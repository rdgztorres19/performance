-- MySQL dump 10.13  Distrib 8.0.44, for Linux (x86_64)
--
-- Host: localhost    Database: blog_prod
-- ------------------------------------------------------
-- Server version	8.0.44-0ubuntu0.22.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `actions`
--

DROP TABLE IF EXISTS `actions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `actions` (
  `id` varchar(24) NOT NULL,
  `resource_id` varchar(24) DEFAULT NULL,
  `resource_type` varchar(50) NOT NULL,
  `actor_id` varchar(24) NOT NULL,
  `actor_type` varchar(50) NOT NULL,
  `event` varchar(50) NOT NULL,
  `context` text,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `actions`
--

LOCK TABLES `actions` WRITE;
/*!40000 ALTER TABLE `actions` DISABLE KEYS */;
INSERT INTO `actions` VALUES ('694f267cc3e44e650f0e60ab','694f2666c3e44e650f0e6033','setting','694f2665c3e44e650f0e5dd8','user','edited','{\"key\":\"description\",\"group\":\"site\"}','2025-12-27 00:21:16'),('694f267cc3e44e650f0e60ac','694f2666c3e44e650f0e6032','setting','694f2665c3e44e650f0e5dd8','user','edited','{\"key\":\"title\",\"group\":\"site\"}','2025-12-27 00:21:16'),('694f267dc3e44e650f0e60ae','694f2665c3e44e650f0e5dd8','user','694f2665c3e44e650f0e5dd8','user','edited','{\"primary_name\":\"Manuel A Rodriguez\"}','2025-12-27 00:21:17'),('694f267dc3e44e650f0e60af','694f2665c3e44e650f0e5dd8','user','694f2665c3e44e650f0e5dd8','user','edited','{\"primary_name\":\"Manuel A Rodriguez\"}','2025-12-27 00:21:17'),('694f267fc3e44e650f0e60b1','694f2665c3e44e650f0e5dd8','user','694f2665c3e44e650f0e5dd8','user','edited','{\"primary_name\":\"Manuel A Rodriguez\"}','2025-12-27 00:21:19'),('694f269bc3e44e650f0e60b2','694f2666c3e44e650f0e6037','setting','694f2665c3e44e650f0e5dd8','user','edited','{\"key\":\"cover_image\",\"group\":\"site\"}','2025-12-27 00:21:47'),('694f269dc3e44e650f0e60b3','694f2665c3e44e650f0e5dd8','user','694f2665c3e44e650f0e5dd8','user','edited','{\"primary_name\":\"Manuel A Rodriguez\"}','2025-12-27 00:21:49'),('694f26a5c3e44e650f0e60b4','694f2665c3e44e650f0e5dd8','user','694f2665c3e44e650f0e5dd8','user','edited','{\"primary_name\":\"Manuel A Rodriguez\"}','2025-12-27 00:21:57'),('694f26a6c3e44e650f0e60b8','694f26a6c3e44e650f0e60b6','member','694f2665c3e44e650f0e5dd8','user','added','{\"primary_name\":\"Manuel A Rodriguez\"}','2025-12-27 00:21:58'),('694f26aac3e44e650f0e60bc','694f2665c3e44e650f0e5dd8','user','694f2665c3e44e650f0e5dd8','user','edited','{\"primary_name\":\"Manuel A Rodriguez\"}','2025-12-27 00:22:02'),('694f26b1c3e44e650f0e60bd','694f2665c3e44e650f0e5dd8','user','694f2665c3e44e650f0e5dd8','user','edited','{\"primary_name\":\"Manuel A Rodriguez\"}','2025-12-27 00:22:09'),('694f2c677f4d7d685707e3f3','694f2c677f4d7d685707e3f2','api_key','694f2665c3e44e650f0e5dd8','user','added','{}','2025-12-27 00:46:31'),('694f2c677f4d7d685707e3f5','694f2c677f4d7d685707e3f4','api_key','694f2665c3e44e650f0e5dd8','user','added','{}','2025-12-27 00:46:31'),('694f2c677f4d7d685707e3f6','694f2c677f4d7d685707e3f1','integration','694f2665c3e44e650f0e5dd8','user','added','{\"primary_name\":\"performance\"}','2025-12-27 00:46:31'),('694f2cf27f4d7d685707e3f8','694f2cf27f4d7d685707e3f7','tag','694f2c677f4d7d685707e3f1','integration','added','{\"primary_name\":\"Hardware & Operating System\"}','2025-12-27 00:48:50'),('694f2cf37f4d7d685707e3fa','694f2cf37f4d7d685707e3f9','tag','694f2c677f4d7d685707e3f1','integration','added','{\"primary_name\":\"CPU Optimization\"}','2025-12-27 00:48:51'),('694f2cf37f4d7d685707e3fc','694f2cf37f4d7d685707e3fb','tag','694f2c677f4d7d685707e3f1','integration','added','{\"primary_name\":\"Performance\"}','2025-12-27 00:48:51'),('694f2cf37f4d7d685707e3fe','694f2cf37f4d7d685707e3fd','tag','694f2c677f4d7d685707e3f1','integration','added','{\"primary_name\":\"Optimization\"}','2025-12-27 00:48:51'),('694f2cf37f4d7d685707e400','694f2cf37f4d7d685707e3ff','tag','694f2c677f4d7d685707e3f1','integration','added','{\"primary_name\":\"System Design\"}','2025-12-27 00:48:51'),('694f2cf37f4d7d685707e402','694f2cf37f4d7d685707e401','tag','694f2c677f4d7d685707e3f1','integration','added','{\"primary_name\":\"Architecture\"}','2025-12-27 00:48:51'),('694f2cf47f4d7d685707e40c','694f2cf37f4d7d685707e403','post','694f2c677f4d7d685707e3f1','integration','added','{\"type\":\"post\",\"primary_name\":\"Prefer Fewer Fast CPU Cores Over Many Slow Ones for Latency-Sensitive Workloads\"}','2025-12-27 00:48:52'),('694f2d027f4d7d685707e40d','694f2665c3e44e650f0e5e68','post','694f2665c3e44e650f0e5dd8','user','deleted','{\"type\":\"post\",\"primary_name\":\"Coming soon\"}','2025-12-27 00:49:06'),('694f2db57f4d7d685707e40e','694f2666c3e44e650f0e603c','setting','694f2665c3e44e650f0e5dd8','user','edited','{\"key\":\"codeinjection_head\",\"group\":\"site\"}','2025-12-27 00:52:05'),('694f2e4f7f4d7d685707e412','694f2e4f7f4d7d685707e40f','post','694f2665c3e44e650f0e5dd8','user','added','{\"type\":\"post\",\"primary_name\":\"Tesmp\"}','2025-12-27 00:54:39'),('694f2e5c7f4d7d685707e414','694f2e4f7f4d7d685707e40f','post','694f2665c3e44e650f0e5dd8','user','edited','{\"type\":\"post\",\"primary_name\":\"Tesmp\"}','2025-12-27 00:54:52'),('694f2e617f4d7d685707e416','694f2e4f7f4d7d685707e40f','post','694f2665c3e44e650f0e5dd8','user','edited','{\"type\":\"post\",\"primary_name\":\"Tesmp\"}','2025-12-27 00:54:57'),('694f2e787f4d7d685707e417','694f2e4f7f4d7d685707e40f','post','694f2665c3e44e650f0e5dd8','user','deleted','{\"type\":\"post\",\"primary_name\":\"Tesmp\"}','2025-12-27 00:55:20'),('694f2fbd7f4d7d685707e418','694f2666c3e44e650f0e6033','setting','694f2665c3e44e650f0e5dd8','user','edited','{\"key\":\"description\",\"group\":\"site\"}','2025-12-27 01:00:45'),('694f2fbd7f4d7d685707e419','694f2666c3e44e650f0e6032','setting','694f2665c3e44e650f0e5dd8','user','edited','{\"key\":\"title\",\"group\":\"site\"}','2025-12-27 01:00:45'),('694f30937f4d7d685707e41b','694f2cf37f4d7d685707e403','post','694f2665c3e44e650f0e5dd8','user','edited','{\"type\":\"post\",\"primary_name\":\"Prefer Fewer Fast CPU Cores Over Many Slow Ones for Latency-Sensitive Workloads\"}','2025-12-27 01:04:19');
/*!40000 ALTER TABLE `actions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `api_keys`
--

DROP TABLE IF EXISTS `api_keys`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `api_keys` (
  `id` varchar(24) NOT NULL,
  `type` varchar(50) NOT NULL,
  `secret` varchar(191) NOT NULL,
  `role_id` varchar(24) DEFAULT NULL,
  `integration_id` varchar(24) DEFAULT NULL,
  `user_id` varchar(24) DEFAULT NULL,
  `last_seen_at` datetime DEFAULT NULL,
  `last_seen_version` varchar(50) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `api_keys_secret_unique` (`secret`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `api_keys`
--

LOCK TABLES `api_keys` WRITE;
/*!40000 ALTER TABLE `api_keys` DISABLE KEYS */;
INSERT INTO `api_keys` VALUES ('694f2666c3e44e650f0e5e6d','admin','cc2874d8e119186f7d8939f57ce4cd5defe14c5b337960421a7c0af313dffcfa','694f2665c3e44e650f0e5dde','694f2666c3e44e650f0e5e6c',NULL,NULL,NULL,'2025-12-27 00:20:54','2025-12-27 00:20:54'),('694f2666c3e44e650f0e5e6f','admin','075358cab5a2371275f6225ae750455f8123d374833b7860b82bc1b441b72c08','694f2665c3e44e650f0e5ddf','694f2666c3e44e650f0e5e6e',NULL,NULL,NULL,'2025-12-27 00:20:54','2025-12-27 00:20:54'),('694f2666c3e44e650f0e5e71','admin','e9092493b89c606900fe55f280ee46c2822ce1c0ab6f138e03656061e650b8b2','694f2665c3e44e650f0e5de0','694f2666c3e44e650f0e5e70',NULL,NULL,NULL,'2025-12-27 00:20:54','2025-12-27 00:20:54'),('694f2666c3e44e650f0e5e73','admin','59de193d906b60b0a90626580d14c506a4b464934427be1c44557db3d20268e4','694f2665c3e44e650f0e5de1','694f2666c3e44e650f0e5e72',NULL,NULL,NULL,'2025-12-27 00:20:54','2025-12-27 00:20:54'),('694f2666c3e44e650f0e5e75','admin','db88facae5da33462bbb1a4a7df8837a5e791888cc3a44cfcb6047f74cbeeb80','694f2665c3e44e650f0e5de2','694f2666c3e44e650f0e5e74',NULL,NULL,NULL,'2025-12-27 00:20:54','2025-12-27 00:20:54'),('694f2666c3e44e650f0e5e77','content','567ceef764cc169394967bc446',NULL,'694f2666c3e44e650f0e5e76',NULL,NULL,NULL,'2025-12-27 00:20:54','2025-12-27 00:20:54'),('694f2666c3e44e650f0e5e79','content','c549d6db9666a564bed4eda5f4',NULL,'694f2666c3e44e650f0e5e78',NULL,NULL,NULL,'2025-12-27 00:20:54','2025-12-27 00:20:54'),('694f2c677f4d7d685707e3f2','content','a726bf900fe10718d68468b462',NULL,'694f2c677f4d7d685707e3f1',NULL,NULL,NULL,'2025-12-27 00:46:32','2025-12-27 00:46:32'),('694f2c677f4d7d685707e3f4','admin','a8ecd428b0cfdb67d2f797d8980736629918825e38f56c3bd14f5be0ec3d9a92','694f2665c3e44e650f0e5dde','694f2c677f4d7d685707e3f1',NULL,NULL,NULL,'2025-12-27 00:46:32','2025-12-27 00:46:32');
/*!40000 ALTER TABLE `api_keys` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `automated_emails`
--

DROP TABLE IF EXISTS `automated_emails`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `automated_emails` (
  `id` varchar(24) NOT NULL,
  `status` varchar(50) NOT NULL DEFAULT 'inactive',
  `name` varchar(191) NOT NULL,
  `slug` varchar(191) NOT NULL,
  `subject` varchar(300) NOT NULL,
  `lexical` longtext,
  `sender_name` varchar(191) DEFAULT NULL,
  `sender_email` varchar(191) DEFAULT NULL,
  `sender_reply_to` varchar(191) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `automated_emails_name_unique` (`name`),
  UNIQUE KEY `automated_emails_slug_unique` (`slug`),
  KEY `automated_emails_slug_index` (`slug`),
  KEY `automated_emails_status_index` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `automated_emails`
--

LOCK TABLES `automated_emails` WRITE;
/*!40000 ALTER TABLE `automated_emails` DISABLE KEYS */;
/*!40000 ALTER TABLE `automated_emails` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `benefits`
--

DROP TABLE IF EXISTS `benefits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `benefits` (
  `id` varchar(24) NOT NULL,
  `name` varchar(191) NOT NULL,
  `slug` varchar(191) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `benefits_slug_unique` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `benefits`
--

LOCK TABLES `benefits` WRITE;
/*!40000 ALTER TABLE `benefits` DISABLE KEYS */;
/*!40000 ALTER TABLE `benefits` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `brute`
--

DROP TABLE IF EXISTS `brute`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `brute` (
  `key` varchar(191) NOT NULL,
  `firstRequest` bigint NOT NULL,
  `lastRequest` bigint NOT NULL,
  `lifetime` bigint NOT NULL,
  `count` int NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `brute`
--

LOCK TABLES `brute` WRITE;
/*!40000 ALTER TABLE `brute` DISABLE KEYS */;
INSERT INTO `brute` VALUES ('/8DLOhjqMm7DoqGs0JVGHfOH29miQtHufOwWD+g7b94=',1766794877041,1766794877041,1766798477042,1),('WRV1o1ja7Z/FstPwgCKxV8PaV1yhXzpVvJn2+N+nFYY=',1766796345070,1766796345070,1766799945071,1),('ZYxcVXqpav4FkwIb6oBgPt8OFb/fPDhMFx2EIpufD3A=',1766796314701,1766796314701,1766799914703,1);
/*!40000 ALTER TABLE `brute` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `collections`
--

DROP TABLE IF EXISTS `collections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `collections` (
  `id` varchar(24) NOT NULL,
  `title` varchar(191) NOT NULL,
  `slug` varchar(191) NOT NULL,
  `description` varchar(2000) DEFAULT NULL,
  `type` varchar(50) NOT NULL,
  `filter` text,
  `feature_image` varchar(2000) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `collections_slug_unique` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `collections`
--

LOCK TABLES `collections` WRITE;
/*!40000 ALTER TABLE `collections` DISABLE KEYS */;
INSERT INTO `collections` VALUES ('694f2665c3e44e650f0e5de5','Latest','latest','All posts','automatic',NULL,NULL,'2025-12-27 00:20:53','2025-12-27 00:20:53'),('694f2665c3e44e650f0e5de6','Featured','featured','Featured posts','automatic','featured:true',NULL,'2025-12-27 00:20:53','2025-12-27 00:20:53');
/*!40000 ALTER TABLE `collections` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `collections_posts`
--

DROP TABLE IF EXISTS `collections_posts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `collections_posts` (
  `id` varchar(24) NOT NULL,
  `collection_id` varchar(24) NOT NULL,
  `post_id` varchar(24) NOT NULL,
  `sort_order` int unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `collections_posts_collection_id_foreign` (`collection_id`),
  KEY `collections_posts_post_id_foreign` (`post_id`),
  CONSTRAINT `collections_posts_collection_id_foreign` FOREIGN KEY (`collection_id`) REFERENCES `collections` (`id`) ON DELETE CASCADE,
  CONSTRAINT `collections_posts_post_id_foreign` FOREIGN KEY (`post_id`) REFERENCES `posts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `collections_posts`
--

LOCK TABLES `collections_posts` WRITE;
/*!40000 ALTER TABLE `collections_posts` DISABLE KEYS */;
/*!40000 ALTER TABLE `collections_posts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `comment_likes`
--

DROP TABLE IF EXISTS `comment_likes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `comment_likes` (
  `id` varchar(24) NOT NULL,
  `comment_id` varchar(24) NOT NULL,
  `member_id` varchar(24) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `comment_likes_comment_id_foreign` (`comment_id`),
  KEY `comment_likes_member_id_foreign` (`member_id`),
  CONSTRAINT `comment_likes_comment_id_foreign` FOREIGN KEY (`comment_id`) REFERENCES `comments` (`id`) ON DELETE CASCADE,
  CONSTRAINT `comment_likes_member_id_foreign` FOREIGN KEY (`member_id`) REFERENCES `members` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comment_likes`
--

LOCK TABLES `comment_likes` WRITE;
/*!40000 ALTER TABLE `comment_likes` DISABLE KEYS */;
/*!40000 ALTER TABLE `comment_likes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `comment_reports`
--

DROP TABLE IF EXISTS `comment_reports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `comment_reports` (
  `id` varchar(24) NOT NULL,
  `comment_id` varchar(24) NOT NULL,
  `member_id` varchar(24) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `comment_reports_comment_id_foreign` (`comment_id`),
  KEY `comment_reports_member_id_foreign` (`member_id`),
  CONSTRAINT `comment_reports_comment_id_foreign` FOREIGN KEY (`comment_id`) REFERENCES `comments` (`id`) ON DELETE CASCADE,
  CONSTRAINT `comment_reports_member_id_foreign` FOREIGN KEY (`member_id`) REFERENCES `members` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comment_reports`
--

LOCK TABLES `comment_reports` WRITE;
/*!40000 ALTER TABLE `comment_reports` DISABLE KEYS */;
/*!40000 ALTER TABLE `comment_reports` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `comments`
--

DROP TABLE IF EXISTS `comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `comments` (
  `id` varchar(24) NOT NULL,
  `post_id` varchar(24) NOT NULL,
  `member_id` varchar(24) DEFAULT NULL,
  `parent_id` varchar(24) DEFAULT NULL,
  `in_reply_to_id` varchar(24) DEFAULT NULL,
  `status` varchar(50) NOT NULL DEFAULT 'published',
  `html` longtext,
  `edited_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `comments_post_id_foreign` (`post_id`),
  KEY `comments_member_id_foreign` (`member_id`),
  KEY `comments_parent_id_foreign` (`parent_id`),
  KEY `comments_in_reply_to_id_foreign` (`in_reply_to_id`),
  CONSTRAINT `comments_in_reply_to_id_foreign` FOREIGN KEY (`in_reply_to_id`) REFERENCES `comments` (`id`) ON DELETE SET NULL,
  CONSTRAINT `comments_member_id_foreign` FOREIGN KEY (`member_id`) REFERENCES `members` (`id`) ON DELETE SET NULL,
  CONSTRAINT `comments_parent_id_foreign` FOREIGN KEY (`parent_id`) REFERENCES `comments` (`id`) ON DELETE CASCADE,
  CONSTRAINT `comments_post_id_foreign` FOREIGN KEY (`post_id`) REFERENCES `posts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comments`
--

LOCK TABLES `comments` WRITE;
/*!40000 ALTER TABLE `comments` DISABLE KEYS */;
/*!40000 ALTER TABLE `comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `custom_theme_settings`
--

DROP TABLE IF EXISTS `custom_theme_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `custom_theme_settings` (
  `id` varchar(24) NOT NULL,
  `theme` varchar(191) NOT NULL,
  `key` varchar(191) NOT NULL,
  `type` varchar(50) NOT NULL,
  `value` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `custom_theme_settings`
--

LOCK TABLES `custom_theme_settings` WRITE;
/*!40000 ALTER TABLE `custom_theme_settings` DISABLE KEYS */;
INSERT INTO `custom_theme_settings` VALUES ('694f2667c3e44e650f0e6093','source','navigation_layout','select','Logo in the middle'),('694f2667c3e44e650f0e6094','source','site_background_color','color','#ffffff'),('694f2667c3e44e650f0e6095','source','header_and_footer_color','select','Background color'),('694f2667c3e44e650f0e6096','source','title_font','select','Modern sans-serif'),('694f2667c3e44e650f0e6097','source','body_font','select','Modern sans-serif'),('694f2667c3e44e650f0e6098','source','signup_heading','text',NULL),('694f2667c3e44e650f0e6099','source','signup_subheading','text',NULL),('694f2667c3e44e650f0e609a','source','header_style','select','Landing'),('694f2667c3e44e650f0e609b','source','header_text','text',NULL),('694f2667c3e44e650f0e609c','source','background_image','boolean','true'),('694f2667c3e44e650f0e609d','source','show_featured_posts','boolean','false'),('694f2667c3e44e650f0e609e','source','post_feed_style','select','List'),('694f2667c3e44e650f0e609f','source','show_images_in_feed','boolean','true'),('694f2667c3e44e650f0e60a0','source','show_author','boolean','true'),('694f2667c3e44e650f0e60a1','source','show_publish_date','boolean','true'),('694f2667c3e44e650f0e60a2','source','show_publication_info_sidebar','boolean','false'),('694f2667c3e44e650f0e60a3','source','show_post_metadata','boolean','true'),('694f2667c3e44e650f0e60a4','source','enable_drop_caps_on_posts','boolean','false'),('694f2667c3e44e650f0e60a5','source','show_related_articles','boolean','true');
/*!40000 ALTER TABLE `custom_theme_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `donation_payment_events`
--

DROP TABLE IF EXISTS `donation_payment_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `donation_payment_events` (
  `id` varchar(24) NOT NULL,
  `name` varchar(191) DEFAULT NULL,
  `email` varchar(191) NOT NULL,
  `member_id` varchar(24) DEFAULT NULL,
  `amount` int NOT NULL,
  `currency` varchar(50) NOT NULL,
  `attribution_id` varchar(24) DEFAULT NULL,
  `attribution_type` varchar(50) DEFAULT NULL,
  `attribution_url` varchar(2000) DEFAULT NULL,
  `referrer_source` varchar(191) DEFAULT NULL,
  `referrer_medium` varchar(191) DEFAULT NULL,
  `referrer_url` varchar(2000) DEFAULT NULL,
  `utm_source` varchar(191) DEFAULT NULL,
  `utm_medium` varchar(191) DEFAULT NULL,
  `utm_campaign` varchar(191) DEFAULT NULL,
  `utm_term` varchar(191) DEFAULT NULL,
  `utm_content` varchar(191) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `donation_message` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `donation_payment_events_member_id_foreign` (`member_id`),
  CONSTRAINT `donation_payment_events_member_id_foreign` FOREIGN KEY (`member_id`) REFERENCES `members` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `donation_payment_events`
--

LOCK TABLES `donation_payment_events` WRITE;
/*!40000 ALTER TABLE `donation_payment_events` DISABLE KEYS */;
/*!40000 ALTER TABLE `donation_payment_events` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `email_batches`
--

DROP TABLE IF EXISTS `email_batches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `email_batches` (
  `id` varchar(24) NOT NULL,
  `email_id` varchar(24) NOT NULL,
  `provider_id` varchar(255) DEFAULT NULL,
  `fallback_sending_domain` tinyint(1) NOT NULL DEFAULT '0',
  `status` varchar(50) NOT NULL DEFAULT 'pending',
  `member_segment` text,
  `error_status_code` int unsigned DEFAULT NULL,
  `error_message` varchar(2000) DEFAULT NULL,
  `error_data` longtext,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `email_batches_email_id_foreign` (`email_id`),
  CONSTRAINT `email_batches_email_id_foreign` FOREIGN KEY (`email_id`) REFERENCES `emails` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `email_batches`
--

LOCK TABLES `email_batches` WRITE;
/*!40000 ALTER TABLE `email_batches` DISABLE KEYS */;
/*!40000 ALTER TABLE `email_batches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `email_recipient_failures`
--

DROP TABLE IF EXISTS `email_recipient_failures`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `email_recipient_failures` (
  `id` varchar(24) NOT NULL,
  `email_id` varchar(24) NOT NULL,
  `member_id` varchar(24) DEFAULT NULL,
  `email_recipient_id` varchar(24) NOT NULL,
  `code` int unsigned NOT NULL,
  `enhanced_code` varchar(50) DEFAULT NULL,
  `message` varchar(2000) NOT NULL,
  `severity` varchar(50) NOT NULL DEFAULT 'permanent',
  `failed_at` datetime NOT NULL,
  `event_id` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `email_recipient_failures_email_id_foreign` (`email_id`),
  KEY `email_recipient_failures_email_recipient_id_foreign` (`email_recipient_id`),
  CONSTRAINT `email_recipient_failures_email_id_foreign` FOREIGN KEY (`email_id`) REFERENCES `emails` (`id`),
  CONSTRAINT `email_recipient_failures_email_recipient_id_foreign` FOREIGN KEY (`email_recipient_id`) REFERENCES `email_recipients` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `email_recipient_failures`
--

LOCK TABLES `email_recipient_failures` WRITE;
/*!40000 ALTER TABLE `email_recipient_failures` DISABLE KEYS */;
/*!40000 ALTER TABLE `email_recipient_failures` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `email_recipients`
--

DROP TABLE IF EXISTS `email_recipients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `email_recipients` (
  `id` varchar(24) NOT NULL,
  `email_id` varchar(24) NOT NULL,
  `member_id` varchar(24) NOT NULL,
  `batch_id` varchar(24) NOT NULL,
  `processed_at` datetime DEFAULT NULL,
  `delivered_at` datetime DEFAULT NULL,
  `opened_at` datetime DEFAULT NULL,
  `failed_at` datetime DEFAULT NULL,
  `member_uuid` varchar(36) NOT NULL,
  `member_email` varchar(191) NOT NULL,
  `member_name` varchar(191) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `email_recipients_member_id_index` (`member_id`),
  KEY `email_recipients_batch_id_foreign` (`batch_id`),
  KEY `email_recipients_email_id_member_email_index` (`email_id`,`member_email`),
  KEY `email_recipients_email_id_delivered_at_index` (`email_id`,`delivered_at`),
  KEY `email_recipients_email_id_opened_at_index` (`email_id`,`opened_at`),
  KEY `email_recipients_email_id_failed_at_index` (`email_id`,`failed_at`),
  CONSTRAINT `email_recipients_batch_id_foreign` FOREIGN KEY (`batch_id`) REFERENCES `email_batches` (`id`),
  CONSTRAINT `email_recipients_email_id_foreign` FOREIGN KEY (`email_id`) REFERENCES `emails` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `email_recipients`
--

LOCK TABLES `email_recipients` WRITE;
/*!40000 ALTER TABLE `email_recipients` DISABLE KEYS */;
/*!40000 ALTER TABLE `email_recipients` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `email_spam_complaint_events`
--

DROP TABLE IF EXISTS `email_spam_complaint_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `email_spam_complaint_events` (
  `id` varchar(24) NOT NULL,
  `member_id` varchar(24) NOT NULL,
  `email_id` varchar(24) NOT NULL,
  `email_address` varchar(191) NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email_spam_complaint_events_email_id_member_id_unique` (`email_id`,`member_id`),
  KEY `email_spam_complaint_events_member_id_foreign` (`member_id`),
  CONSTRAINT `email_spam_complaint_events_email_id_foreign` FOREIGN KEY (`email_id`) REFERENCES `emails` (`id`),
  CONSTRAINT `email_spam_complaint_events_member_id_foreign` FOREIGN KEY (`member_id`) REFERENCES `members` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `email_spam_complaint_events`
--

LOCK TABLES `email_spam_complaint_events` WRITE;
/*!40000 ALTER TABLE `email_spam_complaint_events` DISABLE KEYS */;
/*!40000 ALTER TABLE `email_spam_complaint_events` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `emails`
--

DROP TABLE IF EXISTS `emails`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `emails` (
  `id` varchar(24) NOT NULL,
  `post_id` varchar(24) NOT NULL,
  `uuid` varchar(36) NOT NULL,
  `status` varchar(50) NOT NULL DEFAULT 'pending',
  `recipient_filter` text NOT NULL,
  `error` varchar(2000) DEFAULT NULL,
  `error_data` longtext,
  `email_count` int unsigned NOT NULL DEFAULT '0',
  `csd_email_count` int unsigned DEFAULT NULL,
  `delivered_count` int unsigned NOT NULL DEFAULT '0',
  `opened_count` int unsigned NOT NULL DEFAULT '0',
  `failed_count` int unsigned NOT NULL DEFAULT '0',
  `subject` varchar(300) DEFAULT NULL,
  `from` varchar(2000) DEFAULT NULL,
  `reply_to` varchar(2000) DEFAULT NULL,
  `html` longtext,
  `plaintext` longtext,
  `source` longtext,
  `source_type` varchar(50) NOT NULL DEFAULT 'html',
  `track_opens` tinyint(1) NOT NULL DEFAULT '0',
  `track_clicks` tinyint(1) NOT NULL DEFAULT '0',
  `feedback_enabled` tinyint(1) NOT NULL DEFAULT '0',
  `submitted_at` datetime NOT NULL,
  `newsletter_id` varchar(24) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `emails_post_id_unique` (`post_id`),
  KEY `emails_post_id_index` (`post_id`),
  KEY `emails_newsletter_id_foreign` (`newsletter_id`),
  CONSTRAINT `emails_newsletter_id_foreign` FOREIGN KEY (`newsletter_id`) REFERENCES `newsletters` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `emails`
--

LOCK TABLES `emails` WRITE;
/*!40000 ALTER TABLE `emails` DISABLE KEYS */;
/*!40000 ALTER TABLE `emails` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `integrations`
--

DROP TABLE IF EXISTS `integrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `integrations` (
  `id` varchar(24) NOT NULL,
  `type` varchar(50) NOT NULL DEFAULT 'custom',
  `name` varchar(191) NOT NULL,
  `slug` varchar(191) NOT NULL,
  `icon_image` varchar(2000) DEFAULT NULL,
  `description` varchar(2000) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `integrations_slug_unique` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `integrations`
--

LOCK TABLES `integrations` WRITE;
/*!40000 ALTER TABLE `integrations` DISABLE KEYS */;
INSERT INTO `integrations` VALUES ('694f2666c3e44e650f0e5e6c','builtin','Zapier','zapier',NULL,'Built-in Zapier integration','2025-12-27 00:20:54','2025-12-27 00:20:54'),('694f2666c3e44e650f0e5e6e','core','Ghost Explore','ghost-explore',NULL,'Built-in Ghost Explore integration','2025-12-27 00:20:54','2025-12-27 00:20:54'),('694f2666c3e44e650f0e5e70','core','Self-Serve Migration Integration','self-serve-migration',NULL,'Core Self-Serve Migration integration','2025-12-27 00:20:54','2025-12-27 00:20:54'),('694f2666c3e44e650f0e5e72','internal','Ghost Backup','ghost-backup',NULL,'Internal DB Backup integration','2025-12-27 00:20:54','2025-12-27 00:20:54'),('694f2666c3e44e650f0e5e74','internal','Ghost Scheduler','ghost-scheduler',NULL,'Internal Scheduler integration','2025-12-27 00:20:54','2025-12-27 00:20:54'),('694f2666c3e44e650f0e5e76','internal','Ghost Internal Frontend','ghost-internal-frontend',NULL,'Internal frontend integration','2025-12-27 00:20:54','2025-12-27 00:20:54'),('694f2666c3e44e650f0e5e78','core','Ghost Core Content API','ghost-core-content',NULL,'Internal Content API integration for Admin access','2025-12-27 00:20:54','2025-12-27 00:20:54'),('694f2666c3e44e650f0e5e7a','internal','Ghost ActivityPub','ghost-activitypub',NULL,'Internal Integration for ActivityPub','2025-12-27 00:20:54','2025-12-27 00:20:54'),('694f2c677f4d7d685707e3f1','custom','performance','performance',NULL,NULL,'2025-12-27 00:46:31','2025-12-27 00:46:31');
/*!40000 ALTER TABLE `integrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `invites`
--

DROP TABLE IF EXISTS `invites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `invites` (
  `id` varchar(24) NOT NULL,
  `role_id` varchar(24) NOT NULL,
  `status` varchar(50) NOT NULL DEFAULT 'pending',
  `token` varchar(191) NOT NULL,
  `email` varchar(191) NOT NULL,
  `expires` bigint NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `invites_token_unique` (`token`),
  UNIQUE KEY `invites_email_unique` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `invites`
--

LOCK TABLES `invites` WRITE;
/*!40000 ALTER TABLE `invites` DISABLE KEYS */;
/*!40000 ALTER TABLE `invites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jobs`
--

DROP TABLE IF EXISTS `jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `jobs` (
  `id` varchar(24) NOT NULL,
  `name` varchar(191) NOT NULL,
  `status` varchar(50) NOT NULL DEFAULT 'queued',
  `started_at` datetime DEFAULT NULL,
  `finished_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  `metadata` varchar(2000) DEFAULT NULL,
  `queue_entry` int unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `jobs_name_unique` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jobs`
--

LOCK TABLES `jobs` WRITE;
/*!40000 ALTER TABLE `jobs` DISABLE KEYS */;
INSERT INTO `jobs` VALUES ('694f2667c3e44e650f0e60a6','members-migrations','finished','2025-12-27 00:20:55','2025-12-27 00:20:55','2025-12-27 00:20:55','2025-12-27 00:20:55',NULL,NULL);
/*!40000 ALTER TABLE `jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `labels`
--

DROP TABLE IF EXISTS `labels`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `labels` (
  `id` varchar(24) NOT NULL,
  `name` varchar(191) NOT NULL,
  `slug` varchar(191) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `labels_name_unique` (`name`),
  UNIQUE KEY `labels_slug_unique` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `labels`
--

LOCK TABLES `labels` WRITE;
/*!40000 ALTER TABLE `labels` DISABLE KEYS */;
/*!40000 ALTER TABLE `labels` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `members`
--

DROP TABLE IF EXISTS `members`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `members` (
  `id` varchar(24) NOT NULL,
  `uuid` varchar(36) NOT NULL,
  `transient_id` varchar(191) NOT NULL,
  `email` varchar(191) NOT NULL,
  `status` varchar(50) NOT NULL DEFAULT 'free',
  `name` varchar(191) DEFAULT NULL,
  `expertise` varchar(191) DEFAULT NULL,
  `note` varchar(2000) DEFAULT NULL,
  `geolocation` varchar(2000) DEFAULT NULL,
  `enable_comment_notifications` tinyint(1) NOT NULL DEFAULT '1',
  `email_count` int unsigned NOT NULL DEFAULT '0',
  `email_opened_count` int unsigned NOT NULL DEFAULT '0',
  `email_open_rate` int unsigned DEFAULT NULL,
  `email_disabled` tinyint(1) NOT NULL DEFAULT '0',
  `last_seen_at` datetime DEFAULT NULL,
  `last_commented_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `members_uuid_unique` (`uuid`),
  UNIQUE KEY `members_transient_id_unique` (`transient_id`),
  UNIQUE KEY `members_email_unique` (`email`),
  KEY `members_email_open_rate_index` (`email_open_rate`),
  KEY `members_email_disabled_index` (`email_disabled`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `members`
--

LOCK TABLES `members` WRITE;
/*!40000 ALTER TABLE `members` DISABLE KEYS */;
INSERT INTO `members` VALUES ('694f26a6c3e44e650f0e60b6','ec211e6b-343e-4ab1-9bb5-3a324df0027e','e63b2bcd-7293-4666-96b9-09d3534bea0c','rdgztorres19@gmail.com','free','Manuel A Rodriguez',NULL,NULL,NULL,1,0,0,NULL,0,NULL,NULL,'2025-12-27 00:21:58','2025-12-27 00:21:58');
/*!40000 ALTER TABLE `members` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `members_cancel_events`
--

DROP TABLE IF EXISTS `members_cancel_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `members_cancel_events` (
  `id` varchar(24) NOT NULL,
  `member_id` varchar(24) NOT NULL,
  `from_plan` varchar(255) NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `members_cancel_events_member_id_foreign` (`member_id`),
  CONSTRAINT `members_cancel_events_member_id_foreign` FOREIGN KEY (`member_id`) REFERENCES `members` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `members_cancel_events`
--

LOCK TABLES `members_cancel_events` WRITE;
/*!40000 ALTER TABLE `members_cancel_events` DISABLE KEYS */;
/*!40000 ALTER TABLE `members_cancel_events` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `members_click_events`
--

DROP TABLE IF EXISTS `members_click_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `members_click_events` (
  `id` varchar(24) NOT NULL,
  `member_id` varchar(24) NOT NULL,
  `redirect_id` varchar(24) NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `members_click_events_member_id_foreign` (`member_id`),
  KEY `members_click_events_redirect_id_foreign` (`redirect_id`),
  CONSTRAINT `members_click_events_member_id_foreign` FOREIGN KEY (`member_id`) REFERENCES `members` (`id`) ON DELETE CASCADE,
  CONSTRAINT `members_click_events_redirect_id_foreign` FOREIGN KEY (`redirect_id`) REFERENCES `redirects` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `members_click_events`
--

LOCK TABLES `members_click_events` WRITE;
/*!40000 ALTER TABLE `members_click_events` DISABLE KEYS */;
/*!40000 ALTER TABLE `members_click_events` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `members_created_events`
--

DROP TABLE IF EXISTS `members_created_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `members_created_events` (
  `id` varchar(24) NOT NULL,
  `created_at` datetime NOT NULL,
  `member_id` varchar(24) NOT NULL,
  `attribution_id` varchar(24) DEFAULT NULL,
  `attribution_type` varchar(50) DEFAULT NULL,
  `attribution_url` varchar(2000) DEFAULT NULL,
  `referrer_source` varchar(191) DEFAULT NULL,
  `referrer_medium` varchar(191) DEFAULT NULL,
  `referrer_url` varchar(2000) DEFAULT NULL,
  `utm_source` varchar(191) DEFAULT NULL,
  `utm_medium` varchar(191) DEFAULT NULL,
  `utm_campaign` varchar(191) DEFAULT NULL,
  `utm_term` varchar(191) DEFAULT NULL,
  `utm_content` varchar(191) DEFAULT NULL,
  `source` varchar(50) NOT NULL,
  `batch_id` varchar(24) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `members_created_events_member_id_foreign` (`member_id`),
  KEY `members_created_events_attribution_id_index` (`attribution_id`),
  CONSTRAINT `members_created_events_member_id_foreign` FOREIGN KEY (`member_id`) REFERENCES `members` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `members_created_events`
--

LOCK TABLES `members_created_events` WRITE;
/*!40000 ALTER TABLE `members_created_events` DISABLE KEYS */;
INSERT INTO `members_created_events` VALUES ('694f26a6c3e44e650f0e60bb','2025-12-27 00:21:58','694f26a6c3e44e650f0e60b6',NULL,NULL,NULL,'Created manually','Ghost Admin',NULL,NULL,NULL,NULL,NULL,NULL,'admin','694f26a6c3e44e650f0e60b5');
/*!40000 ALTER TABLE `members_created_events` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `members_email_change_events`
--

DROP TABLE IF EXISTS `members_email_change_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `members_email_change_events` (
  `id` varchar(24) NOT NULL,
  `member_id` varchar(24) NOT NULL,
  `to_email` varchar(191) NOT NULL,
  `from_email` varchar(191) NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `members_email_change_events_member_id_foreign` (`member_id`),
  CONSTRAINT `members_email_change_events_member_id_foreign` FOREIGN KEY (`member_id`) REFERENCES `members` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `members_email_change_events`
--

LOCK TABLES `members_email_change_events` WRITE;
/*!40000 ALTER TABLE `members_email_change_events` DISABLE KEYS */;
/*!40000 ALTER TABLE `members_email_change_events` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `members_feedback`
--

DROP TABLE IF EXISTS `members_feedback`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `members_feedback` (
  `id` varchar(24) NOT NULL,
  `score` int unsigned NOT NULL DEFAULT '0',
  `member_id` varchar(24) NOT NULL,
  `post_id` varchar(24) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `members_feedback_member_id_foreign` (`member_id`),
  KEY `members_feedback_post_id_foreign` (`post_id`),
  CONSTRAINT `members_feedback_member_id_foreign` FOREIGN KEY (`member_id`) REFERENCES `members` (`id`) ON DELETE CASCADE,
  CONSTRAINT `members_feedback_post_id_foreign` FOREIGN KEY (`post_id`) REFERENCES `posts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `members_feedback`
--

LOCK TABLES `members_feedback` WRITE;
/*!40000 ALTER TABLE `members_feedback` DISABLE KEYS */;
/*!40000 ALTER TABLE `members_feedback` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `members_labels`
--

DROP TABLE IF EXISTS `members_labels`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `members_labels` (
  `id` varchar(24) NOT NULL,
  `member_id` varchar(24) NOT NULL,
  `label_id` varchar(24) NOT NULL,
  `sort_order` int unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `members_labels_member_id_foreign` (`member_id`),
  KEY `members_labels_label_id_foreign` (`label_id`),
  CONSTRAINT `members_labels_label_id_foreign` FOREIGN KEY (`label_id`) REFERENCES `labels` (`id`) ON DELETE CASCADE,
  CONSTRAINT `members_labels_member_id_foreign` FOREIGN KEY (`member_id`) REFERENCES `members` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `members_labels`
--

LOCK TABLES `members_labels` WRITE;
/*!40000 ALTER TABLE `members_labels` DISABLE KEYS */;
/*!40000 ALTER TABLE `members_labels` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `members_login_events`
--

DROP TABLE IF EXISTS `members_login_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `members_login_events` (
  `id` varchar(24) NOT NULL,
  `member_id` varchar(24) NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `members_login_events_member_id_foreign` (`member_id`),
  CONSTRAINT `members_login_events_member_id_foreign` FOREIGN KEY (`member_id`) REFERENCES `members` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `members_login_events`
--

LOCK TABLES `members_login_events` WRITE;
/*!40000 ALTER TABLE `members_login_events` DISABLE KEYS */;
/*!40000 ALTER TABLE `members_login_events` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `members_newsletters`
--

DROP TABLE IF EXISTS `members_newsletters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `members_newsletters` (
  `id` varchar(24) NOT NULL,
  `member_id` varchar(24) NOT NULL,
  `newsletter_id` varchar(24) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `members_newsletters_member_id_foreign` (`member_id`),
  KEY `members_newsletters_newsletter_id_member_id_index` (`newsletter_id`,`member_id`),
  CONSTRAINT `members_newsletters_member_id_foreign` FOREIGN KEY (`member_id`) REFERENCES `members` (`id`) ON DELETE CASCADE,
  CONSTRAINT `members_newsletters_newsletter_id_foreign` FOREIGN KEY (`newsletter_id`) REFERENCES `newsletters` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `members_newsletters`
--

LOCK TABLES `members_newsletters` WRITE;
/*!40000 ALTER TABLE `members_newsletters` DISABLE KEYS */;
INSERT INTO `members_newsletters` VALUES ('694f26a6c3e44e650f0e60b7','694f26a6c3e44e650f0e60b6','694f2665c3e44e650f0e5de9');
/*!40000 ALTER TABLE `members_newsletters` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `members_paid_subscription_events`
--

DROP TABLE IF EXISTS `members_paid_subscription_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `members_paid_subscription_events` (
  `id` varchar(24) NOT NULL,
  `type` varchar(50) DEFAULT NULL,
  `member_id` varchar(24) NOT NULL,
  `subscription_id` varchar(24) DEFAULT NULL,
  `from_plan` varchar(255) DEFAULT NULL,
  `to_plan` varchar(255) DEFAULT NULL,
  `currency` varchar(191) NOT NULL,
  `source` varchar(50) NOT NULL,
  `mrr_delta` int NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `members_paid_subscription_events_member_id_foreign` (`member_id`),
  CONSTRAINT `members_paid_subscription_events_member_id_foreign` FOREIGN KEY (`member_id`) REFERENCES `members` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `members_paid_subscription_events`
--

LOCK TABLES `members_paid_subscription_events` WRITE;
/*!40000 ALTER TABLE `members_paid_subscription_events` DISABLE KEYS */;
/*!40000 ALTER TABLE `members_paid_subscription_events` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `members_payment_events`
--

DROP TABLE IF EXISTS `members_payment_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `members_payment_events` (
  `id` varchar(24) NOT NULL,
  `member_id` varchar(24) NOT NULL,
  `amount` int NOT NULL,
  `currency` varchar(191) NOT NULL,
  `source` varchar(50) NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `members_payment_events_member_id_foreign` (`member_id`),
  CONSTRAINT `members_payment_events_member_id_foreign` FOREIGN KEY (`member_id`) REFERENCES `members` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `members_payment_events`
--

LOCK TABLES `members_payment_events` WRITE;
/*!40000 ALTER TABLE `members_payment_events` DISABLE KEYS */;
/*!40000 ALTER TABLE `members_payment_events` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `members_product_events`
--

DROP TABLE IF EXISTS `members_product_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `members_product_events` (
  `id` varchar(24) NOT NULL,
  `member_id` varchar(24) NOT NULL,
  `product_id` varchar(24) NOT NULL,
  `action` varchar(50) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `members_product_events_member_id_foreign` (`member_id`),
  KEY `members_product_events_product_id_foreign` (`product_id`),
  CONSTRAINT `members_product_events_member_id_foreign` FOREIGN KEY (`member_id`) REFERENCES `members` (`id`) ON DELETE CASCADE,
  CONSTRAINT `members_product_events_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `members_product_events`
--

LOCK TABLES `members_product_events` WRITE;
/*!40000 ALTER TABLE `members_product_events` DISABLE KEYS */;
/*!40000 ALTER TABLE `members_product_events` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `members_products`
--

DROP TABLE IF EXISTS `members_products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `members_products` (
  `id` varchar(24) NOT NULL,
  `member_id` varchar(24) NOT NULL,
  `product_id` varchar(24) NOT NULL,
  `sort_order` int unsigned NOT NULL DEFAULT '0',
  `expiry_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `members_products_member_id_foreign` (`member_id`),
  KEY `members_products_product_id_foreign` (`product_id`),
  CONSTRAINT `members_products_member_id_foreign` FOREIGN KEY (`member_id`) REFERENCES `members` (`id`) ON DELETE CASCADE,
  CONSTRAINT `members_products_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `members_products`
--

LOCK TABLES `members_products` WRITE;
/*!40000 ALTER TABLE `members_products` DISABLE KEYS */;
/*!40000 ALTER TABLE `members_products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `members_status_events`
--

DROP TABLE IF EXISTS `members_status_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `members_status_events` (
  `id` varchar(24) NOT NULL,
  `member_id` varchar(24) NOT NULL,
  `from_status` varchar(50) DEFAULT NULL,
  `to_status` varchar(50) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `members_status_events_member_id_foreign` (`member_id`),
  CONSTRAINT `members_status_events_member_id_foreign` FOREIGN KEY (`member_id`) REFERENCES `members` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `members_status_events`
--

LOCK TABLES `members_status_events` WRITE;
/*!40000 ALTER TABLE `members_status_events` DISABLE KEYS */;
INSERT INTO `members_status_events` VALUES ('694f26a6c3e44e650f0e60b9','694f26a6c3e44e650f0e60b6',NULL,'free','2025-12-27 00:21:58');
/*!40000 ALTER TABLE `members_status_events` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `members_stripe_customers`
--

DROP TABLE IF EXISTS `members_stripe_customers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `members_stripe_customers` (
  `id` varchar(24) NOT NULL,
  `member_id` varchar(24) NOT NULL,
  `customer_id` varchar(255) NOT NULL,
  `name` varchar(191) DEFAULT NULL,
  `email` varchar(191) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `members_stripe_customers_customer_id_unique` (`customer_id`),
  KEY `members_stripe_customers_member_id_foreign` (`member_id`),
  CONSTRAINT `members_stripe_customers_member_id_foreign` FOREIGN KEY (`member_id`) REFERENCES `members` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `members_stripe_customers`
--

LOCK TABLES `members_stripe_customers` WRITE;
/*!40000 ALTER TABLE `members_stripe_customers` DISABLE KEYS */;
/*!40000 ALTER TABLE `members_stripe_customers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `members_stripe_customers_subscriptions`
--

DROP TABLE IF EXISTS `members_stripe_customers_subscriptions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `members_stripe_customers_subscriptions` (
  `id` varchar(24) NOT NULL,
  `customer_id` varchar(255) NOT NULL,
  `ghost_subscription_id` varchar(24) DEFAULT NULL,
  `subscription_id` varchar(255) NOT NULL,
  `stripe_price_id` varchar(255) NOT NULL DEFAULT '',
  `status` varchar(50) NOT NULL,
  `cancel_at_period_end` tinyint(1) NOT NULL DEFAULT '0',
  `cancellation_reason` varchar(500) DEFAULT NULL,
  `current_period_end` datetime NOT NULL,
  `start_date` datetime NOT NULL,
  `default_payment_card_last4` varchar(4) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  `mrr` int unsigned NOT NULL DEFAULT '0',
  `offer_id` varchar(24) DEFAULT NULL,
  `trial_start_at` datetime DEFAULT NULL,
  `trial_end_at` datetime DEFAULT NULL,
  `plan_id` varchar(255) NOT NULL,
  `plan_nickname` varchar(50) NOT NULL,
  `plan_interval` varchar(50) NOT NULL,
  `plan_amount` int NOT NULL,
  `plan_currency` varchar(191) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `members_stripe_customers_subscriptions_subscription_id_unique` (`subscription_id`),
  KEY `members_stripe_customers_subscriptions_customer_id_foreign` (`customer_id`),
  KEY `mscs_ghost_subscription_id_foreign` (`ghost_subscription_id`),
  KEY `members_stripe_customers_subscriptions_stripe_price_id_index` (`stripe_price_id`),
  KEY `members_stripe_customers_subscriptions_offer_id_foreign` (`offer_id`),
  CONSTRAINT `members_stripe_customers_subscriptions_customer_id_foreign` FOREIGN KEY (`customer_id`) REFERENCES `members_stripe_customers` (`customer_id`) ON DELETE CASCADE,
  CONSTRAINT `members_stripe_customers_subscriptions_offer_id_foreign` FOREIGN KEY (`offer_id`) REFERENCES `offers` (`id`),
  CONSTRAINT `mscs_ghost_subscription_id_foreign` FOREIGN KEY (`ghost_subscription_id`) REFERENCES `subscriptions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `members_stripe_customers_subscriptions`
--

LOCK TABLES `members_stripe_customers_subscriptions` WRITE;
/*!40000 ALTER TABLE `members_stripe_customers_subscriptions` DISABLE KEYS */;
/*!40000 ALTER TABLE `members_stripe_customers_subscriptions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `members_subscribe_events`
--

DROP TABLE IF EXISTS `members_subscribe_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `members_subscribe_events` (
  `id` varchar(24) NOT NULL,
  `member_id` varchar(24) NOT NULL,
  `subscribed` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` datetime NOT NULL,
  `source` varchar(50) DEFAULT NULL,
  `newsletter_id` varchar(24) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `members_subscribe_events_member_id_foreign` (`member_id`),
  KEY `members_subscribe_events_newsletter_id_created_at_index` (`newsletter_id`,`created_at`),
  CONSTRAINT `members_subscribe_events_member_id_foreign` FOREIGN KEY (`member_id`) REFERENCES `members` (`id`) ON DELETE CASCADE,
  CONSTRAINT `members_subscribe_events_newsletter_id_foreign` FOREIGN KEY (`newsletter_id`) REFERENCES `newsletters` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `members_subscribe_events`
--

LOCK TABLES `members_subscribe_events` WRITE;
/*!40000 ALTER TABLE `members_subscribe_events` DISABLE KEYS */;
INSERT INTO `members_subscribe_events` VALUES ('694f26a6c3e44e650f0e60ba','694f26a6c3e44e650f0e60b6',1,'2025-12-27 00:21:58','admin','694f2665c3e44e650f0e5de9');
/*!40000 ALTER TABLE `members_subscribe_events` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `members_subscription_created_events`
--

DROP TABLE IF EXISTS `members_subscription_created_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `members_subscription_created_events` (
  `id` varchar(24) NOT NULL,
  `created_at` datetime NOT NULL,
  `member_id` varchar(24) NOT NULL,
  `subscription_id` varchar(24) NOT NULL,
  `attribution_id` varchar(24) DEFAULT NULL,
  `attribution_type` varchar(50) DEFAULT NULL,
  `attribution_url` varchar(2000) DEFAULT NULL,
  `referrer_source` varchar(191) DEFAULT NULL,
  `referrer_medium` varchar(191) DEFAULT NULL,
  `referrer_url` varchar(2000) DEFAULT NULL,
  `utm_source` varchar(191) DEFAULT NULL,
  `utm_medium` varchar(191) DEFAULT NULL,
  `utm_campaign` varchar(191) DEFAULT NULL,
  `utm_term` varchar(191) DEFAULT NULL,
  `utm_content` varchar(191) DEFAULT NULL,
  `batch_id` varchar(24) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `members_subscription_created_events_member_id_foreign` (`member_id`),
  KEY `members_subscription_created_events_subscription_id_foreign` (`subscription_id`),
  KEY `members_subscription_created_events_attribution_id_index` (`attribution_id`),
  CONSTRAINT `members_subscription_created_events_member_id_foreign` FOREIGN KEY (`member_id`) REFERENCES `members` (`id`) ON DELETE CASCADE,
  CONSTRAINT `members_subscription_created_events_subscription_id_foreign` FOREIGN KEY (`subscription_id`) REFERENCES `members_stripe_customers_subscriptions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `members_subscription_created_events`
--

LOCK TABLES `members_subscription_created_events` WRITE;
/*!40000 ALTER TABLE `members_subscription_created_events` DISABLE KEYS */;
/*!40000 ALTER TABLE `members_subscription_created_events` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mentions`
--

DROP TABLE IF EXISTS `mentions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mentions` (
  `id` varchar(24) NOT NULL,
  `source` varchar(2000) NOT NULL,
  `source_title` varchar(2000) DEFAULT NULL,
  `source_site_title` varchar(2000) DEFAULT NULL,
  `source_excerpt` varchar(2000) DEFAULT NULL,
  `source_author` varchar(2000) DEFAULT NULL,
  `source_featured_image` varchar(2000) DEFAULT NULL,
  `source_favicon` varchar(2000) DEFAULT NULL,
  `target` varchar(2000) NOT NULL,
  `resource_id` varchar(24) DEFAULT NULL,
  `resource_type` varchar(50) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `payload` text,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `verified` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mentions`
--

LOCK TABLES `mentions` WRITE;
/*!40000 ALTER TABLE `mentions` DISABLE KEYS */;
/*!40000 ALTER TABLE `mentions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(120) NOT NULL,
  `version` varchar(70) NOT NULL,
  `currentVersion` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `migrations_name_version_unique` (`name`,`version`)
) ENGINE=InnoDB AUTO_INCREMENT=241 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'1-create-tables.js','init','6.10'),(2,'2-create-fixtures.js','init','6.10'),(3,'01-final-v1.js','1.25','6.10'),(4,'02-noop.js','1.25','6.10'),(5,'01-final-v2.js','2.37','6.10'),(6,'01-final-v3.js','3.41','6.10'),(7,'2022-05-03-15-30-final-v4.js','4.47','6.10'),(8,'2022-05-04-10-03-no-op.js','4.47','6.10'),(9,'2022-03-14-12-33-delete-duplicate-offer-redemptions.js','5.0','6.10'),(10,'2022-03-28-15-25-backfill-mrr-adjustments-for-offers.js','5.0','6.10'),(11,'2022-04-25-10-32-backfill-mrr-for-discounted-subscriptions.js','5.0','6.10'),(12,'2022-04-26-15-44-backfill-mrr-events-for-canceled-subscriptions.js','5.0','6.10'),(13,'2022-04-27-11-26-backfill-mrr-for-canceled-subscriptions.js','5.0','6.10'),(14,'2022-04-28-03-26-remove-author-id-column-from-posts-table.js','5.0','6.10'),(15,'2022-05-03-09-39-drop-nullable-subscribe-event-newsletter-id.js','5.0','6.10'),(16,'2022-05-04-15-24-map-existing-emails-to-default-newsletter.js','5.0','6.10'),(17,'2022-05-05-13-13-migrate-legacy-recipient-filters.js','5.0','6.10'),(18,'2022-05-05-13-29-add-newsletters-admin-integration-permission-roles.js','5.0','6.10'),(19,'2022-05-05-15-17-drop-oauth-table.js','5.0','6.10'),(20,'2022-05-06-08-16-cleanup-client-subscriber-permissions.js','5.0','6.10'),(21,'2022-05-06-13-22-add-frontend-integration.js','5.0','6.10'),(22,'2022-05-09-10-00-drop-members-subscribed-column.js','5.0','6.10'),(23,'2022-05-09-14-17-cleanup-invalid-users-status.js','5.0','6.10'),(24,'2022-05-10-08-33-drop-members-analytics-table.js','5.0','6.10'),(25,'2022-05-10-14-57-cleanup-invalid-posts-status.js','5.0','6.10'),(26,'2022-05-11-12-08-drop-webhooks-status-column.js','5.0','6.10'),(27,'2022-05-11-13-12-rename-settings.js','5.0','6.10'),(28,'2022-05-11-16-36-remove-unused-settings.js','5.0','6.10'),(29,'2022-05-12-10-29-add-newsletter-permissions-for-editors-and-authors.js','5.0','6.10'),(30,'2022-05-12-13-51-add-label-permissions-for-authors.js','5.0','6.10'),(31,'2022-05-13-11-38-drop-none-email-recipient-filter.js','5.0','6.10'),(32,'2022-05-21-00-00-regenerate-posts-html.js','5.0','6.10'),(33,'2022-07-04-13-49-add-comments-table.js','5.3','6.10'),(34,'2022-07-05-09-36-add-comments-likes-table.js','5.3','6.10'),(35,'2022-07-05-09-47-add-comments-reports-table.js','5.3','6.10'),(36,'2022-07-05-10-00-add-comment-related-fields-to-members.js','5.3','6.10'),(37,'2022-07-05-12-55-add-comments-crud-permissions.js','5.3','6.10'),(38,'2022-07-05-15-35-add-comment-notifications-field-to-users-table.js','5.3','6.10'),(39,'2022-07-06-07-26-add-comments-enabled-setting.js','5.3','6.10'),(40,'2022-07-06-07-58-add-ghost-explore-integration-role.js','5.3','6.10'),(41,'2022-07-06-09-13-add-ghost-explore-integration-role-permissions.js','5.3','6.10'),(42,'2022-07-06-09-17-add-ghost-explore-integration.js','5.3','6.10'),(43,'2022-07-06-09-26-add-ghost-explore-integration-api-key.js','5.3','6.10'),(44,'2022-07-18-14-29-add-comment-reporting-permissions.js','5.5','6.10'),(45,'2022-07-18-14-31-drop-reports-reason.js','5.5','6.10'),(46,'2022-07-18-14-32-drop-nullable-member-id-from-likes.js','5.5','6.10'),(47,'2022-07-18-14-33-fix-comments-on-delete-foreign-keys.js','5.5','6.10'),(48,'2022-07-21-08-56-add-jobs-table.js','5.5','6.10'),(49,'2022-07-27-13-40-change-explore-type.js','5.6','6.10'),(50,'2022-08-02-06-09-add-trial-period-days-column-to-tiers.js','5.8','6.10'),(51,'2022-08-03-15-28-add-trial-start-column-to-stripe-subscriptions.js','5.8','6.10'),(52,'2022-08-03-15-29-add-trial-end-column-to-stripe-subscriptions.js','5.8','6.10'),(53,'2022-08-09-08-32-added-new-integration-type.js','5.9','6.10'),(54,'2022-08-15-05-34-add-expiry-at-column-to-members-products.js','5.10','6.10'),(55,'2022-08-16-14-25-add-member-created-events-table.js','5.10','6.10'),(56,'2022-08-16-14-25-add-subscription-created-events-table.js','5.10','6.10'),(57,'2022-08-19-14-15-fix-comments-deletion-strategy.js','5.10','6.10'),(58,'2022-08-22-11-03-add-member-alert-settings-columns-to-users.js','5.11','6.10'),(59,'2022-08-23-13-41-backfill-members-created-events.js','5.11','6.10'),(60,'2022-08-23-13-59-fix-page-resource-type.js','5.11','6.10'),(61,'2022-09-02-12-55-rename-members-bio-to-expertise.js','5.14','6.10'),(62,'2022-09-12-16-10-add-posts-lexical-column.js','5.15','6.10'),(63,'2022-09-14-12-46-add-email-track-clicks-setting.js','5.15','6.10'),(64,'2022-09-16-08-22-add-post-revisions-table.js','5.15','6.10'),(65,'2022-09-19-09-04-add-link-redirects-table.js','5.16','6.10'),(66,'2022-09-19-09-05-add-members-link-click-events-table.js','5.16','6.10'),(67,'2022-09-19-17-44-add-referrer-columns-to-member-events-table.js','5.16','6.10'),(68,'2022-09-19-17-44-add-referrer-columns-to-subscription-events-table.js','5.16','6.10'),(69,'2022-09-27-13-53-remove-click-tracking-tables.js','5.17','6.10'),(70,'2022-09-27-13-55-add-redirects-table.js','5.17','6.10'),(71,'2022-09-27-13-56-add-members-click-events-table.js','5.17','6.10'),(72,'2022-09-27-16-49-set-track-clicks-based-on-opens.js','5.17','6.10'),(73,'2022-09-29-12-39-add-track-clicks-column-to-emails.js','5.17','6.10'),(74,'2022-09-02-20-25-add-columns-to-products-table.js','5.19','6.10'),(75,'2022-09-02-20-52-backfill-new-product-columns.js','5.19','6.10'),(76,'2022-10-10-06-58-add-subscriptions-table.js','5.19','6.10'),(77,'2022-10-10-10-05-add-members-feedback-table.js','5.19','6.10'),(78,'2022-10-11-10-38-add-feedback-enabled-column-to-newsletters.js','5.19','6.10'),(79,'2022-10-18-05-39-drop-nullable-tier-id.js','5.20','6.10'),(80,'2022-10-18-10-13-add-ghost-subscription-id-column-to-mscs.js','5.20','6.10'),(81,'2022-10-19-11-17-add-link-browse-permissions.js','5.20','6.10'),(82,'2022-10-20-02-52-add-link-edit-permissions.js','5.20','6.10'),(83,'2022-10-24-07-23-disable-feedback-enabled.js','5.21','6.10'),(84,'2022-10-25-12-05-backfill-missed-products-columns.js','5.21','6.10'),(85,'2022-10-26-04-49-add-batch-id-members-created-events.js','5.21','6.10'),(86,'2022-10-26-04-49-add-batch-id-subscription-created-events.js','5.21','6.10'),(87,'2022-10-26-04-50-member-subscription-created-batch-id.js','5.21','6.10'),(88,'2022-10-26-09-32-add-feedback-enabled-column-to-emails.js','5.21','6.10'),(89,'2022-10-27-09-50-add-member-track-source-setting.js','5.21','6.10'),(90,'2022-10-31-12-03-backfill-new-product-columns.js','5.22','6.10'),(91,'2022-11-21-09-32-add-source-columns-to-emails-table.js','5.24','6.10'),(92,'2022-11-21-15-03-populate-source-column-with-html-for-emails.js','5.24','6.10'),(93,'2022-11-21-15-57-add-error-columns-for-email-batches.js','5.24','6.10'),(94,'2022-11-24-10-36-add-suppressions-table.js','5.25','6.10'),(95,'2022-11-24-10-37-add-email-spam-complaint-events-table.js','5.25','6.10'),(96,'2022-11-29-08-30-add-error-recipient-failures-table.js','5.25','6.10'),(97,'2022-12-13-16-15-add-usage-colums-to-tokens.js','5.27','6.10'),(98,'2023-01-04-04-12-drop-suppressions-table.js','5.27','6.10'),(99,'2023-01-04-04-13-add-suppressions-table.js','5.27','6.10'),(100,'2023-01-05-15-13-add-active-theme-permissions.js','5.28','6.10'),(101,'2023-01-11-02-45-truncate-suppressions.js','5.29','6.10'),(102,'2023-01-13-04-25-unsubscribe-suppressed-emails.js','5.30','6.10'),(103,'2022-12-05-09-56-update-newsletter-subscriptions.js','5.31','6.10'),(104,'2023-01-17-14-59-add-outbound-link-tagging-setting.js','5.31','6.10'),(105,'2023-01-19-07-46-add-mentions-table.js','5.31','6.10'),(106,'2023-01-24-08-00-fix-invalid-tier-expiry-for-paid-members.js','5.32','6.10'),(107,'2023-01-24-08-09-restore-incorrect-expired-tiers-for-members.js','5.32','6.10'),(108,'2023-01-30-07-27-add-mentions-permission.js','5.34','6.10'),(109,'2023-02-08-03-08-add-mentions-notifications-column.js','5.34','6.10'),(110,'2023-02-08-22-32-add-mentions-delete-column.js','5.34','6.10'),(111,'2023-02-13-06-24-add-mentions-verified-column.js','5.35','6.10'),(112,'2023-02-20-12-22-add-milestones-table.js','5.36','6.10'),(113,'2023-02-21-12-29-add-milestone-notifications-column.js','5.36','6.10'),(114,'2023-02-23-10-40-set-outbound-link-tagging-based-on-source-tracking.js','5.36','6.10'),(115,'2023-03-13-09-29-add-newsletter-show-post-title-section.js','5.39','6.10'),(116,'2023-03-13-13-11-add-newsletter-show-comment-cta.js','5.39','6.10'),(117,'2023-03-13-14-30-add-newsletter-show-subscription-details.js','5.39','6.10'),(118,'2023-03-14-12-26-add-last-mentions-email-report-timestamp-setting.js','5.39','6.10'),(119,'2023-03-13-14-05-add-newsletter-show-latest-posts.js','5.40','6.10'),(120,'2023-03-21-18-42-add-self-serve-integration-role.js','5.40','6.10'),(121,'2023-03-21-18-43-add-self-serve-migration-and-permissions.js','5.40','6.10'),(122,'2023-03-21-18-52-add-self-serve-integration.js','5.40','6.10'),(123,'2023-03-21-19-02-add-self-serve-integration-api-key.js','5.40','6.10'),(124,'2023-03-27-15-00-add-newsletter-colors.js','5.41','6.10'),(125,'2023-03-27-17-51-fix-self-serve-integration-api-key-type.js','5.41','6.10'),(126,'2023-04-04-07-03-add-portal-terms-settings.js','5.42','6.10'),(127,'2023-04-14-04-17-add-snippets-lexical-column.js','5.44','6.10'),(128,'2023-04-17-11-05-add-post-revision-author.js','5.45','6.10'),(129,'2023-04-18-12-56-add-announcement-settings.js','5.45','6.10'),(130,'2023-04-19-13-45-add-pintura-settings.js','5.45','6.10'),(131,'2023-04-20-14-19-add-announcement-visibility-setting.js','5.45','6.10'),(132,'2023-04-21-08-54-add-post-revision-status.js','5.45','6.10'),(133,'2023-04-21-10-30-add-feature-image-to-revisions.js','5.45','6.10'),(134,'2023-04-21-13-01-add-feature-image-meta-to-post-revisions.js','5.45','6.10'),(135,'2023-05-30-19-03-update-pintura-setting.js','5.51','6.10'),(136,'2023-06-07-10-17-add-collections-crud-persmissions.js','5.51','6.10'),(137,'2023-06-13-12-24-add-temp-mail-events-table.js','5.53','6.10'),(138,'2023-06-20-10-18-add-collections-table.js','5.53','6.10'),(139,'2023-06-20-10-19-add-collections-posts-table.js','5.53','6.10'),(140,'2023-07-07-11-57-add-show-title-and-feature-image-column-to-posts.js','5.54','6.10'),(141,'2023-07-10-05-15-55-add-built-in-collections.js','5.55','6.10'),(142,'2023-07-10-05-16-55-add-built-in-collection-posts.js','5.55','6.10'),(143,'2023-07-14-10-11-12-add-email-disabled-field-to-members.js','5.56','6.10'),(144,'2023-07-15-10-11-12-update-members-email-disabled-field.js','5.56','6.10'),(145,'2023-07-26-12-44-stripe-products-nullable-product.js','5.57','6.10'),(146,'2023-07-27-11-47-49-create-donation-events.js','5.57','6.10'),(147,'2023-08-02-09-42-add-donation-settings.js','5.58','6.10'),(148,'2023-08-07-10-42-add-donation-notifications-column.js','5.59','6.10'),(149,'2023-08-07-11-17-05-add-posts-published-at-index.js','5.59','6.10'),(150,'2023-08-29-10-17-add-recommendations-crud-permissions.js','5.61','6.10'),(151,'2023-08-29-11-39-10-add-recommendations-table.js','5.61','6.10'),(152,'2023-08-30-07-37-04-add-recommendations-enabled-settings.js','5.61','6.10'),(153,'2023-09-12-11-22-10-add-recommendation-click-events-table.js','5.63','6.10'),(154,'2023-09-12-11-22-11-add-recommendation-subscribe-events-table.js','5.63','6.10'),(155,'2023-09-13-13-03-10-add-ghost-core-content-integration.js','5.63','6.10'),(156,'2023-09-13-13-34-11-add-ghost-core-content-integration-key.js','5.63','6.10'),(157,'2023-09-19-04-25-40-truncate-stale-built-in-collections-posts.js','5.64','6.10'),(158,'2023-09-19-04-34-10-repopulate-built-in-collection-posts.js','5.64','6.10'),(159,'2023-09-22-06-42-15-truncate-stale-built-in-collections-posts.js','5.65','6.10'),(160,'2023-09-22-06-42-55-repopulate-built-in-featured-collection-posts.js','5.65','6.10'),(161,'2023-09-22-14-15-add-recommendation-notifications-column.js','5.66','6.10'),(162,'2023-10-03-00-32-32-rollback-source-theme.js','5.67','6.10'),(163,'2023-10-06-15-06-00-rename-recommendations-reason-to-description.js','5.69','6.10'),(164,'2023-10-31-11-06-00-members-created-attribution-id-index.js','5.72','6.10'),(165,'2023-10-31-11-06-01-members-subscription-created-attribution-id-index.js','5.72','6.10'),(166,'2023-11-14-11-15-00-add-transient-id-column-nullable.js','5.74','6.10'),(167,'2023-11-14-11-16-00-fill-transient-id-column.js','5.74','6.10'),(168,'2023-11-14-11-17-00-drop-nullable-transient-id-column.js','5.74','6.10'),(169,'2023-11-27-15-55-add-members-newsletters-index.js','5.75','6.10'),(170,'2023-12-05-11-00-add-portal-default-plan-setting.js','5.76','6.10'),(171,'2024-01-30-19-36-44-fix-discrepancy-in-free-tier-visibility.js','5.79','6.10'),(172,'2024-03-18-16-20-add-missing-post-permissions.js','5.81','6.10'),(173,'2024-03-25-16-46-10-add-email-recipients-email-id-indexes.js','5.82','6.10'),(174,'2024-03-25-16-51-29-drop-email-recipients-non-email-id-indexes.js','5.82','6.10'),(175,'2024-05-28-02-20-55-add-show-subhead-column-newsletters.js','5.83','6.10'),(176,'2024-06-04-09-13-33-rename-newsletters-show-subhead.js','5.84','6.10'),(177,'2024-06-04-11-10-37-add-custom-excerpt-to-post-revisions.js','5.84','6.10'),(178,'2024-06-05-08-42-34-populate-post-revisions-custom-excerpt.js','5.84','6.10'),(179,'2024-06-05-13-48-35-rename-newsletters-show-subtitle.js','5.84','6.10'),(180,'2024-06-10-14-53-31-add-posts-updated-at-index.js','5.85','6.10'),(181,'2024-06-25-12-08-20-add-posts-tags-post-tag-index.js','5.87','6.10'),(182,'2024-06-25-12-08-45-add-posts-type-status-updated-at-index.js','5.87','6.10'),(183,'2024-07-30-19-51-06-backfill-offer-redemptions.js','5.89','6.10'),(184,'2024-08-20-09-40-24-update-default-donations-suggested-amount.js','5.90','6.10'),(185,'2024-08-28-05-28-22-add-donation-message-column-to-donation-payment-events.js','5.91','6.10'),(186,'2024-09-03-18-51-01-update-stripe-prices-nickname-length.js','5.93','6.10'),(187,'2024-09-03-20-09-40-null-analytics-jobs-timings.js','5.94','6.10'),(188,'2024-10-08-14-25-27-added-body-font-settings.js','5.97','6.10'),(189,'2024-10-08-14-36-58-added-heading-font-setting.js','5.97','6.10'),(190,'2024-10-09-14-04-10-add-session-verification-field.js','5.97','6.10'),(191,'2024-10-10-01-02-03-add-signin-urls-permissions.js','5.97','6.10'),(192,'2024-10-31-15-27-42-add-jobs-queue-columns.js','5.100','6.10'),(193,'2024-11-05-14-48-08-add-comments-in-reply-to-id.js','5.100','6.10'),(194,'2024-11-06-04-45-15-add-activitypub-integration.js','5.100','6.10'),(195,'2024-12-02-17-32-40-alter-length-redirects-from.js','5.102','6.10'),(196,'2024-12-02-17-48-40-add-index-redirects-from.js','5.102','6.10'),(197,'2025-01-23-02-51-10-add-blocked-email-domains-setting.js','5.108','6.10'),(198,'2025-03-05-16-36-39-add-captcha-setting.js','5.111','6.10'),(199,'2025-03-10-10-01-01-add-require-mfa-setting.js','5.112','6.10'),(200,'2025-03-07-12-24-00-add-super-editor.js','5.113','6.10'),(201,'2025-03-07-12-25-00-add-member-perms-to-super-editor.js','5.113','6.10'),(202,'2025-03-19-03-13-04-add-index-to-posts-uuid.js','5.114','6.10'),(203,'2025-03-24-07-19-27-add-identity-read-permission-to-administrators.js','5.115','6.10'),(204,'2025-04-14-02-36-30-add-additional-social-accounts-columns-to-user-table.js','5.117','6.10'),(205,'2025-04-30-13-01-28-remove-captcha-setting.js','5.119','6.10'),(206,'2025-05-07-14-57-38-add-newsletters-button-corners-column.js','5.120','6.10'),(207,'2025-05-13-17-36-56-add-newsletters-button-style-column.js','5.120','6.10'),(208,'2025-05-14-20-00-15-add-newsletters-setting-columns.js','5.120','6.10'),(209,'2025-05-26-08-59-26-drop-newsletters-border-color-column.js','5.121','6.10'),(210,'2025-05-26-09-10-30-rename-newsletters-title-color-column.js','5.121','6.10'),(211,'2025-05-26-12-03-24-add-newsletters-color-columns.js','5.121','6.10'),(212,'2025-05-29-08-41-04-add-member-export-permissions-to-backup-integration.js','5.121','6.10'),(213,'2025-06-03-19-32-57-change-default-for-newsletters-button-color.js','5.122','6.10'),(214,'2025-06-06-23-12-11-create-site-uuid-setting.js','5.124','6.10'),(215,'2025-06-12-14-18-27-add-email-disabled-index.js','5.126','6.10'),(216,'2025-06-12-14-18-57-add-mse-newsletter-created-index.js','5.126','6.10'),(217,'2025-06-18-11-35-41-change-newsletters-link-color-default-to-accent.js','5.126','6.10'),(218,'2025-06-18-11-36-00-update-newsletters-link-color-null-to-accent.js','5.126','6.10'),(219,'2025-06-19-13-41-54-add-web-analytics-setting.js','5.127','6.10'),(220,'2025-06-26-09-36-41-add-social-web-setting.js','5.128','6.10'),(221,'2025-07-11-14-14-54-add-explore-settings.js','5.130','6.10'),(222,'2025-06-20-01-41-54-remove-updated-by-column.js','6.0','6.10'),(223,'2025-06-20-13-41-55-remove-created-by-column.js','6.0','6.10'),(224,'2025-06-23-09-49-25-add-missing-member-uuids.js','6.0','6.10'),(225,'2025-06-23-10-03-26-members-nullable-uuid.js','6.0','6.10'),(226,'2025-06-24-09-19-42-use-object-id-for-hardcoded-user-id.js','6.0','6.10'),(227,'2025-06-25-15-03-29-remove-amp-from-settings.js','6.0','6.10'),(228,'2025-06-30-13-59-10-remove-mail-events-table.js','6.0','6.10'),(229,'2025-06-30-14-00-00-update-feature-image-alt-length.js','6.0','6.10'),(230,'2025-09-11-00-38-13-add-uuid-column-to-tokens.js','6.1','6.10'),(231,'2025-09-11-00-39-08-backfill-tokens-uuid.js','6.1','6.10'),(232,'2025-09-11-00-39-36-tokens-drop-nullable-uuid.js','6.1','6.10'),(233,'2025-09-30-14-28-09-add-utm-fields.js','6.2','6.10'),(234,'2025-10-02-15-13-31-add-members-otc-secret-setting.js','6.3','6.10'),(235,'2025-10-13-10-18-38-add-tokens-otc-used-count-column.js','6.4','6.10'),(236,'2025-11-02-18-29-37-add-outbox-table.js','6.7','6.10'),(237,'2025-11-03-15-17-05-add-csd-email-count.js','6.7','6.10'),(238,'2025-11-03-15-18-04-add-email-batch-fallback-domain.js','6.7','6.10'),(239,'2025-12-01-21-04-36-add-automated-emails-table.js','6.10','6.10'),(240,'2025-12-01-21-04-37-add-automated-email-permissions.js','6.10','6.10');
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations_lock`
--

DROP TABLE IF EXISTS `migrations_lock`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations_lock` (
  `lock_key` varchar(191) NOT NULL,
  `locked` tinyint(1) DEFAULT '0',
  `acquired_at` datetime DEFAULT NULL,
  `released_at` datetime DEFAULT NULL,
  PRIMARY KEY (`lock_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations_lock`
--

LOCK TABLES `migrations_lock` WRITE;
/*!40000 ALTER TABLE `migrations_lock` DISABLE KEYS */;
INSERT INTO `migrations_lock` VALUES ('km01',0,'2025-12-27 00:20:50','2025-12-27 00:20:54');
/*!40000 ALTER TABLE `migrations_lock` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `milestones`
--

DROP TABLE IF EXISTS `milestones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `milestones` (
  `id` varchar(24) NOT NULL,
  `type` varchar(24) NOT NULL,
  `value` int NOT NULL,
  `currency` varchar(24) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `email_sent_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `milestones`
--

LOCK TABLES `milestones` WRITE;
/*!40000 ALTER TABLE `milestones` DISABLE KEYS */;
INSERT INTO `milestones` VALUES ('694f2c047f4d7d685707e3ef','members',0,NULL,'2025-12-27 00:44:52',NULL);
/*!40000 ALTER TABLE `milestones` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mobiledoc_revisions`
--

DROP TABLE IF EXISTS `mobiledoc_revisions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mobiledoc_revisions` (
  `id` varchar(24) NOT NULL,
  `post_id` varchar(24) NOT NULL,
  `mobiledoc` longtext,
  `created_at_ts` bigint NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `mobiledoc_revisions_post_id_index` (`post_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mobiledoc_revisions`
--

LOCK TABLES `mobiledoc_revisions` WRITE;
/*!40000 ALTER TABLE `mobiledoc_revisions` DISABLE KEYS */;
INSERT INTO `mobiledoc_revisions` VALUES ('694f267cc3e44e650f0e60a9','694f2666c3e44e650f0e5e6a','{\"version\":\"0.3.1\",\"atoms\":[],\"cards\":[[\"hr\",{}]],\"markups\":[[\"a\",[\"href\",\"https://ghost.org\"]]],\"sections\":[[1,\"p\",[[0,[],0,\"This is an independent publication. If you subscribe today, you\'ll get full access to the website as well as email newsletters about new content when it\'s available. Your subscription makes this site possible. Thank you!\"]]],[1,\"h3\",[[0,[],0,\"Access all areas\"]]],[1,\"p\",[[0,[],0,\"By signing up, you\'ll get access to the full archive of everything that\'s been published before and everything that\'s still to come. Your very own private library.\"]]],[1,\"h3\",[[0,[],0,\"Fresh content, delivered\"]]],[1,\"p\",[[0,[],0,\"Stay up to date with new content sent straight to your inbox! No more worrying about whether you missed something because of a pesky algorithm or news feed.\"]]],[1,\"h3\",[[0,[],0,\"Meet people like you\"]]],[1,\"p\",[[0,[],0,\"Join a community of other subscribers who share the same interests.\"]]],[10,0],[1,\"h3\",[[0,[],0,\"Start your own thing\"]]],[1,\"p\",[[0,[],0,\"Enjoying the experience? Get started for free and set up your very own subscription business using \"],[0,[0],1,\"Ghost\"],[0,[],0,\", the same platform that powers this website.\"]]]],\"ghostVersion\":\"4.0\"}',1766794876868,'2025-12-27 00:21:16'),('694f267cc3e44e650f0e60aa','694f2666c3e44e650f0e5e6a','{\"version\":\"0.3.1\",\"atoms\":[],\"cards\":[[\"hr\",{}]],\"markups\":[[\"a\",[\"href\",\"https://ghost.org\"]]],\"sections\":[[1,\"p\",[[0,[],0,\"Performance Engineering is an independent publication launched in December 2025 by Manuel A Rodriguez. If you subscribe today, you\'ll get full access to the website as well as email newsletters about new content when it\'s available. Your subscription makes this site possible, and allows Performance Engineering to continue to exist. Thank you!\"]]],[1,\"h3\",[[0,[],0,\"Access all areas\"]]],[1,\"p\",[[0,[],0,\"By signing up, you\'ll get access to the full archive of everything that\'s been published before and everything that\'s still to come. Your very own private library.\"]]],[1,\"h3\",[[0,[],0,\"Fresh content, delivered\"]]],[1,\"p\",[[0,[],0,\"Stay up to date with new content sent straight to your inbox! No more worrying about whether you missed something because of a pesky algorithm or news feed.\"]]],[1,\"h3\",[[0,[],0,\"Meet people like you\"]]],[1,\"p\",[[0,[],0,\"Join a community of other subscribers who share the same interests.\"]]],[10,0],[1,\"h3\",[[0,[],0,\"Start your own thing\"]]],[1,\"p\",[[0,[],0,\"Enjoying the experience? Get started for free and set up your very own subscription business using \"],[0,[0],1,\"Ghost\"],[0,[],0,\", the same platform that powers this website.\"]]]],\"ghostVersion\":\"4.0\"}',1766794876869,'2025-12-27 00:21:16'),('694f2cf47f4d7d685707e40b','694f2cf37f4d7d685707e403','{\"version\":\"0.3.1\",\"atoms\":[],\"cards\":[[\"markdown\",{\"markdown\":\"# Prefer Fewer Fast CPU Cores Over Many Slow Ones for Latency-Sensitive Workloads\\n\\n## Subtitle\\nUnderstanding the trade-off between CPU core count and single-thread performance is critical for optimizing latency-sensitive applications where sequential execution matters more than raw parallelism.\\n\\n## Executive Summary (TL;DR)\\nChoosing fewer fast CPU cores over many slow cores is a performance principle that prioritizes single-thread performance and instruction-level parallelism (IPC) over core count. This approach delivers 20-40% better single-threaded performance, significantly lower latency for critical operations (often reducing response times from 50-100ms to 20-40ms), and improved throughput for applications with sequential dependencies. However, it sacrifices overall parallel throughput and scales poorly for highly concurrent workloads. Use this approach when latency matters more than throughput, for single-threaded applications, or when Amdahl\'s Law limits parallel speedup.\\n\\n## Problem Context\\nA common misconception in performance optimization is that more CPU cores always translate to better performance. Engineers often scale systems horizontally by adding cores without considering single-thread performance characteristics. This leads to scenarios where applications with sequential bottlenecks or latency-sensitive operations underperform despite high core counts.\\n\\nMany production systems suffer from this because modern CPUs designed for high core counts (such as some server-class processors) prioritize parallelism over single-thread speed. These processors trade higher clock frequencies and aggressive out-of-order execution for more cores, resulting in lower IPC (Instructions Per Cycle) and slower individual core performance.\\n\\nNaive scaling attempts often fail because:\\n- Sequential dependencies prevent effective parallelization (Amdahl\'s Law)\\n- Synchronization overhead increases with more cores\\n- Cache coherency traffic scales non-linearly with core count\\n- Critical paths remain bounded by single-thread performance\\n\\n## How It Works\\nCPU performance is determined by three key factors: clock frequency, IPC (Instructions Per Cycle), and core count. Fast cores achieve higher performance through:\\n\\n**Clock Frequency**: Higher clock rates allow more instructions to execute per second. Modern fast cores (e.g., Intel Core series, AMD Ryzen high-frequency variants) run at 4-6 GHz, while many-core processors often operate at 2-3 GHz.\\n\\n**Instruction-Level Parallelism (IPC)**: Fast cores employ deeper pipelines, wider execution units, larger instruction windows, and more aggressive branch prediction. This allows them to extract more parallelism from sequential code, executing multiple independent instructions simultaneously within a single thread.\\n\\n**Cache Hierarchy**: Fast cores typically feature larger, faster L1 and L2 caches per core, reducing memory latency for single-threaded workloads. They also have better prefetching logic that predicts memory access patterns.\\n\\n**Out-of-Order Execution**: Advanced out-of-order execution engines can reorder and parallelize independent instructions within a single thread, effectively creating instruction-level parallelism without explicit multi-threading.\\n\\nWhen a workload has sequential dependencies or Amdahl\'s Law limits parallel speedup, a single fast core can outperform multiple slow cores by completing the critical path faster, even if total theoretical throughput is lower.\\n\\n## Why This Becomes a Bottleneck\\nPerformance degrades when core speed is sacrificed for core count because:\\n\\n**Sequential Bottlenecks**: Every parallel algorithm has sequential portions (data distribution, result aggregation, synchronization). Amdahl\'s Law shows that even 5% sequential code limits speedup to 20x regardless of core count. Fast cores reduce the time spent in sequential sections.\\n\\n**Synchronization Overhead**: More cores require more synchronization primitives (locks, barriers, atomic operations). Each synchronization point introduces latency and serialization. Fast cores reduce the time each thread spends in critical sections, decreasing contention window duration.\\n\\n**Cache Coherency Traffic**: With more cores, cache line invalidation and data movement between caches increase exponentially. Fast cores with better cache locality generate less coherency traffic per unit of work.\\n\\n**Memory Bandwidth Contention**: Multiple slow cores saturate memory bandwidth more easily because each core takes longer to complete operations, keeping memory buses occupied longer. Fast cores complete memory operations faster, freeing bandwidth sooner.\\n\\n**Latency Amplification**: In request-response systems, latency is determined by the slowest path. Even if 99% of work is parallelized, the 1% sequential portion (often I/O or serialization) determines P99 latency. Fast cores reduce this critical path latency.\\n\\n## Advantages\\n- **Superior Single-Thread Performance**: 20-40% better performance on single-threaded workloads compared to many-core processors with lower IPC\\n- **Reduced Latency**: Critical operations complete 50-100% faster (e.g., reducing response times from 50-100ms to 20-40ms in observed benchmarks)\\n- **Lower Synchronization Overhead**: Fewer cores mean fewer lock contentions, atomic operations, and cache coherency messages\\n- **Better Cache Locality**: Larger per-core caches and fewer threads reduce cache misses and improve memory access patterns\\n- **Simpler Architecture**: Less need for complex thread pools, work-stealing schedulers, and parallel algorithms\\n- **Predictable Performance**: More deterministic latency characteristics, crucial for real-time systems\\n- **Higher Throughput for Sequential Workloads**: Applications that cannot be parallelized achieve 15-30% better throughput even with fewer total cores\\n\\n## Disadvantages and Trade-offs\\n- **Limited Parallel Throughput**: Cannot match the total compute capacity of many-core systems for embarrassingly parallel workloads\\n- **Higher Per-Core Cost**: Fast cores with advanced microarchitecture features are more expensive to manufacture\\n- **Poor Scalability for Concurrent Workloads**: Request-per-thread server models (like traditional web servers) benefit less when request count exceeds fast core count\\n- **Lower Total Compute Capacity**: Cannot execute as many independent threads simultaneously\\n- **Underutilization Risk**: If workloads can be fully parallelized, fast cores may sit idle while waiting for I/O, wasting resources\\n- **Memory Bandwidth Limits**: Fewer cores mean fewer memory controllers, potentially limiting memory bandwidth for data-parallel workloads\\n\\n## When to Use This Approach\\n- **Latency-Sensitive Applications**: Real-time systems, trading platforms, gaming servers, interactive applications where P99 latency matters more than throughput\\n- **Sequential Workloads**: Applications with Amdahl\'s Law limits, legacy code that cannot be parallelized, algorithms with strong data dependencies\\n- **Single-Threaded Applications**: Node.js event loops, Python GIL-bound code, JavaScript engines, database query execution (single query optimization)\\n- **Cache-Sensitive Workloads**: Applications where cache locality matters more than parallelism (many scientific computing kernels, graph algorithms)\\n- **I/O-Bound Systems with Critical Paths**: Systems where CPU work per request is minimal but latency is critical (API gateways, load balancers with simple routing logic)\\n- **Development and Testing**: Faster iteration cycles when single-thread performance improves compile times and test execution speed\\n\\n## When Not to Use It\\n- **Highly Parallel Workloads**: Data processing pipelines, batch jobs, scientific simulations with perfect parallelism (no shared state)\\n- **Request-Per-Thread Servers**: Traditional threaded web servers handling thousands of concurrent connections (more cores allow more simultaneous request processing)\\n- **Cost-Optimized Deployments**: When total compute capacity per dollar is the primary metric and latency requirements are relaxed\\n- **Embarrassingly Parallel Problems**: Image processing, video encoding, Monte Carlo simulations where each unit of work is independent\\n- **Cloud Environments with Auto-Scaling**: When horizontal scaling is cheaper than vertical scaling and workload can be distributed\\n- **Containers with Thread Pools**: Applications using thread pools larger than available fast cores, where additional slow cores provide better resource utilization\\n\\n## Performance Impact\\nReal-world observations show:\\n\\n**Latency Improvements**: P50 latency reductions of 30-50% and P99 latency improvements of 40-60% in latency-sensitive applications. For example, a trading system reduced order processing latency from 85ms to 35ms by switching from 32 slow cores to 8 fast cores.\\n\\n**Single-Thread Throughput**: 20-40% improvement in single-threaded benchmarks (SPEC CPU benchmarks show this consistently). JavaScript V8 benchmarks show 25-35% improvements on fast-core architectures.\\n\\n**Sequential Workload Throughput**: Even with fewer total cores, applications with 10-20% sequential code show 15-30% better overall throughput because the critical path completes faster.\\n\\n**Resource Utilization**: Lower CPU utilization (50-70% vs 80-95%) but better response time characteristics, indicating that cores are not the bottleneck but rather single-thread speed.\\n\\n**Energy Efficiency**: Better performance per watt for single-threaded workloads, though total system power may be lower with fewer cores.\\n\\n## Common Mistakes\\n- **Assuming More Cores Always Help**: Adding cores to applications with sequential bottlenecks without profiling to identify the actual bottleneck\\n- **Ignoring Amdahl\'s Law**: Failing to calculate theoretical speedup limits based on sequential code percentage\\n- **Over-Parallelization**: Creating excessive threads that contend for fast cores, leading to context switching overhead that negates single-thread advantages\\n- **Mismatched Architecture Patterns**: Using request-per-thread models (many threads) with fast-core architectures instead of event-driven or async models\\n- **Not Profiling Single-Thread Performance**: Optimizing for multi-threaded scenarios without measuring whether single-thread speed is the actual constraint\\n- **Cache-Unaware Algorithms**: Implementing algorithms that ignore cache locality, wasting the cache advantages of fast cores\\n- **Benchmarking Synthetic Loads**: Testing with perfectly parallel synthetic workloads instead of realistic production traffic patterns\\n\\n## How to Measure and Validate\\n**Profiling Tools**:\\n- Use `perf` (Linux) to measure CPI (Cycles Per Instruction), cache misses, and branch mispredictions\\n- Profile with tools like `vtune` or `perf top` to identify if single-thread performance or parallelism is the bottleneck\\n- Measure IPC metrics: instructions retired per cycle should be higher on fast cores (typically 2-4 IPC vs 1-2 IPC on slow cores)\\n\\n**Key Metrics**:\\n- **Latency Percentiles**: Track P50, P95, P99 latency - fast cores should show lower tail latencies\\n- **Single-Thread Throughput**: Benchmark single-threaded execution time for critical paths\\n- **CPU Utilization**: Lower utilization with better performance indicates single-thread speedup\\n- **Context Switch Rate**: Fewer context switches per request with fast cores\\n- **Cache Hit Rates**: Monitor L1/L2/L3 cache hit ratios - fast cores should show better locality\\n\\n**Benchmarking Strategy**:\\n1. Run single-threaded benchmarks (SPEC CPU, single-threaded application tests)\\n2. Measure critical path latency under production load\\n3. Compare same workload on many-core vs few-core-fast systems\\n4. Use realistic load patterns, not synthetic parallel workloads\\n5. Measure tail latencies, not just averages\\n\\n**Production Validation**:\\n- A/B test with canary deployments comparing core configurations\\n- Monitor application-level metrics (request latency, transaction completion time)\\n- Track system metrics (CPU utilization, context switches, cache performance)\\n- Validate that improvements translate to business metrics (user experience, revenue)\\n\\n## Summary and Key Takeaways\\nThe core principle: **Fewer fast CPU cores outperform many slow cores when single-thread performance matters more than total parallel throughput**. This trade-off is fundamental in CPU architecture and should guide hardware selection and system design.\\n\\nThe main trade-off is between latency/sequential performance and total parallel capacity. Fast cores excel at reducing critical path latency and improving single-thread execution, while many-core systems excel at total throughput for parallelizable workloads.\\n\\n**Decision Guideline**: Choose fast cores when (1) latency requirements are strict (P99 < 100ms), (2) workloads have sequential dependencies (Amdahl\'s Law limits apply), (3) single-thread performance is the bottleneck (profiling confirms), or (4) cache locality matters more than parallelism. Choose many cores when (1) workloads are embarrassingly parallel, (2) total throughput is the primary metric, (3) cost per compute unit is critical, or (4) request-per-thread models handle massive concurrency.\\n\\nAlways profile before deciding: measure IPC, latency percentiles, and identify whether the bottleneck is sequential execution or parallel capacity.\"}]],\"markups\":[],\"sections\":[[10,0]]}',1766796532108,'2025-12-27 00:48:52');
/*!40000 ALTER TABLE `mobiledoc_revisions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `newsletters`
--

DROP TABLE IF EXISTS `newsletters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `newsletters` (
  `id` varchar(24) NOT NULL,
  `uuid` varchar(36) NOT NULL,
  `name` varchar(191) NOT NULL,
  `description` varchar(2000) DEFAULT NULL,
  `feedback_enabled` tinyint(1) NOT NULL DEFAULT '0',
  `slug` varchar(191) NOT NULL,
  `sender_name` varchar(191) DEFAULT NULL,
  `sender_email` varchar(191) DEFAULT NULL,
  `sender_reply_to` varchar(191) NOT NULL DEFAULT 'newsletter',
  `status` varchar(50) NOT NULL DEFAULT 'active',
  `visibility` varchar(50) NOT NULL DEFAULT 'members',
  `subscribe_on_signup` tinyint(1) NOT NULL DEFAULT '1',
  `sort_order` int unsigned NOT NULL DEFAULT '0',
  `header_image` varchar(2000) DEFAULT NULL,
  `show_header_icon` tinyint(1) NOT NULL DEFAULT '1',
  `show_header_title` tinyint(1) NOT NULL DEFAULT '1',
  `show_excerpt` tinyint(1) NOT NULL DEFAULT '0',
  `title_font_category` varchar(191) NOT NULL DEFAULT 'sans_serif',
  `title_alignment` varchar(191) NOT NULL DEFAULT 'center',
  `show_feature_image` tinyint(1) NOT NULL DEFAULT '1',
  `body_font_category` varchar(191) NOT NULL DEFAULT 'sans_serif',
  `footer_content` text,
  `show_badge` tinyint(1) NOT NULL DEFAULT '1',
  `show_header_name` tinyint(1) NOT NULL DEFAULT '1',
  `show_post_title_section` tinyint(1) NOT NULL DEFAULT '1',
  `show_comment_cta` tinyint(1) NOT NULL DEFAULT '1',
  `show_subscription_details` tinyint(1) NOT NULL DEFAULT '0',
  `show_latest_posts` tinyint(1) NOT NULL DEFAULT '0',
  `background_color` varchar(50) NOT NULL DEFAULT 'light',
  `post_title_color` varchar(50) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  `button_corners` varchar(50) NOT NULL DEFAULT 'rounded',
  `button_style` varchar(50) NOT NULL DEFAULT 'fill',
  `title_font_weight` varchar(50) NOT NULL DEFAULT 'bold',
  `link_style` varchar(50) NOT NULL DEFAULT 'underline',
  `image_corners` varchar(50) NOT NULL DEFAULT 'square',
  `header_background_color` varchar(50) NOT NULL DEFAULT 'transparent',
  `section_title_color` varchar(50) DEFAULT NULL,
  `divider_color` varchar(50) DEFAULT NULL,
  `button_color` varchar(50) DEFAULT 'accent',
  `link_color` varchar(50) DEFAULT 'accent',
  PRIMARY KEY (`id`),
  UNIQUE KEY `newsletters_uuid_unique` (`uuid`),
  UNIQUE KEY `newsletters_name_unique` (`name`),
  UNIQUE KEY `newsletters_slug_unique` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `newsletters`
--

LOCK TABLES `newsletters` WRITE;
/*!40000 ALTER TABLE `newsletters` DISABLE KEYS */;
INSERT INTO `newsletters` VALUES ('694f2665c3e44e650f0e5de9','f77efd8b-3657-49c5-a382-350404caa68b','Performance Engineering',NULL,0,'default-newsletter',NULL,NULL,'newsletter','active','members',1,0,NULL,1,1,0,'sans_serif','center',1,'sans_serif',NULL,1,0,1,1,0,0,'light',NULL,'2025-12-27 00:20:53','2025-12-27 00:21:16','rounded','fill','bold','underline','square','transparent',NULL,NULL,'accent','accent');
/*!40000 ALTER TABLE `newsletters` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `offer_redemptions`
--

DROP TABLE IF EXISTS `offer_redemptions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `offer_redemptions` (
  `id` varchar(24) NOT NULL,
  `offer_id` varchar(24) NOT NULL,
  `member_id` varchar(24) NOT NULL,
  `subscription_id` varchar(24) NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `offer_redemptions_offer_id_foreign` (`offer_id`),
  KEY `offer_redemptions_member_id_foreign` (`member_id`),
  KEY `offer_redemptions_subscription_id_foreign` (`subscription_id`),
  CONSTRAINT `offer_redemptions_member_id_foreign` FOREIGN KEY (`member_id`) REFERENCES `members` (`id`) ON DELETE CASCADE,
  CONSTRAINT `offer_redemptions_offer_id_foreign` FOREIGN KEY (`offer_id`) REFERENCES `offers` (`id`) ON DELETE CASCADE,
  CONSTRAINT `offer_redemptions_subscription_id_foreign` FOREIGN KEY (`subscription_id`) REFERENCES `members_stripe_customers_subscriptions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `offer_redemptions`
--

LOCK TABLES `offer_redemptions` WRITE;
/*!40000 ALTER TABLE `offer_redemptions` DISABLE KEYS */;
/*!40000 ALTER TABLE `offer_redemptions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `offers`
--

DROP TABLE IF EXISTS `offers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `offers` (
  `id` varchar(24) NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `name` varchar(191) NOT NULL,
  `code` varchar(191) NOT NULL,
  `product_id` varchar(24) NOT NULL,
  `stripe_coupon_id` varchar(255) DEFAULT NULL,
  `interval` varchar(50) NOT NULL,
  `currency` varchar(50) DEFAULT NULL,
  `discount_type` varchar(50) NOT NULL,
  `discount_amount` int NOT NULL,
  `duration` varchar(50) NOT NULL,
  `duration_in_months` int DEFAULT NULL,
  `portal_title` varchar(191) DEFAULT NULL,
  `portal_description` varchar(2000) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `offers_name_unique` (`name`),
  UNIQUE KEY `offers_code_unique` (`code`),
  UNIQUE KEY `offers_stripe_coupon_id_unique` (`stripe_coupon_id`),
  KEY `offers_product_id_foreign` (`product_id`),
  CONSTRAINT `offers_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `offers`
--

LOCK TABLES `offers` WRITE;
/*!40000 ALTER TABLE `offers` DISABLE KEYS */;
/*!40000 ALTER TABLE `offers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `outbox`
--

DROP TABLE IF EXISTS `outbox`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `outbox` (
  `id` varchar(24) NOT NULL,
  `event_type` varchar(50) NOT NULL,
  `status` varchar(50) NOT NULL DEFAULT 'pending',
  `payload` text NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  `retry_count` int unsigned NOT NULL DEFAULT '0',
  `last_retry_at` datetime DEFAULT NULL,
  `message` varchar(2000) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `outbox_event_type_status_created_at_index` (`event_type`,`status`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `outbox`
--

LOCK TABLES `outbox` WRITE;
/*!40000 ALTER TABLE `outbox` DISABLE KEYS */;
/*!40000 ALTER TABLE `outbox` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `permissions`
--

DROP TABLE IF EXISTS `permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `permissions` (
  `id` varchar(24) NOT NULL,
  `name` varchar(50) NOT NULL,
  `object_type` varchar(50) NOT NULL,
  `action_type` varchar(50) NOT NULL,
  `object_id` varchar(24) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `permissions_name_unique` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permissions`
--

LOCK TABLES `permissions` WRITE;
/*!40000 ALTER TABLE `permissions` DISABLE KEYS */;
INSERT INTO `permissions` VALUES ('694f2665c3e44e650f0e5deb','Read explore data','explore','read',NULL,'2025-12-27 00:20:53','2025-12-27 00:20:53'),('694f2665c3e44e650f0e5dec','Export database','db','exportContent',NULL,'2025-12-27 00:20:53','2025-12-27 00:20:53'),('694f2665c3e44e650f0e5ded','Import database','db','importContent',NULL,'2025-12-27 00:20:53','2025-12-27 00:20:53'),('694f2665c3e44e650f0e5dee','Delete all content','db','deleteAllContent',NULL,'2025-12-27 00:20:53','2025-12-27 00:20:53'),('694f2665c3e44e650f0e5def','Send mail','mail','send',NULL,'2025-12-27 00:20:53','2025-12-27 00:20:53'),('694f2665c3e44e650f0e5df0','Browse notifications','notification','browse',NULL,'2025-12-27 00:20:53','2025-12-27 00:20:53'),('694f2665c3e44e650f0e5df1','Add notifications','notification','add',NULL,'2025-12-27 00:20:53','2025-12-27 00:20:53'),('694f2665c3e44e650f0e5df2','Delete notifications','notification','destroy',NULL,'2025-12-27 00:20:53','2025-12-27 00:20:53'),('694f2665c3e44e650f0e5df3','Browse posts','post','browse',NULL,'2025-12-27 00:20:53','2025-12-27 00:20:53'),('694f2665c3e44e650f0e5df4','Read posts','post','read',NULL,'2025-12-27 00:20:53','2025-12-27 00:20:53'),('694f2665c3e44e650f0e5df5','Edit posts','post','edit',NULL,'2025-12-27 00:20:53','2025-12-27 00:20:53'),('694f2665c3e44e650f0e5df6','Add posts','post','add',NULL,'2025-12-27 00:20:53','2025-12-27 00:20:53'),('694f2665c3e44e650f0e5df7','Delete posts','post','destroy',NULL,'2025-12-27 00:20:53','2025-12-27 00:20:53'),('694f2665c3e44e650f0e5df8','Browse settings','setting','browse',NULL,'2025-12-27 00:20:53','2025-12-27 00:20:53'),('694f2665c3e44e650f0e5df9','Read settings','setting','read',NULL,'2025-12-27 00:20:53','2025-12-27 00:20:53'),('694f2665c3e44e650f0e5dfa','Edit settings','setting','edit',NULL,'2025-12-27 00:20:53','2025-12-27 00:20:53'),('694f2665c3e44e650f0e5dfb','Generate slugs','slug','generate',NULL,'2025-12-27 00:20:53','2025-12-27 00:20:53'),('694f2665c3e44e650f0e5dfc','Browse tags','tag','browse',NULL,'2025-12-27 00:20:53','2025-12-27 00:20:53'),('694f2665c3e44e650f0e5dfd','Read tags','tag','read',NULL,'2025-12-27 00:20:53','2025-12-27 00:20:53'),('694f2665c3e44e650f0e5dfe','Edit tags','tag','edit',NULL,'2025-12-27 00:20:53','2025-12-27 00:20:53'),('694f2665c3e44e650f0e5dff','Add tags','tag','add',NULL,'2025-12-27 00:20:53','2025-12-27 00:20:53'),('694f2665c3e44e650f0e5e00','Delete tags','tag','destroy',NULL,'2025-12-27 00:20:53','2025-12-27 00:20:53'),('694f2665c3e44e650f0e5e01','Browse themes','theme','browse',NULL,'2025-12-27 00:20:53','2025-12-27 00:20:53'),('694f2665c3e44e650f0e5e02','Edit themes','theme','edit',NULL,'2025-12-27 00:20:53','2025-12-27 00:20:53'),('694f2665c3e44e650f0e5e03','Activate themes','theme','activate',NULL,'2025-12-27 00:20:53','2025-12-27 00:20:53'),('694f2665c3e44e650f0e5e04','View active theme details','theme','readActive',NULL,'2025-12-27 00:20:53','2025-12-27 00:20:53'),('694f2665c3e44e650f0e5e05','Upload themes','theme','add',NULL,'2025-12-27 00:20:53','2025-12-27 00:20:53'),('694f2665c3e44e650f0e5e06','Download themes','theme','read',NULL,'2025-12-27 00:20:53','2025-12-27 00:20:53'),('694f2665c3e44e650f0e5e07','Delete themes','theme','destroy',NULL,'2025-12-27 00:20:53','2025-12-27 00:20:53'),('694f2665c3e44e650f0e5e08','Browse users','user','browse',NULL,'2025-12-27 00:20:53','2025-12-27 00:20:53'),('694f2665c3e44e650f0e5e09','Read users','user','read',NULL,'2025-12-27 00:20:53','2025-12-27 00:20:53'),('694f2665c3e44e650f0e5e0a','Edit users','user','edit',NULL,'2025-12-27 00:20:53','2025-12-27 00:20:53'),('694f2665c3e44e650f0e5e0b','Add users','user','add',NULL,'2025-12-27 00:20:53','2025-12-27 00:20:53'),('694f2665c3e44e650f0e5e0c','Delete users','user','destroy',NULL,'2025-12-27 00:20:53','2025-12-27 00:20:53'),('694f2665c3e44e650f0e5e0d','Assign a role','role','assign',NULL,'2025-12-27 00:20:53','2025-12-27 00:20:53'),('694f2665c3e44e650f0e5e0e','Browse roles','role','browse',NULL,'2025-12-27 00:20:53','2025-12-27 00:20:53'),('694f2665c3e44e650f0e5e0f','Browse invites','invite','browse',NULL,'2025-12-27 00:20:53','2025-12-27 00:20:53'),('694f2665c3e44e650f0e5e10','Read invites','invite','read',NULL,'2025-12-27 00:20:53','2025-12-27 00:20:53'),('694f2665c3e44e650f0e5e11','Edit invites','invite','edit',NULL,'2025-12-27 00:20:53','2025-12-27 00:20:53'),('694f2665c3e44e650f0e5e12','Add invites','invite','add',NULL,'2025-12-27 00:20:53','2025-12-27 00:20:53'),('694f2665c3e44e650f0e5e13','Delete invites','invite','destroy',NULL,'2025-12-27 00:20:53','2025-12-27 00:20:53'),('694f2665c3e44e650f0e5e14','Download redirects','redirect','download',NULL,'2025-12-27 00:20:53','2025-12-27 00:20:53'),('694f2665c3e44e650f0e5e15','Upload redirects','redirect','upload',NULL,'2025-12-27 00:20:53','2025-12-27 00:20:53'),('694f2665c3e44e650f0e5e16','Add webhooks','webhook','add',NULL,'2025-12-27 00:20:53','2025-12-27 00:20:53'),('694f2665c3e44e650f0e5e17','Edit webhooks','webhook','edit',NULL,'2025-12-27 00:20:53','2025-12-27 00:20:53'),('694f2665c3e44e650f0e5e18','Delete webhooks','webhook','destroy',NULL,'2025-12-27 00:20:53','2025-12-27 00:20:53'),('694f2665c3e44e650f0e5e19','Browse integrations','integration','browse',NULL,'2025-12-27 00:20:53','2025-12-27 00:20:53'),('694f2665c3e44e650f0e5e1a','Read integrations','integration','read',NULL,'2025-12-27 00:20:53','2025-12-27 00:20:53'),('694f2665c3e44e650f0e5e1b','Edit integrations','integration','edit',NULL,'2025-12-27 00:20:53','2025-12-27 00:20:53'),('694f2665c3e44e650f0e5e1c','Add integrations','integration','add',NULL,'2025-12-27 00:20:53','2025-12-27 00:20:53'),('694f2665c3e44e650f0e5e1d','Delete integrations','integration','destroy',NULL,'2025-12-27 00:20:53','2025-12-27 00:20:53'),('694f2665c3e44e650f0e5e1e','Browse API keys','api_key','browse',NULL,'2025-12-27 00:20:53','2025-12-27 00:20:53'),('694f2665c3e44e650f0e5e1f','Read API keys','api_key','read',NULL,'2025-12-27 00:20:53','2025-12-27 00:20:53'),('694f2665c3e44e650f0e5e20','Edit API keys','api_key','edit',NULL,'2025-12-27 00:20:53','2025-12-27 00:20:53'),('694f2665c3e44e650f0e5e21','Add API keys','api_key','add',NULL,'2025-12-27 00:20:53','2025-12-27 00:20:53'),('694f2665c3e44e650f0e5e22','Delete API keys','api_key','destroy',NULL,'2025-12-27 00:20:53','2025-12-27 00:20:53'),('694f2665c3e44e650f0e5e23','Browse Actions','action','browse',NULL,'2025-12-27 00:20:53','2025-12-27 00:20:53'),('694f2665c3e44e650f0e5e24','Browse Members','member','browse',NULL,'2025-12-27 00:20:53','2025-12-27 00:20:53'),('694f2665c3e44e650f0e5e25','Read Members','member','read',NULL,'2025-12-27 00:20:53','2025-12-27 00:20:53'),('694f2665c3e44e650f0e5e26','Edit Members','member','edit',NULL,'2025-12-27 00:20:53','2025-12-27 00:20:53'),('694f2665c3e44e650f0e5e27','Add Members','member','add',NULL,'2025-12-27 00:20:53','2025-12-27 00:20:53'),('694f2665c3e44e650f0e5e28','Delete Members','member','destroy',NULL,'2025-12-27 00:20:53','2025-12-27 00:20:53'),('694f2665c3e44e650f0e5e29','Browse Products','product','browse',NULL,'2025-12-27 00:20:53','2025-12-27 00:20:53'),('694f2665c3e44e650f0e5e2a','Read Products','product','read',NULL,'2025-12-27 00:20:53','2025-12-27 00:20:53'),('694f2665c3e44e650f0e5e2b','Edit Products','product','edit',NULL,'2025-12-27 00:20:53','2025-12-27 00:20:53'),('694f2665c3e44e650f0e5e2c','Add Products','product','add',NULL,'2025-12-27 00:20:53','2025-12-27 00:20:53'),('694f2665c3e44e650f0e5e2d','Delete Products','product','destroy',NULL,'2025-12-27 00:20:53','2025-12-27 00:20:53'),('694f2665c3e44e650f0e5e2e','Publish posts','post','publish',NULL,'2025-12-27 00:20:53','2025-12-27 00:20:53'),('694f2665c3e44e650f0e5e2f','Backup database','db','backupContent',NULL,'2025-12-27 00:20:53','2025-12-27 00:20:53'),('694f2665c3e44e650f0e5e30','Email preview','email_preview','read',NULL,'2025-12-27 00:20:53','2025-12-27 00:20:53'),('694f2665c3e44e650f0e5e31','Send test email','email_preview','sendTestEmail',NULL,'2025-12-27 00:20:53','2025-12-27 00:20:53'),('694f2665c3e44e650f0e5e32','Browse emails','email','browse',NULL,'2025-12-27 00:20:53','2025-12-27 00:20:53'),('694f2665c3e44e650f0e5e33','Read emails','email','read',NULL,'2025-12-27 00:20:53','2025-12-27 00:20:53'),('694f2665c3e44e650f0e5e34','Retry emails','email','retry',NULL,'2025-12-27 00:20:53','2025-12-27 00:20:53'),('694f2665c3e44e650f0e5e35','Browse labels','label','browse',NULL,'2025-12-27 00:20:53','2025-12-27 00:20:53'),('694f2665c3e44e650f0e5e36','Read labels','label','read',NULL,'2025-12-27 00:20:53','2025-12-27 00:20:53'),('694f2665c3e44e650f0e5e37','Edit labels','label','edit',NULL,'2025-12-27 00:20:53','2025-12-27 00:20:53'),('694f2665c3e44e650f0e5e38','Add labels','label','add',NULL,'2025-12-27 00:20:53','2025-12-27 00:20:53'),('694f2665c3e44e650f0e5e39','Delete labels','label','destroy',NULL,'2025-12-27 00:20:53','2025-12-27 00:20:53'),('694f2665c3e44e650f0e5e3a','Browse automated emails','automated_email','browse',NULL,'2025-12-27 00:20:53','2025-12-27 00:20:53'),('694f2665c3e44e650f0e5e3b','Read automated emails','automated_email','read',NULL,'2025-12-27 00:20:53','2025-12-27 00:20:53'),('694f2665c3e44e650f0e5e3c','Edit automated emails','automated_email','edit',NULL,'2025-12-27 00:20:53','2025-12-27 00:20:53'),('694f2665c3e44e650f0e5e3d','Add automated emails','automated_email','add',NULL,'2025-12-27 00:20:53','2025-12-27 00:20:53'),('694f2665c3e44e650f0e5e3e','Delete automated emails','automated_email','destroy',NULL,'2025-12-27 00:20:53','2025-12-27 00:20:53'),('694f2665c3e44e650f0e5e3f','Read member signin urls','member_signin_url','read',NULL,'2025-12-27 00:20:53','2025-12-27 00:20:53'),('694f2665c3e44e650f0e5e40','Read identities','identity','read',NULL,'2025-12-27 00:20:53','2025-12-27 00:20:53'),('694f2665c3e44e650f0e5e41','Auth Stripe Connect for Members','members_stripe_connect','auth',NULL,'2025-12-27 00:20:53','2025-12-27 00:20:53'),('694f2665c3e44e650f0e5e42','Browse snippets','snippet','browse',NULL,'2025-12-27 00:20:53','2025-12-27 00:20:53'),('694f2665c3e44e650f0e5e43','Read snippets','snippet','read',NULL,'2025-12-27 00:20:53','2025-12-27 00:20:53'),('694f2665c3e44e650f0e5e44','Edit snippets','snippet','edit',NULL,'2025-12-27 00:20:53','2025-12-27 00:20:53'),('694f2665c3e44e650f0e5e45','Add snippets','snippet','add',NULL,'2025-12-27 00:20:53','2025-12-27 00:20:53'),('694f2665c3e44e650f0e5e46','Delete snippets','snippet','destroy',NULL,'2025-12-27 00:20:53','2025-12-27 00:20:53'),('694f2665c3e44e650f0e5e47','Browse offers','offer','browse',NULL,'2025-12-27 00:20:53','2025-12-27 00:20:53'),('694f2665c3e44e650f0e5e48','Read offers','offer','read',NULL,'2025-12-27 00:20:53','2025-12-27 00:20:53'),('694f2665c3e44e650f0e5e49','Edit offers','offer','edit',NULL,'2025-12-27 00:20:53','2025-12-27 00:20:53'),('694f2665c3e44e650f0e5e4a','Add offers','offer','add',NULL,'2025-12-27 00:20:53','2025-12-27 00:20:53'),('694f2665c3e44e650f0e5e4b','Reset all passwords','authentication','resetAllPasswords',NULL,'2025-12-27 00:20:53','2025-12-27 00:20:53'),('694f2665c3e44e650f0e5e4c','Browse custom theme settings','custom_theme_setting','browse',NULL,'2025-12-27 00:20:53','2025-12-27 00:20:53'),('694f2665c3e44e650f0e5e4d','Edit custom theme settings','custom_theme_setting','edit',NULL,'2025-12-27 00:20:53','2025-12-27 00:20:53'),('694f2665c3e44e650f0e5e4e','Browse newsletters','newsletter','browse',NULL,'2025-12-27 00:20:53','2025-12-27 00:20:53'),('694f2665c3e44e650f0e5e4f','Read newsletters','newsletter','read',NULL,'2025-12-27 00:20:53','2025-12-27 00:20:53'),('694f2665c3e44e650f0e5e50','Add newsletters','newsletter','add',NULL,'2025-12-27 00:20:53','2025-12-27 00:20:53'),('694f2665c3e44e650f0e5e51','Edit newsletters','newsletter','edit',NULL,'2025-12-27 00:20:53','2025-12-27 00:20:53'),('694f2665c3e44e650f0e5e52','Browse comments','comment','browse',NULL,'2025-12-27 00:20:53','2025-12-27 00:20:53'),('694f2665c3e44e650f0e5e53','Read comments','comment','read',NULL,'2025-12-27 00:20:53','2025-12-27 00:20:53'),('694f2665c3e44e650f0e5e54','Edit comments','comment','edit',NULL,'2025-12-27 00:20:53','2025-12-27 00:20:53'),('694f2665c3e44e650f0e5e55','Add comments','comment','add',NULL,'2025-12-27 00:20:53','2025-12-27 00:20:53'),('694f2665c3e44e650f0e5e56','Delete comments','comment','destroy',NULL,'2025-12-27 00:20:53','2025-12-27 00:20:53'),('694f2665c3e44e650f0e5e57','Moderate comments','comment','moderate',NULL,'2025-12-27 00:20:53','2025-12-27 00:20:53'),('694f2665c3e44e650f0e5e58','Like comments','comment','like',NULL,'2025-12-27 00:20:53','2025-12-27 00:20:53'),('694f2665c3e44e650f0e5e59','Unlike comments','comment','unlike',NULL,'2025-12-27 00:20:53','2025-12-27 00:20:53'),('694f2665c3e44e650f0e5e5a','Report comments','comment','report',NULL,'2025-12-27 00:20:53','2025-12-27 00:20:53'),('694f2665c3e44e650f0e5e5b','Browse links','link','browse',NULL,'2025-12-27 00:20:53','2025-12-27 00:20:53'),('694f2665c3e44e650f0e5e5c','Edit links','link','edit',NULL,'2025-12-27 00:20:53','2025-12-27 00:20:53'),('694f2665c3e44e650f0e5e5d','Browse mentions','mention','browse',NULL,'2025-12-27 00:20:53','2025-12-27 00:20:53'),('694f2665c3e44e650f0e5e5e','Browse collections','collection','browse',NULL,'2025-12-27 00:20:53','2025-12-27 00:20:53'),('694f2665c3e44e650f0e5e5f','Read collections','collection','read',NULL,'2025-12-27 00:20:53','2025-12-27 00:20:53'),('694f2665c3e44e650f0e5e60','Edit collections','collection','edit',NULL,'2025-12-27 00:20:53','2025-12-27 00:20:53'),('694f2665c3e44e650f0e5e61','Add collections','collection','add',NULL,'2025-12-27 00:20:53','2025-12-27 00:20:53'),('694f2665c3e44e650f0e5e62','Delete collections','collection','destroy',NULL,'2025-12-27 00:20:53','2025-12-27 00:20:53'),('694f2665c3e44e650f0e5e63','Browse recommendations','recommendation','browse',NULL,'2025-12-27 00:20:53','2025-12-27 00:20:53'),('694f2665c3e44e650f0e5e64','Read recommendations','recommendation','read',NULL,'2025-12-27 00:20:53','2025-12-27 00:20:53'),('694f2665c3e44e650f0e5e65','Edit recommendations','recommendation','edit',NULL,'2025-12-27 00:20:53','2025-12-27 00:20:53'),('694f2665c3e44e650f0e5e66','Add recommendations','recommendation','add',NULL,'2025-12-27 00:20:53','2025-12-27 00:20:53'),('694f2665c3e44e650f0e5e67','Delete recommendations','recommendation','destroy',NULL,'2025-12-27 00:20:53','2025-12-27 00:20:53');
/*!40000 ALTER TABLE `permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `permissions_roles`
--

DROP TABLE IF EXISTS `permissions_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `permissions_roles` (
  `id` varchar(24) NOT NULL,
  `role_id` varchar(24) NOT NULL,
  `permission_id` varchar(24) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permissions_roles`
--

LOCK TABLES `permissions_roles` WRITE;
/*!40000 ALTER TABLE `permissions_roles` DISABLE KEYS */;
INSERT INTO `permissions_roles` VALUES ('694f2666c3e44e650f0e5e7b','694f2665c3e44e650f0e5dd9','694f2665c3e44e650f0e5dec'),('694f2666c3e44e650f0e5e7c','694f2665c3e44e650f0e5dd9','694f2665c3e44e650f0e5ded'),('694f2666c3e44e650f0e5e7d','694f2665c3e44e650f0e5dd9','694f2665c3e44e650f0e5dee'),('694f2666c3e44e650f0e5e7e','694f2665c3e44e650f0e5dd9','694f2665c3e44e650f0e5e2f'),('694f2666c3e44e650f0e5e7f','694f2665c3e44e650f0e5dd9','694f2665c3e44e650f0e5def'),('694f2666c3e44e650f0e5e80','694f2665c3e44e650f0e5dd9','694f2665c3e44e650f0e5df0'),('694f2666c3e44e650f0e5e81','694f2665c3e44e650f0e5dd9','694f2665c3e44e650f0e5df1'),('694f2666c3e44e650f0e5e82','694f2665c3e44e650f0e5dd9','694f2665c3e44e650f0e5df2'),('694f2666c3e44e650f0e5e83','694f2665c3e44e650f0e5dd9','694f2665c3e44e650f0e5df3'),('694f2666c3e44e650f0e5e84','694f2665c3e44e650f0e5dd9','694f2665c3e44e650f0e5df4'),('694f2666c3e44e650f0e5e85','694f2665c3e44e650f0e5dd9','694f2665c3e44e650f0e5df5'),('694f2666c3e44e650f0e5e86','694f2665c3e44e650f0e5dd9','694f2665c3e44e650f0e5df6'),('694f2666c3e44e650f0e5e87','694f2665c3e44e650f0e5dd9','694f2665c3e44e650f0e5df7'),('694f2666c3e44e650f0e5e88','694f2665c3e44e650f0e5dd9','694f2665c3e44e650f0e5e2e'),('694f2666c3e44e650f0e5e89','694f2665c3e44e650f0e5dd9','694f2665c3e44e650f0e5df8'),('694f2666c3e44e650f0e5e8a','694f2665c3e44e650f0e5dd9','694f2665c3e44e650f0e5df9'),('694f2666c3e44e650f0e5e8b','694f2665c3e44e650f0e5dd9','694f2665c3e44e650f0e5dfa'),('694f2666c3e44e650f0e5e8c','694f2665c3e44e650f0e5dd9','694f2665c3e44e650f0e5dfb'),('694f2666c3e44e650f0e5e8d','694f2665c3e44e650f0e5dd9','694f2665c3e44e650f0e5dfc'),('694f2666c3e44e650f0e5e8e','694f2665c3e44e650f0e5dd9','694f2665c3e44e650f0e5dfd'),('694f2666c3e44e650f0e5e8f','694f2665c3e44e650f0e5dd9','694f2665c3e44e650f0e5dfe'),('694f2666c3e44e650f0e5e90','694f2665c3e44e650f0e5dd9','694f2665c3e44e650f0e5dff'),('694f2666c3e44e650f0e5e91','694f2665c3e44e650f0e5dd9','694f2665c3e44e650f0e5e00'),('694f2666c3e44e650f0e5e92','694f2665c3e44e650f0e5dd9','694f2665c3e44e650f0e5e01'),('694f2666c3e44e650f0e5e93','694f2665c3e44e650f0e5dd9','694f2665c3e44e650f0e5e02'),('694f2666c3e44e650f0e5e94','694f2665c3e44e650f0e5dd9','694f2665c3e44e650f0e5e03'),('694f2666c3e44e650f0e5e95','694f2665c3e44e650f0e5dd9','694f2665c3e44e650f0e5e04'),('694f2666c3e44e650f0e5e96','694f2665c3e44e650f0e5dd9','694f2665c3e44e650f0e5e05'),('694f2666c3e44e650f0e5e97','694f2665c3e44e650f0e5dd9','694f2665c3e44e650f0e5e06'),('694f2666c3e44e650f0e5e98','694f2665c3e44e650f0e5dd9','694f2665c3e44e650f0e5e07'),('694f2666c3e44e650f0e5e99','694f2665c3e44e650f0e5dd9','694f2665c3e44e650f0e5e08'),('694f2666c3e44e650f0e5e9a','694f2665c3e44e650f0e5dd9','694f2665c3e44e650f0e5e09'),('694f2666c3e44e650f0e5e9b','694f2665c3e44e650f0e5dd9','694f2665c3e44e650f0e5e0a'),('694f2666c3e44e650f0e5e9c','694f2665c3e44e650f0e5dd9','694f2665c3e44e650f0e5e0b'),('694f2666c3e44e650f0e5e9d','694f2665c3e44e650f0e5dd9','694f2665c3e44e650f0e5e0c'),('694f2666c3e44e650f0e5e9e','694f2665c3e44e650f0e5dd9','694f2665c3e44e650f0e5e0d'),('694f2666c3e44e650f0e5e9f','694f2665c3e44e650f0e5dd9','694f2665c3e44e650f0e5e0e'),('694f2666c3e44e650f0e5ea0','694f2665c3e44e650f0e5dd9','694f2665c3e44e650f0e5e0f'),('694f2666c3e44e650f0e5ea1','694f2665c3e44e650f0e5dd9','694f2665c3e44e650f0e5e10'),('694f2666c3e44e650f0e5ea2','694f2665c3e44e650f0e5dd9','694f2665c3e44e650f0e5e11'),('694f2666c3e44e650f0e5ea3','694f2665c3e44e650f0e5dd9','694f2665c3e44e650f0e5e12'),('694f2666c3e44e650f0e5ea4','694f2665c3e44e650f0e5dd9','694f2665c3e44e650f0e5e13'),('694f2666c3e44e650f0e5ea5','694f2665c3e44e650f0e5dd9','694f2665c3e44e650f0e5e14'),('694f2666c3e44e650f0e5ea6','694f2665c3e44e650f0e5dd9','694f2665c3e44e650f0e5e15'),('694f2666c3e44e650f0e5ea7','694f2665c3e44e650f0e5dd9','694f2665c3e44e650f0e5e16'),('694f2666c3e44e650f0e5ea8','694f2665c3e44e650f0e5dd9','694f2665c3e44e650f0e5e17'),('694f2666c3e44e650f0e5ea9','694f2665c3e44e650f0e5dd9','694f2665c3e44e650f0e5e18'),('694f2666c3e44e650f0e5eaa','694f2665c3e44e650f0e5dd9','694f2665c3e44e650f0e5e19'),('694f2666c3e44e650f0e5eab','694f2665c3e44e650f0e5dd9','694f2665c3e44e650f0e5e1a'),('694f2666c3e44e650f0e5eac','694f2665c3e44e650f0e5dd9','694f2665c3e44e650f0e5e1b'),('694f2666c3e44e650f0e5ead','694f2665c3e44e650f0e5dd9','694f2665c3e44e650f0e5e1c'),('694f2666c3e44e650f0e5eae','694f2665c3e44e650f0e5dd9','694f2665c3e44e650f0e5e1d'),('694f2666c3e44e650f0e5eaf','694f2665c3e44e650f0e5dd9','694f2665c3e44e650f0e5e1e'),('694f2666c3e44e650f0e5eb0','694f2665c3e44e650f0e5dd9','694f2665c3e44e650f0e5e1f'),('694f2666c3e44e650f0e5eb1','694f2665c3e44e650f0e5dd9','694f2665c3e44e650f0e5e20'),('694f2666c3e44e650f0e5eb2','694f2665c3e44e650f0e5dd9','694f2665c3e44e650f0e5e21'),('694f2666c3e44e650f0e5eb3','694f2665c3e44e650f0e5dd9','694f2665c3e44e650f0e5e22'),('694f2666c3e44e650f0e5eb4','694f2665c3e44e650f0e5dd9','694f2665c3e44e650f0e5e23'),('694f2666c3e44e650f0e5eb5','694f2665c3e44e650f0e5dd9','694f2665c3e44e650f0e5e24'),('694f2666c3e44e650f0e5eb6','694f2665c3e44e650f0e5dd9','694f2665c3e44e650f0e5e25'),('694f2666c3e44e650f0e5eb7','694f2665c3e44e650f0e5dd9','694f2665c3e44e650f0e5e26'),('694f2666c3e44e650f0e5eb8','694f2665c3e44e650f0e5dd9','694f2665c3e44e650f0e5e27'),('694f2666c3e44e650f0e5eb9','694f2665c3e44e650f0e5dd9','694f2665c3e44e650f0e5e28'),('694f2666c3e44e650f0e5eba','694f2665c3e44e650f0e5dd9','694f2665c3e44e650f0e5e29'),('694f2666c3e44e650f0e5ebb','694f2665c3e44e650f0e5dd9','694f2665c3e44e650f0e5e2a'),('694f2666c3e44e650f0e5ebc','694f2665c3e44e650f0e5dd9','694f2665c3e44e650f0e5e2b'),('694f2666c3e44e650f0e5ebd','694f2665c3e44e650f0e5dd9','694f2665c3e44e650f0e5e2c'),('694f2666c3e44e650f0e5ebe','694f2665c3e44e650f0e5dd9','694f2665c3e44e650f0e5e2d'),('694f2666c3e44e650f0e5ebf','694f2665c3e44e650f0e5dd9','694f2665c3e44e650f0e5e35'),('694f2666c3e44e650f0e5ec0','694f2665c3e44e650f0e5dd9','694f2665c3e44e650f0e5e36'),('694f2666c3e44e650f0e5ec1','694f2665c3e44e650f0e5dd9','694f2665c3e44e650f0e5e37'),('694f2666c3e44e650f0e5ec2','694f2665c3e44e650f0e5dd9','694f2665c3e44e650f0e5e38'),('694f2666c3e44e650f0e5ec3','694f2665c3e44e650f0e5dd9','694f2665c3e44e650f0e5e39'),('694f2666c3e44e650f0e5ec4','694f2665c3e44e650f0e5dd9','694f2665c3e44e650f0e5e3a'),('694f2666c3e44e650f0e5ec5','694f2665c3e44e650f0e5dd9','694f2665c3e44e650f0e5e3b'),('694f2666c3e44e650f0e5ec6','694f2665c3e44e650f0e5dd9','694f2665c3e44e650f0e5e3c'),('694f2666c3e44e650f0e5ec7','694f2665c3e44e650f0e5dd9','694f2665c3e44e650f0e5e3d'),('694f2666c3e44e650f0e5ec8','694f2665c3e44e650f0e5dd9','694f2665c3e44e650f0e5e3e'),('694f2666c3e44e650f0e5ec9','694f2665c3e44e650f0e5dd9','694f2665c3e44e650f0e5e30'),('694f2666c3e44e650f0e5eca','694f2665c3e44e650f0e5dd9','694f2665c3e44e650f0e5e31'),('694f2666c3e44e650f0e5ecb','694f2665c3e44e650f0e5dd9','694f2665c3e44e650f0e5e32'),('694f2666c3e44e650f0e5ecc','694f2665c3e44e650f0e5dd9','694f2665c3e44e650f0e5e33'),('694f2666c3e44e650f0e5ecd','694f2665c3e44e650f0e5dd9','694f2665c3e44e650f0e5e34'),('694f2666c3e44e650f0e5ece','694f2665c3e44e650f0e5dd9','694f2665c3e44e650f0e5e3f'),('694f2666c3e44e650f0e5ecf','694f2665c3e44e650f0e5dd9','694f2665c3e44e650f0e5e42'),('694f2666c3e44e650f0e5ed0','694f2665c3e44e650f0e5dd9','694f2665c3e44e650f0e5e43'),('694f2666c3e44e650f0e5ed1','694f2665c3e44e650f0e5dd9','694f2665c3e44e650f0e5e44'),('694f2666c3e44e650f0e5ed2','694f2665c3e44e650f0e5dd9','694f2665c3e44e650f0e5e45'),('694f2666c3e44e650f0e5ed3','694f2665c3e44e650f0e5dd9','694f2665c3e44e650f0e5e46'),('694f2666c3e44e650f0e5ed4','694f2665c3e44e650f0e5dd9','694f2665c3e44e650f0e5e4c'),('694f2666c3e44e650f0e5ed5','694f2665c3e44e650f0e5dd9','694f2665c3e44e650f0e5e4d'),('694f2666c3e44e650f0e5ed6','694f2665c3e44e650f0e5dd9','694f2665c3e44e650f0e5e47'),('694f2666c3e44e650f0e5ed7','694f2665c3e44e650f0e5dd9','694f2665c3e44e650f0e5e48'),('694f2666c3e44e650f0e5ed8','694f2665c3e44e650f0e5dd9','694f2665c3e44e650f0e5e49'),('694f2666c3e44e650f0e5ed9','694f2665c3e44e650f0e5dd9','694f2665c3e44e650f0e5e4a'),('694f2666c3e44e650f0e5eda','694f2665c3e44e650f0e5dd9','694f2665c3e44e650f0e5e4b'),('694f2666c3e44e650f0e5edb','694f2665c3e44e650f0e5dd9','694f2665c3e44e650f0e5e41'),('694f2666c3e44e650f0e5edc','694f2665c3e44e650f0e5dd9','694f2665c3e44e650f0e5e4e'),('694f2666c3e44e650f0e5edd','694f2665c3e44e650f0e5dd9','694f2665c3e44e650f0e5e4f'),('694f2666c3e44e650f0e5ede','694f2665c3e44e650f0e5dd9','694f2665c3e44e650f0e5e50'),('694f2666c3e44e650f0e5edf','694f2665c3e44e650f0e5dd9','694f2665c3e44e650f0e5e51'),('694f2666c3e44e650f0e5ee0','694f2665c3e44e650f0e5dd9','694f2665c3e44e650f0e5deb'),('694f2666c3e44e650f0e5ee1','694f2665c3e44e650f0e5dd9','694f2665c3e44e650f0e5e52'),('694f2666c3e44e650f0e5ee2','694f2665c3e44e650f0e5dd9','694f2665c3e44e650f0e5e53'),('694f2666c3e44e650f0e5ee3','694f2665c3e44e650f0e5dd9','694f2665c3e44e650f0e5e54'),('694f2666c3e44e650f0e5ee4','694f2665c3e44e650f0e5dd9','694f2665c3e44e650f0e5e55'),('694f2666c3e44e650f0e5ee5','694f2665c3e44e650f0e5dd9','694f2665c3e44e650f0e5e56'),('694f2666c3e44e650f0e5ee6','694f2665c3e44e650f0e5dd9','694f2665c3e44e650f0e5e57'),('694f2666c3e44e650f0e5ee7','694f2665c3e44e650f0e5dd9','694f2665c3e44e650f0e5e58'),('694f2666c3e44e650f0e5ee8','694f2665c3e44e650f0e5dd9','694f2665c3e44e650f0e5e59'),('694f2666c3e44e650f0e5ee9','694f2665c3e44e650f0e5dd9','694f2665c3e44e650f0e5e5a'),('694f2666c3e44e650f0e5eea','694f2665c3e44e650f0e5dd9','694f2665c3e44e650f0e5e5b'),('694f2666c3e44e650f0e5eeb','694f2665c3e44e650f0e5dd9','694f2665c3e44e650f0e5e5c'),('694f2666c3e44e650f0e5eec','694f2665c3e44e650f0e5dd9','694f2665c3e44e650f0e5e5d'),('694f2666c3e44e650f0e5eed','694f2665c3e44e650f0e5dd9','694f2665c3e44e650f0e5e5e'),('694f2666c3e44e650f0e5eee','694f2665c3e44e650f0e5dd9','694f2665c3e44e650f0e5e5f'),('694f2666c3e44e650f0e5eef','694f2665c3e44e650f0e5dd9','694f2665c3e44e650f0e5e60'),('694f2666c3e44e650f0e5ef0','694f2665c3e44e650f0e5dd9','694f2665c3e44e650f0e5e61'),('694f2666c3e44e650f0e5ef1','694f2665c3e44e650f0e5dd9','694f2665c3e44e650f0e5e62'),('694f2666c3e44e650f0e5ef2','694f2665c3e44e650f0e5dd9','694f2665c3e44e650f0e5e63'),('694f2666c3e44e650f0e5ef3','694f2665c3e44e650f0e5dd9','694f2665c3e44e650f0e5e64'),('694f2666c3e44e650f0e5ef4','694f2665c3e44e650f0e5dd9','694f2665c3e44e650f0e5e65'),('694f2666c3e44e650f0e5ef5','694f2665c3e44e650f0e5dd9','694f2665c3e44e650f0e5e66'),('694f2666c3e44e650f0e5ef6','694f2665c3e44e650f0e5dd9','694f2665c3e44e650f0e5e67'),('694f2666c3e44e650f0e5ef7','694f2665c3e44e650f0e5dd9','694f2665c3e44e650f0e5e40'),('694f2666c3e44e650f0e5ef8','694f2665c3e44e650f0e5de1','694f2665c3e44e650f0e5dec'),('694f2666c3e44e650f0e5ef9','694f2665c3e44e650f0e5de1','694f2665c3e44e650f0e5ded'),('694f2666c3e44e650f0e5efa','694f2665c3e44e650f0e5de1','694f2665c3e44e650f0e5dee'),('694f2666c3e44e650f0e5efb','694f2665c3e44e650f0e5de1','694f2665c3e44e650f0e5e2f'),('694f2666c3e44e650f0e5efc','694f2665c3e44e650f0e5de1','694f2665c3e44e650f0e5e24'),('694f2666c3e44e650f0e5efd','694f2665c3e44e650f0e5de2','694f2665c3e44e650f0e5e2e'),('694f2666c3e44e650f0e5efe','694f2665c3e44e650f0e5ddf','694f2665c3e44e650f0e5deb'),('694f2666c3e44e650f0e5eff','694f2665c3e44e650f0e5de0','694f2665c3e44e650f0e5ded'),('694f2666c3e44e650f0e5f00','694f2665c3e44e650f0e5de0','694f2665c3e44e650f0e5e27'),('694f2666c3e44e650f0e5f01','694f2665c3e44e650f0e5de0','694f2665c3e44e650f0e5dfd'),('694f2666c3e44e650f0e5f02','694f2665c3e44e650f0e5dde','694f2665c3e44e650f0e5def'),('694f2666c3e44e650f0e5f03','694f2665c3e44e650f0e5dde','694f2665c3e44e650f0e5df0'),('694f2666c3e44e650f0e5f04','694f2665c3e44e650f0e5dde','694f2665c3e44e650f0e5df1'),('694f2666c3e44e650f0e5f05','694f2665c3e44e650f0e5dde','694f2665c3e44e650f0e5df2'),('694f2666c3e44e650f0e5f06','694f2665c3e44e650f0e5dde','694f2665c3e44e650f0e5df3'),('694f2666c3e44e650f0e5f07','694f2665c3e44e650f0e5dde','694f2665c3e44e650f0e5df4'),('694f2666c3e44e650f0e5f08','694f2665c3e44e650f0e5dde','694f2665c3e44e650f0e5df5'),('694f2666c3e44e650f0e5f09','694f2665c3e44e650f0e5dde','694f2665c3e44e650f0e5df6'),('694f2666c3e44e650f0e5f0a','694f2665c3e44e650f0e5dde','694f2665c3e44e650f0e5df7'),('694f2666c3e44e650f0e5f0b','694f2665c3e44e650f0e5dde','694f2665c3e44e650f0e5e2e'),('694f2666c3e44e650f0e5f0c','694f2665c3e44e650f0e5dde','694f2665c3e44e650f0e5df8'),('694f2666c3e44e650f0e5f0d','694f2665c3e44e650f0e5dde','694f2665c3e44e650f0e5df9'),('694f2666c3e44e650f0e5f0e','694f2665c3e44e650f0e5dde','694f2665c3e44e650f0e5dfa'),('694f2666c3e44e650f0e5f0f','694f2665c3e44e650f0e5dde','694f2665c3e44e650f0e5dfb'),('694f2666c3e44e650f0e5f10','694f2665c3e44e650f0e5dde','694f2665c3e44e650f0e5dfc'),('694f2666c3e44e650f0e5f11','694f2665c3e44e650f0e5dde','694f2665c3e44e650f0e5dfd'),('694f2666c3e44e650f0e5f12','694f2665c3e44e650f0e5dde','694f2665c3e44e650f0e5dfe'),('694f2666c3e44e650f0e5f13','694f2665c3e44e650f0e5dde','694f2665c3e44e650f0e5dff'),('694f2666c3e44e650f0e5f14','694f2665c3e44e650f0e5dde','694f2665c3e44e650f0e5e00'),('694f2666c3e44e650f0e5f15','694f2665c3e44e650f0e5dde','694f2665c3e44e650f0e5e01'),('694f2666c3e44e650f0e5f16','694f2665c3e44e650f0e5dde','694f2665c3e44e650f0e5e02'),('694f2666c3e44e650f0e5f17','694f2665c3e44e650f0e5dde','694f2665c3e44e650f0e5e03'),('694f2666c3e44e650f0e5f18','694f2665c3e44e650f0e5dde','694f2665c3e44e650f0e5e04'),('694f2666c3e44e650f0e5f19','694f2665c3e44e650f0e5dde','694f2665c3e44e650f0e5e05'),('694f2666c3e44e650f0e5f1a','694f2665c3e44e650f0e5dde','694f2665c3e44e650f0e5e06'),('694f2666c3e44e650f0e5f1b','694f2665c3e44e650f0e5dde','694f2665c3e44e650f0e5e07'),('694f2666c3e44e650f0e5f1c','694f2665c3e44e650f0e5dde','694f2665c3e44e650f0e5e08'),('694f2666c3e44e650f0e5f1d','694f2665c3e44e650f0e5dde','694f2665c3e44e650f0e5e09'),('694f2666c3e44e650f0e5f1e','694f2665c3e44e650f0e5dde','694f2665c3e44e650f0e5e0a'),('694f2666c3e44e650f0e5f1f','694f2665c3e44e650f0e5dde','694f2665c3e44e650f0e5e0b'),('694f2666c3e44e650f0e5f20','694f2665c3e44e650f0e5dde','694f2665c3e44e650f0e5e0c'),('694f2666c3e44e650f0e5f21','694f2665c3e44e650f0e5dde','694f2665c3e44e650f0e5e0d'),('694f2666c3e44e650f0e5f22','694f2665c3e44e650f0e5dde','694f2665c3e44e650f0e5e0e'),('694f2666c3e44e650f0e5f23','694f2665c3e44e650f0e5dde','694f2665c3e44e650f0e5e0f'),('694f2666c3e44e650f0e5f24','694f2665c3e44e650f0e5dde','694f2665c3e44e650f0e5e10'),('694f2666c3e44e650f0e5f25','694f2665c3e44e650f0e5dde','694f2665c3e44e650f0e5e11'),('694f2666c3e44e650f0e5f26','694f2665c3e44e650f0e5dde','694f2665c3e44e650f0e5e12'),('694f2666c3e44e650f0e5f27','694f2665c3e44e650f0e5dde','694f2665c3e44e650f0e5e13'),('694f2666c3e44e650f0e5f28','694f2665c3e44e650f0e5dde','694f2665c3e44e650f0e5e14'),('694f2666c3e44e650f0e5f29','694f2665c3e44e650f0e5dde','694f2665c3e44e650f0e5e15'),('694f2666c3e44e650f0e5f2a','694f2665c3e44e650f0e5dde','694f2665c3e44e650f0e5e16'),('694f2666c3e44e650f0e5f2b','694f2665c3e44e650f0e5dde','694f2665c3e44e650f0e5e17'),('694f2666c3e44e650f0e5f2c','694f2665c3e44e650f0e5dde','694f2665c3e44e650f0e5e18'),('694f2666c3e44e650f0e5f2d','694f2665c3e44e650f0e5dde','694f2665c3e44e650f0e5e23'),('694f2666c3e44e650f0e5f2e','694f2665c3e44e650f0e5dde','694f2665c3e44e650f0e5e24'),('694f2666c3e44e650f0e5f2f','694f2665c3e44e650f0e5dde','694f2665c3e44e650f0e5e25'),('694f2666c3e44e650f0e5f30','694f2665c3e44e650f0e5dde','694f2665c3e44e650f0e5e26'),('694f2666c3e44e650f0e5f31','694f2665c3e44e650f0e5dde','694f2665c3e44e650f0e5e27'),('694f2666c3e44e650f0e5f32','694f2665c3e44e650f0e5dde','694f2665c3e44e650f0e5e28'),('694f2666c3e44e650f0e5f33','694f2665c3e44e650f0e5dde','694f2665c3e44e650f0e5e35'),('694f2666c3e44e650f0e5f34','694f2665c3e44e650f0e5dde','694f2665c3e44e650f0e5e36'),('694f2666c3e44e650f0e5f35','694f2665c3e44e650f0e5dde','694f2665c3e44e650f0e5e37'),('694f2666c3e44e650f0e5f36','694f2665c3e44e650f0e5dde','694f2665c3e44e650f0e5e38'),('694f2666c3e44e650f0e5f37','694f2665c3e44e650f0e5dde','694f2665c3e44e650f0e5e39'),('694f2666c3e44e650f0e5f38','694f2665c3e44e650f0e5dde','694f2665c3e44e650f0e5e3a'),('694f2666c3e44e650f0e5f39','694f2665c3e44e650f0e5dde','694f2665c3e44e650f0e5e3b'),('694f2666c3e44e650f0e5f3a','694f2665c3e44e650f0e5dde','694f2665c3e44e650f0e5e3c'),('694f2666c3e44e650f0e5f3b','694f2665c3e44e650f0e5dde','694f2665c3e44e650f0e5e3d'),('694f2666c3e44e650f0e5f3c','694f2665c3e44e650f0e5dde','694f2665c3e44e650f0e5e3e'),('694f2666c3e44e650f0e5f3d','694f2665c3e44e650f0e5dde','694f2665c3e44e650f0e5e30'),('694f2666c3e44e650f0e5f3e','694f2665c3e44e650f0e5dde','694f2665c3e44e650f0e5e31'),('694f2666c3e44e650f0e5f3f','694f2665c3e44e650f0e5dde','694f2665c3e44e650f0e5e32'),('694f2666c3e44e650f0e5f40','694f2665c3e44e650f0e5dde','694f2665c3e44e650f0e5e33'),('694f2666c3e44e650f0e5f41','694f2665c3e44e650f0e5dde','694f2665c3e44e650f0e5e34'),('694f2666c3e44e650f0e5f42','694f2665c3e44e650f0e5dde','694f2665c3e44e650f0e5e42'),('694f2666c3e44e650f0e5f43','694f2665c3e44e650f0e5dde','694f2665c3e44e650f0e5e43'),('694f2666c3e44e650f0e5f44','694f2665c3e44e650f0e5dde','694f2665c3e44e650f0e5e44'),('694f2666c3e44e650f0e5f45','694f2665c3e44e650f0e5dde','694f2665c3e44e650f0e5e45'),('694f2666c3e44e650f0e5f46','694f2665c3e44e650f0e5dde','694f2665c3e44e650f0e5e46'),('694f2666c3e44e650f0e5f47','694f2665c3e44e650f0e5dde','694f2665c3e44e650f0e5e29'),('694f2666c3e44e650f0e5f48','694f2665c3e44e650f0e5dde','694f2665c3e44e650f0e5e2a'),('694f2666c3e44e650f0e5f49','694f2665c3e44e650f0e5dde','694f2665c3e44e650f0e5e2b'),('694f2666c3e44e650f0e5f4a','694f2665c3e44e650f0e5dde','694f2665c3e44e650f0e5e2c'),('694f2666c3e44e650f0e5f4b','694f2665c3e44e650f0e5dde','694f2665c3e44e650f0e5e47'),('694f2666c3e44e650f0e5f4c','694f2665c3e44e650f0e5dde','694f2665c3e44e650f0e5e48'),('694f2666c3e44e650f0e5f4d','694f2665c3e44e650f0e5dde','694f2665c3e44e650f0e5e49'),('694f2666c3e44e650f0e5f4e','694f2665c3e44e650f0e5dde','694f2665c3e44e650f0e5e4a'),('694f2666c3e44e650f0e5f4f','694f2665c3e44e650f0e5dde','694f2665c3e44e650f0e5e4e'),('694f2666c3e44e650f0e5f50','694f2665c3e44e650f0e5dde','694f2665c3e44e650f0e5e4f'),('694f2666c3e44e650f0e5f51','694f2665c3e44e650f0e5dde','694f2665c3e44e650f0e5e50'),('694f2666c3e44e650f0e5f52','694f2665c3e44e650f0e5dde','694f2665c3e44e650f0e5e51'),('694f2666c3e44e650f0e5f53','694f2665c3e44e650f0e5dde','694f2665c3e44e650f0e5deb'),('694f2666c3e44e650f0e5f54','694f2665c3e44e650f0e5dde','694f2665c3e44e650f0e5e52'),('694f2666c3e44e650f0e5f55','694f2665c3e44e650f0e5dde','694f2665c3e44e650f0e5e53'),('694f2666c3e44e650f0e5f56','694f2665c3e44e650f0e5dde','694f2665c3e44e650f0e5e54'),('694f2666c3e44e650f0e5f57','694f2665c3e44e650f0e5dde','694f2665c3e44e650f0e5e55'),('694f2666c3e44e650f0e5f58','694f2665c3e44e650f0e5dde','694f2665c3e44e650f0e5e56'),('694f2666c3e44e650f0e5f59','694f2665c3e44e650f0e5dde','694f2665c3e44e650f0e5e57'),('694f2666c3e44e650f0e5f5a','694f2665c3e44e650f0e5dde','694f2665c3e44e650f0e5e58'),('694f2666c3e44e650f0e5f5b','694f2665c3e44e650f0e5dde','694f2665c3e44e650f0e5e59'),('694f2666c3e44e650f0e5f5c','694f2665c3e44e650f0e5dde','694f2665c3e44e650f0e5e5a'),('694f2666c3e44e650f0e5f5d','694f2665c3e44e650f0e5dde','694f2665c3e44e650f0e5e5b'),('694f2666c3e44e650f0e5f5e','694f2665c3e44e650f0e5dde','694f2665c3e44e650f0e5e5c'),('694f2666c3e44e650f0e5f5f','694f2665c3e44e650f0e5dde','694f2665c3e44e650f0e5e5d'),('694f2666c3e44e650f0e5f60','694f2665c3e44e650f0e5dde','694f2665c3e44e650f0e5e5e'),('694f2666c3e44e650f0e5f61','694f2665c3e44e650f0e5dde','694f2665c3e44e650f0e5e5f'),('694f2666c3e44e650f0e5f62','694f2665c3e44e650f0e5dde','694f2665c3e44e650f0e5e60'),('694f2666c3e44e650f0e5f63','694f2665c3e44e650f0e5dde','694f2665c3e44e650f0e5e61'),('694f2666c3e44e650f0e5f64','694f2665c3e44e650f0e5dde','694f2665c3e44e650f0e5e62'),('694f2666c3e44e650f0e5f65','694f2665c3e44e650f0e5dde','694f2665c3e44e650f0e5e63'),('694f2666c3e44e650f0e5f66','694f2665c3e44e650f0e5dde','694f2665c3e44e650f0e5e64'),('694f2666c3e44e650f0e5f67','694f2665c3e44e650f0e5dde','694f2665c3e44e650f0e5e65'),('694f2666c3e44e650f0e5f68','694f2665c3e44e650f0e5dde','694f2665c3e44e650f0e5e66'),('694f2666c3e44e650f0e5f69','694f2665c3e44e650f0e5dde','694f2665c3e44e650f0e5e67'),('694f2666c3e44e650f0e5f6a','694f2665c3e44e650f0e5dde','694f2665c3e44e650f0e5e3f'),('694f2666c3e44e650f0e5f6b','694f2665c3e44e650f0e5de3','694f2665c3e44e650f0e5df0'),('694f2666c3e44e650f0e5f6c','694f2665c3e44e650f0e5de3','694f2665c3e44e650f0e5df1'),('694f2666c3e44e650f0e5f6d','694f2665c3e44e650f0e5de3','694f2665c3e44e650f0e5df2'),('694f2666c3e44e650f0e5f6e','694f2665c3e44e650f0e5de3','694f2665c3e44e650f0e5df3'),('694f2666c3e44e650f0e5f6f','694f2665c3e44e650f0e5de3','694f2665c3e44e650f0e5df4'),('694f2666c3e44e650f0e5f70','694f2665c3e44e650f0e5de3','694f2665c3e44e650f0e5df5'),('694f2666c3e44e650f0e5f71','694f2665c3e44e650f0e5de3','694f2665c3e44e650f0e5df6'),('694f2666c3e44e650f0e5f72','694f2665c3e44e650f0e5de3','694f2665c3e44e650f0e5df7'),('694f2666c3e44e650f0e5f73','694f2665c3e44e650f0e5de3','694f2665c3e44e650f0e5e2e'),('694f2666c3e44e650f0e5f74','694f2665c3e44e650f0e5de3','694f2665c3e44e650f0e5df8'),('694f2666c3e44e650f0e5f75','694f2665c3e44e650f0e5de3','694f2665c3e44e650f0e5df9'),('694f2666c3e44e650f0e5f76','694f2665c3e44e650f0e5de3','694f2665c3e44e650f0e5dfb'),('694f2666c3e44e650f0e5f77','694f2665c3e44e650f0e5de3','694f2665c3e44e650f0e5dfc'),('694f2666c3e44e650f0e5f78','694f2665c3e44e650f0e5de3','694f2665c3e44e650f0e5dfd'),('694f2666c3e44e650f0e5f79','694f2665c3e44e650f0e5de3','694f2665c3e44e650f0e5dfe'),('694f2666c3e44e650f0e5f7a','694f2665c3e44e650f0e5de3','694f2665c3e44e650f0e5dff'),('694f2666c3e44e650f0e5f7b','694f2665c3e44e650f0e5de3','694f2665c3e44e650f0e5e00'),('694f2666c3e44e650f0e5f7c','694f2665c3e44e650f0e5de3','694f2665c3e44e650f0e5e08'),('694f2666c3e44e650f0e5f7d','694f2665c3e44e650f0e5de3','694f2665c3e44e650f0e5e09'),('694f2666c3e44e650f0e5f7e','694f2665c3e44e650f0e5de3','694f2665c3e44e650f0e5e0a'),('694f2666c3e44e650f0e5f7f','694f2665c3e44e650f0e5de3','694f2665c3e44e650f0e5e0b'),('694f2666c3e44e650f0e5f80','694f2665c3e44e650f0e5de3','694f2665c3e44e650f0e5e0c'),('694f2666c3e44e650f0e5f81','694f2665c3e44e650f0e5de3','694f2665c3e44e650f0e5e0d'),('694f2666c3e44e650f0e5f82','694f2665c3e44e650f0e5de3','694f2665c3e44e650f0e5e0e'),('694f2666c3e44e650f0e5f83','694f2665c3e44e650f0e5de3','694f2665c3e44e650f0e5e0f'),('694f2666c3e44e650f0e5f84','694f2665c3e44e650f0e5de3','694f2665c3e44e650f0e5e10'),('694f2666c3e44e650f0e5f85','694f2665c3e44e650f0e5de3','694f2665c3e44e650f0e5e11'),('694f2666c3e44e650f0e5f86','694f2665c3e44e650f0e5de3','694f2665c3e44e650f0e5e12'),('694f2666c3e44e650f0e5f87','694f2665c3e44e650f0e5de3','694f2665c3e44e650f0e5e13'),('694f2666c3e44e650f0e5f88','694f2665c3e44e650f0e5de3','694f2665c3e44e650f0e5e01'),('694f2666c3e44e650f0e5f89','694f2665c3e44e650f0e5de3','694f2665c3e44e650f0e5e04'),('694f2666c3e44e650f0e5f8a','694f2665c3e44e650f0e5de3','694f2665c3e44e650f0e5e30'),('694f2666c3e44e650f0e5f8b','694f2665c3e44e650f0e5de3','694f2665c3e44e650f0e5e31'),('694f2666c3e44e650f0e5f8c','694f2665c3e44e650f0e5de3','694f2665c3e44e650f0e5e32'),('694f2666c3e44e650f0e5f8d','694f2665c3e44e650f0e5de3','694f2665c3e44e650f0e5e33'),('694f2666c3e44e650f0e5f8e','694f2665c3e44e650f0e5de3','694f2665c3e44e650f0e5e34'),('694f2666c3e44e650f0e5f8f','694f2665c3e44e650f0e5de3','694f2665c3e44e650f0e5e42'),('694f2666c3e44e650f0e5f90','694f2665c3e44e650f0e5de3','694f2665c3e44e650f0e5e43'),('694f2666c3e44e650f0e5f91','694f2665c3e44e650f0e5de3','694f2665c3e44e650f0e5e44'),('694f2666c3e44e650f0e5f92','694f2665c3e44e650f0e5de3','694f2665c3e44e650f0e5e45'),('694f2666c3e44e650f0e5f93','694f2665c3e44e650f0e5de3','694f2665c3e44e650f0e5e46'),('694f2666c3e44e650f0e5f94','694f2665c3e44e650f0e5de3','694f2665c3e44e650f0e5e35'),('694f2666c3e44e650f0e5f95','694f2665c3e44e650f0e5de3','694f2665c3e44e650f0e5e36'),('694f2666c3e44e650f0e5f96','694f2665c3e44e650f0e5de3','694f2665c3e44e650f0e5e37'),('694f2666c3e44e650f0e5f97','694f2665c3e44e650f0e5de3','694f2665c3e44e650f0e5e38'),('694f2666c3e44e650f0e5f98','694f2665c3e44e650f0e5de3','694f2665c3e44e650f0e5e39'),('694f2666c3e44e650f0e5f99','694f2665c3e44e650f0e5de3','694f2665c3e44e650f0e5e29'),('694f2666c3e44e650f0e5f9a','694f2665c3e44e650f0e5de3','694f2665c3e44e650f0e5e2a'),('694f2666c3e44e650f0e5f9b','694f2665c3e44e650f0e5de3','694f2665c3e44e650f0e5e4e'),('694f2666c3e44e650f0e5f9c','694f2665c3e44e650f0e5de3','694f2665c3e44e650f0e5e4f'),('694f2666c3e44e650f0e5f9d','694f2665c3e44e650f0e5de3','694f2665c3e44e650f0e5e5e'),('694f2666c3e44e650f0e5f9e','694f2665c3e44e650f0e5de3','694f2665c3e44e650f0e5e5f'),('694f2666c3e44e650f0e5f9f','694f2665c3e44e650f0e5de3','694f2665c3e44e650f0e5e60'),('694f2666c3e44e650f0e5fa0','694f2665c3e44e650f0e5de3','694f2665c3e44e650f0e5e61'),('694f2666c3e44e650f0e5fa1','694f2665c3e44e650f0e5de3','694f2665c3e44e650f0e5e62'),('694f2666c3e44e650f0e5fa2','694f2665c3e44e650f0e5de3','694f2665c3e44e650f0e5e63'),('694f2666c3e44e650f0e5fa3','694f2665c3e44e650f0e5de3','694f2665c3e44e650f0e5e64'),('694f2666c3e44e650f0e5fa4','694f2665c3e44e650f0e5de3','694f2665c3e44e650f0e5e24'),('694f2666c3e44e650f0e5fa5','694f2665c3e44e650f0e5de3','694f2665c3e44e650f0e5e25'),('694f2666c3e44e650f0e5fa6','694f2665c3e44e650f0e5de3','694f2665c3e44e650f0e5e26'),('694f2666c3e44e650f0e5fa7','694f2665c3e44e650f0e5de3','694f2665c3e44e650f0e5e27'),('694f2666c3e44e650f0e5fa8','694f2665c3e44e650f0e5de3','694f2665c3e44e650f0e5e28'),('694f2666c3e44e650f0e5fa9','694f2665c3e44e650f0e5de3','694f2665c3e44e650f0e5e3f'),('694f2666c3e44e650f0e5faa','694f2665c3e44e650f0e5de3','694f2665c3e44e650f0e5e47'),('694f2666c3e44e650f0e5fab','694f2665c3e44e650f0e5de3','694f2665c3e44e650f0e5e48'),('694f2666c3e44e650f0e5fac','694f2665c3e44e650f0e5de3','694f2665c3e44e650f0e5e52'),('694f2666c3e44e650f0e5fad','694f2665c3e44e650f0e5de3','694f2665c3e44e650f0e5e53'),('694f2666c3e44e650f0e5fae','694f2665c3e44e650f0e5de3','694f2665c3e44e650f0e5e54'),('694f2666c3e44e650f0e5faf','694f2665c3e44e650f0e5de3','694f2665c3e44e650f0e5e55'),('694f2666c3e44e650f0e5fb0','694f2665c3e44e650f0e5de3','694f2665c3e44e650f0e5e56'),('694f2666c3e44e650f0e5fb1','694f2665c3e44e650f0e5de3','694f2665c3e44e650f0e5e57'),('694f2666c3e44e650f0e5fb2','694f2665c3e44e650f0e5de3','694f2665c3e44e650f0e5e58'),('694f2666c3e44e650f0e5fb3','694f2665c3e44e650f0e5de3','694f2665c3e44e650f0e5e59'),('694f2666c3e44e650f0e5fb4','694f2665c3e44e650f0e5de3','694f2665c3e44e650f0e5e5a'),('694f2666c3e44e650f0e5fb5','694f2665c3e44e650f0e5dda','694f2665c3e44e650f0e5df0'),('694f2666c3e44e650f0e5fb6','694f2665c3e44e650f0e5dda','694f2665c3e44e650f0e5df1'),('694f2666c3e44e650f0e5fb7','694f2665c3e44e650f0e5dda','694f2665c3e44e650f0e5df2'),('694f2666c3e44e650f0e5fb8','694f2665c3e44e650f0e5dda','694f2665c3e44e650f0e5df3'),('694f2666c3e44e650f0e5fb9','694f2665c3e44e650f0e5dda','694f2665c3e44e650f0e5df4'),('694f2666c3e44e650f0e5fba','694f2665c3e44e650f0e5dda','694f2665c3e44e650f0e5df5'),('694f2666c3e44e650f0e5fbb','694f2665c3e44e650f0e5dda','694f2665c3e44e650f0e5df6'),('694f2666c3e44e650f0e5fbc','694f2665c3e44e650f0e5dda','694f2665c3e44e650f0e5df7'),('694f2666c3e44e650f0e5fbd','694f2665c3e44e650f0e5dda','694f2665c3e44e650f0e5e2e'),('694f2666c3e44e650f0e5fbe','694f2665c3e44e650f0e5dda','694f2665c3e44e650f0e5df8'),('694f2666c3e44e650f0e5fbf','694f2665c3e44e650f0e5dda','694f2665c3e44e650f0e5df9'),('694f2666c3e44e650f0e5fc0','694f2665c3e44e650f0e5dda','694f2665c3e44e650f0e5dfb'),('694f2666c3e44e650f0e5fc1','694f2665c3e44e650f0e5dda','694f2665c3e44e650f0e5dfc'),('694f2666c3e44e650f0e5fc2','694f2665c3e44e650f0e5dda','694f2665c3e44e650f0e5dfd'),('694f2666c3e44e650f0e5fc3','694f2665c3e44e650f0e5dda','694f2665c3e44e650f0e5dfe'),('694f2666c3e44e650f0e5fc4','694f2665c3e44e650f0e5dda','694f2665c3e44e650f0e5dff'),('694f2666c3e44e650f0e5fc5','694f2665c3e44e650f0e5dda','694f2665c3e44e650f0e5e00'),('694f2666c3e44e650f0e5fc6','694f2665c3e44e650f0e5dda','694f2665c3e44e650f0e5e08'),('694f2666c3e44e650f0e5fc7','694f2665c3e44e650f0e5dda','694f2665c3e44e650f0e5e09'),('694f2666c3e44e650f0e5fc8','694f2665c3e44e650f0e5dda','694f2665c3e44e650f0e5e0a'),('694f2666c3e44e650f0e5fc9','694f2665c3e44e650f0e5dda','694f2665c3e44e650f0e5e0b'),('694f2666c3e44e650f0e5fca','694f2665c3e44e650f0e5dda','694f2665c3e44e650f0e5e0c'),('694f2666c3e44e650f0e5fcb','694f2665c3e44e650f0e5dda','694f2665c3e44e650f0e5e0d'),('694f2666c3e44e650f0e5fcc','694f2665c3e44e650f0e5dda','694f2665c3e44e650f0e5e0e'),('694f2666c3e44e650f0e5fcd','694f2665c3e44e650f0e5dda','694f2665c3e44e650f0e5e0f'),('694f2666c3e44e650f0e5fce','694f2665c3e44e650f0e5dda','694f2665c3e44e650f0e5e10'),('694f2666c3e44e650f0e5fcf','694f2665c3e44e650f0e5dda','694f2665c3e44e650f0e5e11'),('694f2666c3e44e650f0e5fd0','694f2665c3e44e650f0e5dda','694f2665c3e44e650f0e5e12'),('694f2666c3e44e650f0e5fd1','694f2665c3e44e650f0e5dda','694f2665c3e44e650f0e5e13'),('694f2666c3e44e650f0e5fd2','694f2665c3e44e650f0e5dda','694f2665c3e44e650f0e5e01'),('694f2666c3e44e650f0e5fd3','694f2665c3e44e650f0e5dda','694f2665c3e44e650f0e5e04'),('694f2666c3e44e650f0e5fd4','694f2665c3e44e650f0e5dda','694f2665c3e44e650f0e5e30'),('694f2666c3e44e650f0e5fd5','694f2665c3e44e650f0e5dda','694f2665c3e44e650f0e5e31'),('694f2666c3e44e650f0e5fd6','694f2665c3e44e650f0e5dda','694f2665c3e44e650f0e5e32'),('694f2666c3e44e650f0e5fd7','694f2665c3e44e650f0e5dda','694f2665c3e44e650f0e5e33'),('694f2666c3e44e650f0e5fd8','694f2665c3e44e650f0e5dda','694f2665c3e44e650f0e5e34'),('694f2666c3e44e650f0e5fd9','694f2665c3e44e650f0e5dda','694f2665c3e44e650f0e5e42'),('694f2666c3e44e650f0e5fda','694f2665c3e44e650f0e5dda','694f2665c3e44e650f0e5e43'),('694f2666c3e44e650f0e5fdb','694f2665c3e44e650f0e5dda','694f2665c3e44e650f0e5e44'),('694f2666c3e44e650f0e5fdc','694f2665c3e44e650f0e5dda','694f2665c3e44e650f0e5e45'),('694f2666c3e44e650f0e5fdd','694f2665c3e44e650f0e5dda','694f2665c3e44e650f0e5e46'),('694f2666c3e44e650f0e5fde','694f2665c3e44e650f0e5dda','694f2665c3e44e650f0e5e35'),('694f2666c3e44e650f0e5fdf','694f2665c3e44e650f0e5dda','694f2665c3e44e650f0e5e36'),('694f2666c3e44e650f0e5fe0','694f2665c3e44e650f0e5dda','694f2665c3e44e650f0e5e29'),('694f2666c3e44e650f0e5fe1','694f2665c3e44e650f0e5dda','694f2665c3e44e650f0e5e2a'),('694f2666c3e44e650f0e5fe2','694f2665c3e44e650f0e5dda','694f2665c3e44e650f0e5e4e'),('694f2666c3e44e650f0e5fe3','694f2665c3e44e650f0e5dda','694f2665c3e44e650f0e5e4f'),('694f2666c3e44e650f0e5fe4','694f2665c3e44e650f0e5dda','694f2665c3e44e650f0e5e5e'),('694f2666c3e44e650f0e5fe5','694f2665c3e44e650f0e5dda','694f2665c3e44e650f0e5e5f'),('694f2666c3e44e650f0e5fe6','694f2665c3e44e650f0e5dda','694f2665c3e44e650f0e5e60'),('694f2666c3e44e650f0e5fe7','694f2665c3e44e650f0e5dda','694f2665c3e44e650f0e5e61'),('694f2666c3e44e650f0e5fe8','694f2665c3e44e650f0e5dda','694f2665c3e44e650f0e5e62'),('694f2666c3e44e650f0e5fe9','694f2665c3e44e650f0e5dda','694f2665c3e44e650f0e5e63'),('694f2666c3e44e650f0e5fea','694f2665c3e44e650f0e5dda','694f2665c3e44e650f0e5e64'),('694f2666c3e44e650f0e5feb','694f2665c3e44e650f0e5ddb','694f2665c3e44e650f0e5df3'),('694f2666c3e44e650f0e5fec','694f2665c3e44e650f0e5ddb','694f2665c3e44e650f0e5df4'),('694f2666c3e44e650f0e5fed','694f2665c3e44e650f0e5ddb','694f2665c3e44e650f0e5df5'),('694f2666c3e44e650f0e5fee','694f2665c3e44e650f0e5ddb','694f2665c3e44e650f0e5df6'),('694f2666c3e44e650f0e5fef','694f2665c3e44e650f0e5ddb','694f2665c3e44e650f0e5df7'),('694f2666c3e44e650f0e5ff0','694f2665c3e44e650f0e5ddb','694f2665c3e44e650f0e5df8'),('694f2666c3e44e650f0e5ff1','694f2665c3e44e650f0e5ddb','694f2665c3e44e650f0e5df9'),('694f2666c3e44e650f0e5ff2','694f2665c3e44e650f0e5ddb','694f2665c3e44e650f0e5dfb'),('694f2666c3e44e650f0e5ff3','694f2665c3e44e650f0e5ddb','694f2665c3e44e650f0e5dfc'),('694f2666c3e44e650f0e5ff4','694f2665c3e44e650f0e5ddb','694f2665c3e44e650f0e5dfd'),('694f2666c3e44e650f0e5ff5','694f2665c3e44e650f0e5ddb','694f2665c3e44e650f0e5dff'),('694f2666c3e44e650f0e5ff6','694f2665c3e44e650f0e5ddb','694f2665c3e44e650f0e5e08'),('694f2666c3e44e650f0e5ff7','694f2665c3e44e650f0e5ddb','694f2665c3e44e650f0e5e09'),('694f2666c3e44e650f0e5ff8','694f2665c3e44e650f0e5ddb','694f2665c3e44e650f0e5e0e'),('694f2666c3e44e650f0e5ff9','694f2665c3e44e650f0e5ddb','694f2665c3e44e650f0e5e01'),('694f2666c3e44e650f0e5ffa','694f2665c3e44e650f0e5ddb','694f2665c3e44e650f0e5e04'),('694f2666c3e44e650f0e5ffb','694f2665c3e44e650f0e5ddb','694f2665c3e44e650f0e5e30'),('694f2666c3e44e650f0e5ffc','694f2665c3e44e650f0e5ddb','694f2665c3e44e650f0e5e33'),('694f2666c3e44e650f0e5ffd','694f2665c3e44e650f0e5ddb','694f2665c3e44e650f0e5e42'),('694f2666c3e44e650f0e5ffe','694f2665c3e44e650f0e5ddb','694f2665c3e44e650f0e5e43'),('694f2666c3e44e650f0e5fff','694f2665c3e44e650f0e5ddb','694f2665c3e44e650f0e5e35'),('694f2666c3e44e650f0e6000','694f2665c3e44e650f0e5ddb','694f2665c3e44e650f0e5e36'),('694f2666c3e44e650f0e6001','694f2665c3e44e650f0e5ddb','694f2665c3e44e650f0e5e29'),('694f2666c3e44e650f0e6002','694f2665c3e44e650f0e5ddb','694f2665c3e44e650f0e5e2a'),('694f2666c3e44e650f0e6003','694f2665c3e44e650f0e5ddb','694f2665c3e44e650f0e5e4e'),('694f2666c3e44e650f0e6004','694f2665c3e44e650f0e5ddb','694f2665c3e44e650f0e5e4f'),('694f2666c3e44e650f0e6005','694f2665c3e44e650f0e5ddb','694f2665c3e44e650f0e5e5e'),('694f2666c3e44e650f0e6006','694f2665c3e44e650f0e5ddb','694f2665c3e44e650f0e5e5f'),('694f2666c3e44e650f0e6007','694f2665c3e44e650f0e5ddb','694f2665c3e44e650f0e5e61'),('694f2666c3e44e650f0e6008','694f2665c3e44e650f0e5ddb','694f2665c3e44e650f0e5e63'),('694f2666c3e44e650f0e6009','694f2665c3e44e650f0e5ddb','694f2665c3e44e650f0e5e64'),('694f2666c3e44e650f0e600a','694f2665c3e44e650f0e5ddc','694f2665c3e44e650f0e5df3'),('694f2666c3e44e650f0e600b','694f2665c3e44e650f0e5ddc','694f2665c3e44e650f0e5df4'),('694f2666c3e44e650f0e600c','694f2665c3e44e650f0e5ddc','694f2665c3e44e650f0e5df5'),('694f2666c3e44e650f0e600d','694f2665c3e44e650f0e5ddc','694f2665c3e44e650f0e5df6'),('694f2666c3e44e650f0e600e','694f2665c3e44e650f0e5ddc','694f2665c3e44e650f0e5df7'),('694f2666c3e44e650f0e600f','694f2665c3e44e650f0e5ddc','694f2665c3e44e650f0e5df8'),('694f2666c3e44e650f0e6010','694f2665c3e44e650f0e5ddc','694f2665c3e44e650f0e5df9'),('694f2666c3e44e650f0e6011','694f2665c3e44e650f0e5ddc','694f2665c3e44e650f0e5dfb'),('694f2666c3e44e650f0e6012','694f2665c3e44e650f0e5ddc','694f2665c3e44e650f0e5dfc'),('694f2666c3e44e650f0e6013','694f2665c3e44e650f0e5ddc','694f2665c3e44e650f0e5dfd'),('694f2666c3e44e650f0e6014','694f2665c3e44e650f0e5ddc','694f2665c3e44e650f0e5e08'),('694f2666c3e44e650f0e6015','694f2665c3e44e650f0e5ddc','694f2665c3e44e650f0e5e09'),('694f2666c3e44e650f0e6016','694f2665c3e44e650f0e5ddc','694f2665c3e44e650f0e5e0e'),('694f2666c3e44e650f0e6017','694f2665c3e44e650f0e5ddc','694f2665c3e44e650f0e5e01'),('694f2666c3e44e650f0e6018','694f2665c3e44e650f0e5ddc','694f2665c3e44e650f0e5e30'),('694f2666c3e44e650f0e6019','694f2665c3e44e650f0e5ddc','694f2665c3e44e650f0e5e33'),('694f2666c3e44e650f0e601a','694f2665c3e44e650f0e5ddc','694f2665c3e44e650f0e5e42'),('694f2666c3e44e650f0e601b','694f2665c3e44e650f0e5ddc','694f2665c3e44e650f0e5e43'),('694f2666c3e44e650f0e601c','694f2665c3e44e650f0e5ddc','694f2665c3e44e650f0e5e5e'),('694f2666c3e44e650f0e601d','694f2665c3e44e650f0e5ddc','694f2665c3e44e650f0e5e5f'),('694f2666c3e44e650f0e601e','694f2665c3e44e650f0e5ddc','694f2665c3e44e650f0e5e63'),('694f2666c3e44e650f0e601f','694f2665c3e44e650f0e5ddc','694f2665c3e44e650f0e5e64');
/*!40000 ALTER TABLE `permissions_roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `permissions_users`
--

DROP TABLE IF EXISTS `permissions_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `permissions_users` (
  `id` varchar(24) NOT NULL,
  `user_id` varchar(24) NOT NULL,
  `permission_id` varchar(24) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permissions_users`
--

LOCK TABLES `permissions_users` WRITE;
/*!40000 ALTER TABLE `permissions_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `permissions_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `post_revisions`
--

DROP TABLE IF EXISTS `post_revisions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `post_revisions` (
  `id` varchar(24) NOT NULL,
  `post_id` varchar(24) NOT NULL,
  `lexical` longtext,
  `created_at_ts` bigint NOT NULL,
  `created_at` datetime NOT NULL,
  `author_id` varchar(24) DEFAULT NULL,
  `title` varchar(2000) DEFAULT NULL,
  `post_status` varchar(50) DEFAULT NULL,
  `reason` varchar(50) DEFAULT NULL,
  `feature_image` varchar(2000) DEFAULT NULL,
  `feature_image_alt` varchar(2000) DEFAULT NULL,
  `feature_image_caption` text,
  `custom_excerpt` varchar(2000) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `post_revisions_post_id_index` (`post_id`),
  KEY `post_revs_author_id_foreign` (`author_id`),
  CONSTRAINT `post_revs_author_id_foreign` FOREIGN KEY (`author_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `post_revisions`
--

LOCK TABLES `post_revisions` WRITE;
/*!40000 ALTER TABLE `post_revisions` DISABLE KEYS */;
/*!40000 ALTER TABLE `post_revisions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `posts`
--

DROP TABLE IF EXISTS `posts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `posts` (
  `id` varchar(24) NOT NULL,
  `uuid` varchar(36) NOT NULL,
  `title` varchar(2000) NOT NULL,
  `slug` varchar(191) NOT NULL,
  `mobiledoc` longtext,
  `lexical` longtext,
  `html` longtext,
  `comment_id` varchar(50) DEFAULT NULL,
  `plaintext` longtext,
  `feature_image` varchar(2000) DEFAULT NULL,
  `featured` tinyint(1) NOT NULL DEFAULT '0',
  `type` varchar(50) NOT NULL DEFAULT 'post',
  `status` varchar(50) NOT NULL DEFAULT 'draft',
  `locale` varchar(6) DEFAULT NULL,
  `visibility` varchar(50) NOT NULL DEFAULT 'public',
  `email_recipient_filter` text NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  `published_at` datetime DEFAULT NULL,
  `published_by` varchar(24) DEFAULT NULL,
  `custom_excerpt` varchar(2000) DEFAULT NULL,
  `codeinjection_head` text,
  `codeinjection_foot` text,
  `custom_template` varchar(100) DEFAULT NULL,
  `canonical_url` text,
  `newsletter_id` varchar(24) DEFAULT NULL,
  `show_title_and_feature_image` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `posts_slug_type_unique` (`slug`,`type`),
  KEY `posts_uuid_index` (`uuid`),
  KEY `posts_updated_at_index` (`updated_at`),
  KEY `posts_published_at_index` (`published_at`),
  KEY `posts_newsletter_id_foreign` (`newsletter_id`),
  KEY `posts_type_status_updated_at_index` (`type`,`status`,`updated_at`),
  CONSTRAINT `posts_newsletter_id_foreign` FOREIGN KEY (`newsletter_id`) REFERENCES `newsletters` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `posts`
--

LOCK TABLES `posts` WRITE;
/*!40000 ALTER TABLE `posts` DISABLE KEYS */;
INSERT INTO `posts` VALUES ('694f2666c3e44e650f0e5e6a','3e774f8f-2f5c-44ee-9312-8c334c68d78d','About this site','about','{\"version\":\"0.3.1\",\"atoms\":[],\"cards\":[[\"hr\",{}]],\"markups\":[[\"a\",[\"href\",\"https://ghost.org\"]]],\"sections\":[[1,\"p\",[[0,[],0,\"Performance Engineering is an independent publication launched in December 2025 by Manuel A Rodriguez. If you subscribe today, you\'ll get full access to the website as well as email newsletters about new content when it\'s available. Your subscription makes this site possible, and allows Performance Engineering to continue to exist. Thank you!\"]]],[1,\"h3\",[[0,[],0,\"Access all areas\"]]],[1,\"p\",[[0,[],0,\"By signing up, you\'ll get access to the full archive of everything that\'s been published before and everything that\'s still to come. Your very own private library.\"]]],[1,\"h3\",[[0,[],0,\"Fresh content, delivered\"]]],[1,\"p\",[[0,[],0,\"Stay up to date with new content sent straight to your inbox! No more worrying about whether you missed something because of a pesky algorithm or news feed.\"]]],[1,\"h3\",[[0,[],0,\"Meet people like you\"]]],[1,\"p\",[[0,[],0,\"Join a community of other subscribers who share the same interests.\"]]],[10,0],[1,\"h3\",[[0,[],0,\"Start your own thing\"]]],[1,\"p\",[[0,[],0,\"Enjoying the experience? Get started for free and set up your very own subscription business using \"],[0,[0],1,\"Ghost\"],[0,[],0,\", the same platform that powers this website.\"]]]],\"ghostVersion\":\"4.0\"}',NULL,'<p>Performance Engineering is an independent publication launched in December 2025 by Manuel A Rodriguez. If you subscribe today, you\'ll get full access to the website as well as email newsletters about new content when it\'s available. Your subscription makes this site possible, and allows Performance Engineering to continue to exist. Thank you!</p><h3 id=\"access-all-areas\">Access all areas</h3><p>By signing up, you\'ll get access to the full archive of everything that\'s been published before and everything that\'s still to come. Your very own private library.</p><h3 id=\"fresh-content-delivered\">Fresh content, delivered</h3><p>Stay up to date with new content sent straight to your inbox! No more worrying about whether you missed something because of a pesky algorithm or news feed.</p><h3 id=\"meet-people-like-you\">Meet people like you</h3><p>Join a community of other subscribers who share the same interests.</p><hr><h3 id=\"start-your-own-thing\">Start your own thing</h3><p>Enjoying the experience? Get started for free and set up your very own subscription business using <a href=\"https://ghost.org\">Ghost</a>, the same platform that powers this website.</p>','694f2666c3e44e650f0e5e6a','Performance Engineering is an independent publication launched in December 2025 by Manuel A Rodriguez. If you subscribe today, you\'ll get full access to the website as well as email newsletters about new content when it\'s available. Your subscription makes this site possible, and allows Performance Engineering to continue to exist. Thank you!\n\n\nAccess all areas\n\nBy signing up, you\'ll get access to the full archive of everything that\'s been published before and everything that\'s still to come. Your very own private library.\n\n\nFresh content, delivered\n\nStay up to date with new content sent straight to your inbox! No more worrying about whether you missed something because of a pesky algorithm or news feed.\n\n\nMeet people like you\n\nJoin a community of other subscribers who share the same interests.\n\n\nStart your own thing\n\nEnjoying the experience? Get started for free and set up your very own subscription business using Ghost, the same platform that powers this website.',NULL,0,'page','published',NULL,'public','all','2025-12-27 00:20:54','2025-12-27 00:21:16','2025-12-27 00:20:54','694f2665c3e44e650f0e5dd8',NULL,NULL,NULL,NULL,NULL,NULL,1),('694f2cf37f4d7d685707e403','d56775e3-a377-4b9d-b46c-83a421d3613a','Prefer Fewer Fast CPU Cores Over Many Slow Ones for Latency-Sensitive Workloads','prefer-fewer-fast-cpu-cores-over-many-slow-ones-for-latency-sensitive-workloads',NULL,'{\"root\":{\"children\":[{\"type\":\"markdown\",\"markdown\":\"# Prefer Fewer Fast CPU Cores Over Many Slow Ones for Latency-Sensitive Workloads\\n\\n## Subtitle\\nUnderstanding the trade-off between CPU core count and single-thread performance is critical for optimizing latency-sensitive applications where sequential execution matters more than raw parallelism.\\n\\n## Executive Summary (TL;DR)\\nChoosing fewer fast CPU cores over many slow cores is a performance principle that prioritizes single-thread performance and instruction-level parallelism (IPC) over core count. This approach delivers 20-40% better single-threaded performance, significantly lower latency for critical operations (often reducing response times from 50-100ms to 20-40ms), and improved throughput for applications with sequential dependencies. However, it sacrifices overall parallel throughput and scales poorly for highly concurrent workloads. Use this approach when latency matters more than throughput, for single-threaded applications, or when Amdahl\'s Law limits parallel speedup.\\n\\n## Problem Context\\nA common misconception in performance optimization is that more CPU cores always translate to better performance. Engineers often scale systems horizontally by adding cores without considering single-thread performance characteristics. This leads to scenarios where applications with sequential bottlenecks or latency-sensitive operations underperform despite high core counts.\\n\\nMany production systems suffer from this because modern CPUs designed for high core counts (such as some server-class processors) prioritize parallelism over single-thread speed. These processors trade higher clock frequencies and aggressive out-of-order execution for more cores, resulting in lower IPC (Instructions Per Cycle) and slower individual core performance.\\n\\nNaive scaling attempts often fail because:\\n- Sequential dependencies prevent effective parallelization (Amdahl\'s Law)\\n- Synchronization overhead increases with more cores\\n- Cache coherency traffic scales non-linearly with core count\\n- Critical paths remain bounded by single-thread performance\\n\\n## How It Works\\nCPU performance is determined by three key factors: clock frequency, IPC (Instructions Per Cycle), and core count. Fast cores achieve higher performance through:\\n\\n**Clock Frequency**: Higher clock rates allow more instructions to execute per second. Modern fast cores (e.g., Intel Core series, AMD Ryzen high-frequency variants) run at 4-6 GHz, while many-core processors often operate at 2-3 GHz.\\n\\n**Instruction-Level Parallelism (IPC)**: Fast cores employ deeper pipelines, wider execution units, larger instruction windows, and more aggressive branch prediction. This allows them to extract more parallelism from sequential code, executing multiple independent instructions simultaneously within a single thread.\\n\\n**Cache Hierarchy**: Fast cores typically feature larger, faster L1 and L2 caches per core, reducing memory latency for single-threaded workloads. They also have better prefetching logic that predicts memory access patterns.\\n\\n**Out-of-Order Execution**: Advanced out-of-order execution engines can reorder and parallelize independent instructions within a single thread, effectively creating instruction-level parallelism without explicit multi-threading.\\n\\nWhen a workload has sequential dependencies or Amdahl\'s Law limits parallel speedup, a single fast core can outperform multiple slow cores by completing the critical path faster, even if total theoretical throughput is lower.\\n\\n## Why This Becomes a Bottleneck\\nPerformance degrades when core speed is sacrificed for core count because:\\n\\n**Sequential Bottlenecks**: Every parallel algorithm has sequential portions (data distribution, result aggregation, synchronization). Amdahl\'s Law shows that even 5% sequential code limits speedup to 20x regardless of core count. Fast cores reduce the time spent in sequential sections.\\n\\n**Synchronization Overhead**: More cores require more synchronization primitives (locks, barriers, atomic operations). Each synchronization point introduces latency and serialization. Fast cores reduce the time each thread spends in critical sections, decreasing contention window duration.\\n\\n**Cache Coherency Traffic**: With more cores, cache line invalidation and data movement between caches increase exponentially. Fast cores with better cache locality generate less coherency traffic per unit of work.\\n\\n**Memory Bandwidth Contention**: Multiple slow cores saturate memory bandwidth more easily because each core takes longer to complete operations, keeping memory buses occupied longer. Fast cores complete memory operations faster, freeing bandwidth sooner.\\n\\n**Latency Amplification**: In request-response systems, latency is determined by the slowest path. Even if 99% of work is parallelized, the 1% sequential portion (often I/O or serialization) determines P99 latency. Fast cores reduce this critical path latency.\\n\\n## Advantages\\n- **Superior Single-Thread Performance**: 20-40% better performance on single-threaded workloads compared to many-core processors with lower IPC\\n- **Reduced Latency**: Critical operations complete 50-100% faster (e.g., reducing response times from 50-100ms to 20-40ms in observed benchmarks)\\n- **Lower Synchronization Overhead**: Fewer cores mean fewer lock contentions, atomic operations, and cache coherency messages\\n- **Better Cache Locality**: Larger per-core caches and fewer threads reduce cache misses and improve memory access patterns\\n- **Simpler Architecture**: Less need for complex thread pools, work-stealing schedulers, and parallel algorithms\\n- **Predictable Performance**: More deterministic latency characteristics, crucial for real-time systems\\n- **Higher Throughput for Sequential Workloads**: Applications that cannot be parallelized achieve 15-30% better throughput even with fewer total cores\\n\\n## Disadvantages and Trade-offs\\n- **Limited Parallel Throughput**: Cannot match the total compute capacity of many-core systems for embarrassingly parallel workloads\\n- **Higher Per-Core Cost**: Fast cores with advanced microarchitecture features are more expensive to manufacture\\n- **Poor Scalability for Concurrent Workloads**: Request-per-thread server models (like traditional web servers) benefit less when request count exceeds fast core count\\n- **Lower Total Compute Capacity**: Cannot execute as many independent threads simultaneously\\n- **Underutilization Risk**: If workloads can be fully parallelized, fast cores may sit idle while waiting for I/O, wasting resources\\n- **Memory Bandwidth Limits**: Fewer cores mean fewer memory controllers, potentially limiting memory bandwidth for data-parallel workloads\\n\\n## When to Use This Approach\\n- **Latency-Sensitive Applications**: Real-time systems, trading platforms, gaming servers, interactive applications where P99 latency matters more than throughput\\n- **Sequential Workloads**: Applications with Amdahl\'s Law limits, legacy code that cannot be parallelized, algorithms with strong data dependencies\\n- **Single-Threaded Applications**: Node.js event loops, Python GIL-bound code, JavaScript engines, database query execution (single query optimization)\\n- **Cache-Sensitive Workloads**: Applications where cache locality matters more than parallelism (many scientific computing kernels, graph algorithms)\\n- **I/O-Bound Systems with Critical Paths**: Systems where CPU work per request is minimal but latency is critical (API gateways, load balancers with simple routing logic)\\n- **Development and Testing**: Faster iteration cycles when single-thread performance improves compile times and test execution speed\\n\\n## When Not to Use It\\n- **Highly Parallel Workloads**: Data processing pipelines, batch jobs, scientific simulations with perfect parallelism (no shared state)\\n- **Request-Per-Thread Servers**: Traditional threaded web servers handling thousands of concurrent connections (more cores allow more simultaneous request processing)\\n- **Cost-Optimized Deployments**: When total compute capacity per dollar is the primary metric and latency requirements are relaxed\\n- **Embarrassingly Parallel Problems**: Image processing, video encoding, Monte Carlo simulations where each unit of work is independent\\n- **Cloud Environments with Auto-Scaling**: When horizontal scaling is cheaper than vertical scaling and workload can be distributed\\n- **Containers with Thread Pools**: Applications using thread pools larger than available fast cores, where additional slow cores provide better resource utilization\\n\\n## Performance Impact\\nReal-world observations show:\\n\\n**Latency Improvements**: P50 latency reductions of 30-50% and P99 latency improvements of 40-60% in latency-sensitive applications. For example, a trading system reduced order processing latency from 85ms to 35ms by switching from 32 slow cores to 8 fast cores.\\n\\n**Single-Thread Throughput**: 20-40% improvement in single-threaded benchmarks (SPEC CPU benchmarks show this consistently). JavaScript V8 benchmarks show 25-35% improvements on fast-core architectures.\\n\\n**Sequential Workload Throughput**: Even with fewer total cores, applications with 10-20% sequential code show 15-30% better overall throughput because the critical path completes faster.\\n\\n**Resource Utilization**: Lower CPU utilization (50-70% vs 80-95%) but better response time characteristics, indicating that cores are not the bottleneck but rather single-thread speed.\\n\\n**Energy Efficiency**: Better performance per watt for single-threaded workloads, though total system power may be lower with fewer cores.\\n\\n## Common Mistakes\\n- **Assuming More Cores Always Help**: Adding cores to applications with sequential bottlenecks without profiling to identify the actual bottleneck\\n- **Ignoring Amdahl\'s Law**: Failing to calculate theoretical speedup limits based on sequential code percentage\\n- **Over-Parallelization**: Creating excessive threads that contend for fast cores, leading to context switching overhead that negates single-thread advantages\\n- **Mismatched Architecture Patterns**: Using request-per-thread models (many threads) with fast-core architectures instead of event-driven or async models\\n- **Not Profiling Single-Thread Performance**: Optimizing for multi-threaded scenarios without measuring whether single-thread speed is the actual constraint\\n- **Cache-Unaware Algorithms**: Implementing algorithms that ignore cache locality, wasting the cache advantages of fast cores\\n- **Benchmarking Synthetic Loads**: Testing with perfectly parallel synthetic workloads instead of realistic production traffic patterns\\n\\n## How to Measure and Validate\\n**Profiling Tools**:\\n- Use `perf` (Linux) to measure CPI (Cycles Per Instruction), cache misses, and branch mispredictions\\n- Profile with tools like `vtune` or `perf top` to identify if single-thread performance or parallelism is the bottleneck\\n- Measure IPC metrics: instructions retired per cycle should be higher on fast cores (typically 2-4 IPC vs 1-2 IPC on slow cores)\\n\\n**Key Metrics**:\\n- **Latency Percentiles**: Track P50, P95, P99 latency - fast cores should show lower tail latencies\\n- **Single-Thread Throughput**: Benchmark single-threaded execution time for critical paths\\n- **CPU Utilization**: Lower utilization with better performance indicates single-thread speedup\\n- **Context Switch Rate**: Fewer context switches per request with fast cores\\n- **Cache Hit Rates**: Monitor L1/L2/L3 cache hit ratios - fast cores should show better locality\\n\\n**Benchmarking Strategy**:\\n1. Run single-threaded benchmarks (SPEC CPU, single-threaded application tests)\\n2. Measure critical path latency under production load\\n3. Compare same workload on many-core vs few-core-fast systems\\n4. Use realistic load patterns, not synthetic parallel workloads\\n5. Measure tail latencies, not just averages\\n\\n**Production Validation**:\\n- A/B test with canary deployments comparing core configurations\\n- Monitor application-level metrics (request latency, transaction completion time)\\n- Track system metrics (CPU utilization, context switches, cache performance)\\n- Validate that improvements translate to business metrics (user experience, revenue)\\n\\n## Summary and Key Takeaways\\nThe core principle: **Fewer fast CPU cores outperform many slow cores when single-thread performance matters more than total parallel throughput**. This trade-off is fundamental in CPU architecture and should guide hardware selection and system design.\\n\\nThe main trade-off is between latency/sequential performance and total parallel capacity. Fast cores excel at reducing critical path latency and improving single-thread execution, while many-core systems excel at total throughput for parallelizable workloads.\\n\\n**Decision Guideline**: Choose fast cores when (1) latency requirements are strict (P99 < 100ms), (2) workloads have sequential dependencies (Amdahl\'s Law limits apply), (3) single-thread performance is the bottleneck (profiling confirms), or (4) cache locality matters more than parallelism. Choose many cores when (1) workloads are embarrassingly parallel, (2) total throughput is the primary metric, (3) cost per compute unit is critical, or (4) request-per-thread models handle massive concurrency.\\n\\nAlways profile before deciding: measure IPC, latency percentiles, and identify whether the bottleneck is sequential execution or parallel capacity.\"}],\"direction\":null,\"format\":\"\",\"indent\":0,\"type\":\"root\",\"version\":1}}','<!--kg-card-begin: markdown--><h1 id=\"prefer-fewer-fast-cpu-cores-over-many-slow-ones-for-latency-sensitive-workloads\">Prefer Fewer Fast CPU Cores Over Many Slow Ones for Latency-Sensitive Workloads</h1>\n<h2 id=\"subtitle\">Subtitle</h2>\n<p>Understanding the trade-off between CPU core count and single-thread performance is critical for optimizing latency-sensitive applications where sequential execution matters more than raw parallelism.</p>\n<h2 id=\"executive-summary-tldr\">Executive Summary (TL;DR)</h2>\n<p>Choosing fewer fast CPU cores over many slow cores is a performance principle that prioritizes single-thread performance and instruction-level parallelism (IPC) over core count. This approach delivers 20-40% better single-threaded performance, significantly lower latency for critical operations (often reducing response times from 50-100ms to 20-40ms), and improved throughput for applications with sequential dependencies. However, it sacrifices overall parallel throughput and scales poorly for highly concurrent workloads. Use this approach when latency matters more than throughput, for single-threaded applications, or when Amdahl\'s Law limits parallel speedup.</p>\n<h2 id=\"problem-context\">Problem Context</h2>\n<p>A common misconception in performance optimization is that more CPU cores always translate to better performance. Engineers often scale systems horizontally by adding cores without considering single-thread performance characteristics. This leads to scenarios where applications with sequential bottlenecks or latency-sensitive operations underperform despite high core counts.</p>\n<p>Many production systems suffer from this because modern CPUs designed for high core counts (such as some server-class processors) prioritize parallelism over single-thread speed. These processors trade higher clock frequencies and aggressive out-of-order execution for more cores, resulting in lower IPC (Instructions Per Cycle) and slower individual core performance.</p>\n<p>Naive scaling attempts often fail because:</p>\n<ul>\n<li>Sequential dependencies prevent effective parallelization (Amdahl\'s Law)</li>\n<li>Synchronization overhead increases with more cores</li>\n<li>Cache coherency traffic scales non-linearly with core count</li>\n<li>Critical paths remain bounded by single-thread performance</li>\n</ul>\n<h2 id=\"how-it-works\">How It Works</h2>\n<p>CPU performance is determined by three key factors: clock frequency, IPC (Instructions Per Cycle), and core count. Fast cores achieve higher performance through:</p>\n<p><strong>Clock Frequency</strong>: Higher clock rates allow more instructions to execute per second. Modern fast cores (e.g., Intel Core series, AMD Ryzen high-frequency variants) run at 4-6 GHz, while many-core processors often operate at 2-3 GHz.</p>\n<p><strong>Instruction-Level Parallelism (IPC)</strong>: Fast cores employ deeper pipelines, wider execution units, larger instruction windows, and more aggressive branch prediction. This allows them to extract more parallelism from sequential code, executing multiple independent instructions simultaneously within a single thread.</p>\n<p><strong>Cache Hierarchy</strong>: Fast cores typically feature larger, faster L1 and L2 caches per core, reducing memory latency for single-threaded workloads. They also have better prefetching logic that predicts memory access patterns.</p>\n<p><strong>Out-of-Order Execution</strong>: Advanced out-of-order execution engines can reorder and parallelize independent instructions within a single thread, effectively creating instruction-level parallelism without explicit multi-threading.</p>\n<p>When a workload has sequential dependencies or Amdahl\'s Law limits parallel speedup, a single fast core can outperform multiple slow cores by completing the critical path faster, even if total theoretical throughput is lower.</p>\n<h2 id=\"why-this-becomes-a-bottleneck\">Why This Becomes a Bottleneck</h2>\n<p>Performance degrades when core speed is sacrificed for core count because:</p>\n<p><strong>Sequential Bottlenecks</strong>: Every parallel algorithm has sequential portions (data distribution, result aggregation, synchronization). Amdahl\'s Law shows that even 5% sequential code limits speedup to 20x regardless of core count. Fast cores reduce the time spent in sequential sections.</p>\n<p><strong>Synchronization Overhead</strong>: More cores require more synchronization primitives (locks, barriers, atomic operations). Each synchronization point introduces latency and serialization. Fast cores reduce the time each thread spends in critical sections, decreasing contention window duration.</p>\n<p><strong>Cache Coherency Traffic</strong>: With more cores, cache line invalidation and data movement between caches increase exponentially. Fast cores with better cache locality generate less coherency traffic per unit of work.</p>\n<p><strong>Memory Bandwidth Contention</strong>: Multiple slow cores saturate memory bandwidth more easily because each core takes longer to complete operations, keeping memory buses occupied longer. Fast cores complete memory operations faster, freeing bandwidth sooner.</p>\n<p><strong>Latency Amplification</strong>: In request-response systems, latency is determined by the slowest path. Even if 99% of work is parallelized, the 1% sequential portion (often I/O or serialization) determines P99 latency. Fast cores reduce this critical path latency.</p>\n<h2 id=\"advantages\">Advantages</h2>\n<ul>\n<li><strong>Superior Single-Thread Performance</strong>: 20-40% better performance on single-threaded workloads compared to many-core processors with lower IPC</li>\n<li><strong>Reduced Latency</strong>: Critical operations complete 50-100% faster (e.g., reducing response times from 50-100ms to 20-40ms in observed benchmarks)</li>\n<li><strong>Lower Synchronization Overhead</strong>: Fewer cores mean fewer lock contentions, atomic operations, and cache coherency messages</li>\n<li><strong>Better Cache Locality</strong>: Larger per-core caches and fewer threads reduce cache misses and improve memory access patterns</li>\n<li><strong>Simpler Architecture</strong>: Less need for complex thread pools, work-stealing schedulers, and parallel algorithms</li>\n<li><strong>Predictable Performance</strong>: More deterministic latency characteristics, crucial for real-time systems</li>\n<li><strong>Higher Throughput for Sequential Workloads</strong>: Applications that cannot be parallelized achieve 15-30% better throughput even with fewer total cores</li>\n</ul>\n<h2 id=\"disadvantages-and-trade-offs\">Disadvantages and Trade-offs</h2>\n<ul>\n<li><strong>Limited Parallel Throughput</strong>: Cannot match the total compute capacity of many-core systems for embarrassingly parallel workloads</li>\n<li><strong>Higher Per-Core Cost</strong>: Fast cores with advanced microarchitecture features are more expensive to manufacture</li>\n<li><strong>Poor Scalability for Concurrent Workloads</strong>: Request-per-thread server models (like traditional web servers) benefit less when request count exceeds fast core count</li>\n<li><strong>Lower Total Compute Capacity</strong>: Cannot execute as many independent threads simultaneously</li>\n<li><strong>Underutilization Risk</strong>: If workloads can be fully parallelized, fast cores may sit idle while waiting for I/O, wasting resources</li>\n<li><strong>Memory Bandwidth Limits</strong>: Fewer cores mean fewer memory controllers, potentially limiting memory bandwidth for data-parallel workloads</li>\n</ul>\n<h2 id=\"when-to-use-this-approach\">When to Use This Approach</h2>\n<ul>\n<li><strong>Latency-Sensitive Applications</strong>: Real-time systems, trading platforms, gaming servers, interactive applications where P99 latency matters more than throughput</li>\n<li><strong>Sequential Workloads</strong>: Applications with Amdahl\'s Law limits, legacy code that cannot be parallelized, algorithms with strong data dependencies</li>\n<li><strong>Single-Threaded Applications</strong>: Node.js event loops, Python GIL-bound code, JavaScript engines, database query execution (single query optimization)</li>\n<li><strong>Cache-Sensitive Workloads</strong>: Applications where cache locality matters more than parallelism (many scientific computing kernels, graph algorithms)</li>\n<li><strong>I/O-Bound Systems with Critical Paths</strong>: Systems where CPU work per request is minimal but latency is critical (API gateways, load balancers with simple routing logic)</li>\n<li><strong>Development and Testing</strong>: Faster iteration cycles when single-thread performance improves compile times and test execution speed</li>\n</ul>\n<h2 id=\"when-not-to-use-it\">When Not to Use It</h2>\n<ul>\n<li><strong>Highly Parallel Workloads</strong>: Data processing pipelines, batch jobs, scientific simulations with perfect parallelism (no shared state)</li>\n<li><strong>Request-Per-Thread Servers</strong>: Traditional threaded web servers handling thousands of concurrent connections (more cores allow more simultaneous request processing)</li>\n<li><strong>Cost-Optimized Deployments</strong>: When total compute capacity per dollar is the primary metric and latency requirements are relaxed</li>\n<li><strong>Embarrassingly Parallel Problems</strong>: Image processing, video encoding, Monte Carlo simulations where each unit of work is independent</li>\n<li><strong>Cloud Environments with Auto-Scaling</strong>: When horizontal scaling is cheaper than vertical scaling and workload can be distributed</li>\n<li><strong>Containers with Thread Pools</strong>: Applications using thread pools larger than available fast cores, where additional slow cores provide better resource utilization</li>\n</ul>\n<h2 id=\"performance-impact\">Performance Impact</h2>\n<p>Real-world observations show:</p>\n<p><strong>Latency Improvements</strong>: P50 latency reductions of 30-50% and P99 latency improvements of 40-60% in latency-sensitive applications. For example, a trading system reduced order processing latency from 85ms to 35ms by switching from 32 slow cores to 8 fast cores.</p>\n<p><strong>Single-Thread Throughput</strong>: 20-40% improvement in single-threaded benchmarks (SPEC CPU benchmarks show this consistently). JavaScript V8 benchmarks show 25-35% improvements on fast-core architectures.</p>\n<p><strong>Sequential Workload Throughput</strong>: Even with fewer total cores, applications with 10-20% sequential code show 15-30% better overall throughput because the critical path completes faster.</p>\n<p><strong>Resource Utilization</strong>: Lower CPU utilization (50-70% vs 80-95%) but better response time characteristics, indicating that cores are not the bottleneck but rather single-thread speed.</p>\n<p><strong>Energy Efficiency</strong>: Better performance per watt for single-threaded workloads, though total system power may be lower with fewer cores.</p>\n<h2 id=\"common-mistakes\">Common Mistakes</h2>\n<ul>\n<li><strong>Assuming More Cores Always Help</strong>: Adding cores to applications with sequential bottlenecks without profiling to identify the actual bottleneck</li>\n<li><strong>Ignoring Amdahl\'s Law</strong>: Failing to calculate theoretical speedup limits based on sequential code percentage</li>\n<li><strong>Over-Parallelization</strong>: Creating excessive threads that contend for fast cores, leading to context switching overhead that negates single-thread advantages</li>\n<li><strong>Mismatched Architecture Patterns</strong>: Using request-per-thread models (many threads) with fast-core architectures instead of event-driven or async models</li>\n<li><strong>Not Profiling Single-Thread Performance</strong>: Optimizing for multi-threaded scenarios without measuring whether single-thread speed is the actual constraint</li>\n<li><strong>Cache-Unaware Algorithms</strong>: Implementing algorithms that ignore cache locality, wasting the cache advantages of fast cores</li>\n<li><strong>Benchmarking Synthetic Loads</strong>: Testing with perfectly parallel synthetic workloads instead of realistic production traffic patterns</li>\n</ul>\n<h2 id=\"how-to-measure-and-validate\">How to Measure and Validate</h2>\n<p><strong>Profiling Tools</strong>:</p>\n<ul>\n<li>Use <code>perf</code> (Linux) to measure CPI (Cycles Per Instruction), cache misses, and branch mispredictions</li>\n<li>Profile with tools like <code>vtune</code> or <code>perf top</code> to identify if single-thread performance or parallelism is the bottleneck</li>\n<li>Measure IPC metrics: instructions retired per cycle should be higher on fast cores (typically 2-4 IPC vs 1-2 IPC on slow cores)</li>\n</ul>\n<p><strong>Key Metrics</strong>:</p>\n<ul>\n<li><strong>Latency Percentiles</strong>: Track P50, P95, P99 latency - fast cores should show lower tail latencies</li>\n<li><strong>Single-Thread Throughput</strong>: Benchmark single-threaded execution time for critical paths</li>\n<li><strong>CPU Utilization</strong>: Lower utilization with better performance indicates single-thread speedup</li>\n<li><strong>Context Switch Rate</strong>: Fewer context switches per request with fast cores</li>\n<li><strong>Cache Hit Rates</strong>: Monitor L1/L2/L3 cache hit ratios - fast cores should show better locality</li>\n</ul>\n<p><strong>Benchmarking Strategy</strong>:</p>\n<ol>\n<li>Run single-threaded benchmarks (SPEC CPU, single-threaded application tests)</li>\n<li>Measure critical path latency under production load</li>\n<li>Compare same workload on many-core vs few-core-fast systems</li>\n<li>Use realistic load patterns, not synthetic parallel workloads</li>\n<li>Measure tail latencies, not just averages</li>\n</ol>\n<p><strong>Production Validation</strong>:</p>\n<ul>\n<li>A/B test with canary deployments comparing core configurations</li>\n<li>Monitor application-level metrics (request latency, transaction completion time)</li>\n<li>Track system metrics (CPU utilization, context switches, cache performance)</li>\n<li>Validate that improvements translate to business metrics (user experience, revenue)</li>\n</ul>\n<h2 id=\"summary-and-key-takeaways\">Summary and Key Takeaways</h2>\n<p>The core principle: <strong>Fewer fast CPU cores outperform many slow cores when single-thread performance matters more than total parallel throughput</strong>. This trade-off is fundamental in CPU architecture and should guide hardware selection and system design.</p>\n<p>The main trade-off is between latency/sequential performance and total parallel capacity. Fast cores excel at reducing critical path latency and improving single-thread execution, while many-core systems excel at total throughput for parallelizable workloads.</p>\n<p><strong>Decision Guideline</strong>: Choose fast cores when (1) latency requirements are strict (P99 &lt; 100ms), (2) workloads have sequential dependencies (Amdahl\'s Law limits apply), (3) single-thread performance is the bottleneck (profiling confirms), or (4) cache locality matters more than parallelism. Choose many cores when (1) workloads are embarrassingly parallel, (2) total throughput is the primary metric, (3) cost per compute unit is critical, or (4) request-per-thread models handle massive concurrency.</p>\n<p>Always profile before deciding: measure IPC, latency percentiles, and identify whether the bottleneck is sequential execution or parallel capacity.</p>\n<!--kg-card-end: markdown-->','694f2cf37f4d7d685707e403','Prefer Fewer Fast CPU Cores Over Many Slow Ones for Latency-Sensitive Workloads\n\n\n\nSubtitle\n\n\nUnderstanding the trade-off between CPU core count and single-thread performance is critical for optimizing latency-sensitive applications where sequential execution matters more than raw parallelism.\n\n\n\nExecutive Summary (TL;DR)\n\n\nChoosing fewer fast CPU cores over many slow cores is a performance principle that prioritizes single-thread performance and instruction-level parallelism (IPC) over core count. This approach delivers 20-40% better single-threaded performance, significantly lower latency for critical operations (often reducing response times from 50-100ms to 20-40ms), and improved throughput for applications with sequential dependencies. However, it sacrifices overall parallel throughput and scales poorly for highly concurrent workloads. Use this approach when latency matters more than throughput, for single-threaded applications, or when Amdahl\'s Law limits parallel speedup.\n\n\n\nProblem Context\n\n\nA common misconception in performance optimization is that more CPU cores always translate to better performance. Engineers often scale systems horizontally by adding cores without considering single-thread performance characteristics. This leads to scenarios where applications with sequential bottlenecks or latency-sensitive operations underperform despite high core counts.\n\n\nMany production systems suffer from this because modern CPUs designed for high core counts (such as some server-class processors) prioritize parallelism over single-thread speed. These processors trade higher clock frequencies and aggressive out-of-order execution for more cores, resulting in lower IPC (Instructions Per Cycle) and slower individual core performance.\n\n\nNaive scaling attempts often fail because:\n\n\n * Sequential dependencies prevent effective parallelization (Amdahl\'s Law)\n * Synchronization overhead increases with more cores\n * Cache coherency traffic scales non-linearly with core count\n * Critical paths remain bounded by single-thread performance\n\n\n\nHow It Works\n\n\nCPU performance is determined by three key factors: clock frequency, IPC (Instructions Per Cycle), and core count. Fast cores achieve higher performance through:\n\n\nClock Frequency: Higher clock rates allow more instructions to execute per second. Modern fast cores (e.g., Intel Core series, AMD Ryzen high-frequency variants) run at 4-6 GHz, while many-core processors often operate at 2-3 GHz.\n\n\nInstruction-Level Parallelism (IPC): Fast cores employ deeper pipelines, wider execution units, larger instruction windows, and more aggressive branch prediction. This allows them to extract more parallelism from sequential code, executing multiple independent instructions simultaneously within a single thread.\n\n\nCache Hierarchy: Fast cores typically feature larger, faster L1 and L2 caches per core, reducing memory latency for single-threaded workloads. They also have better prefetching logic that predicts memory access patterns.\n\n\nOut-of-Order Execution: Advanced out-of-order execution engines can reorder and parallelize independent instructions within a single thread, effectively creating instruction-level parallelism without explicit multi-threading.\n\n\nWhen a workload has sequential dependencies or Amdahl\'s Law limits parallel speedup, a single fast core can outperform multiple slow cores by completing the critical path faster, even if total theoretical throughput is lower.\n\n\n\nWhy This Becomes a Bottleneck\n\n\nPerformance degrades when core speed is sacrificed for core count because:\n\n\nSequential Bottlenecks: Every parallel algorithm has sequential portions (data distribution, result aggregation, synchronization). Amdahl\'s Law shows that even 5% sequential code limits speedup to 20x regardless of core count. Fast cores reduce the time spent in sequential sections.\n\n\nSynchronization Overhead: More cores require more synchronization primitives (locks, barriers, atomic operations). Each synchronization point introduces latency and serialization. Fast cores reduce the time each thread spends in critical sections, decreasing contention window duration.\n\n\nCache Coherency Traffic: With more cores, cache line invalidation and data movement between caches increase exponentially. Fast cores with better cache locality generate less coherency traffic per unit of work.\n\n\nMemory Bandwidth Contention: Multiple slow cores saturate memory bandwidth more easily because each core takes longer to complete operations, keeping memory buses occupied longer. Fast cores complete memory operations faster, freeing bandwidth sooner.\n\n\nLatency Amplification: In request-response systems, latency is determined by the slowest path. Even if 99% of work is parallelized, the 1% sequential portion (often I/O or serialization) determines P99 latency. Fast cores reduce this critical path latency.\n\n\n\nAdvantages\n\n\n * Superior Single-Thread Performance: 20-40% better performance on single-threaded workloads compared to many-core processors with lower IPC\n * Reduced Latency: Critical operations complete 50-100% faster (e.g., reducing response times from 50-100ms to 20-40ms in observed benchmarks)\n * Lower Synchronization Overhead: Fewer cores mean fewer lock contentions, atomic operations, and cache coherency messages\n * Better Cache Locality: Larger per-core caches and fewer threads reduce cache misses and improve memory access patterns\n * Simpler Architecture: Less need for complex thread pools, work-stealing schedulers, and parallel algorithms\n * Predictable Performance: More deterministic latency characteristics, crucial for real-time systems\n * Higher Throughput for Sequential Workloads: Applications that cannot be parallelized achieve 15-30% better throughput even with fewer total cores\n\n\n\nDisadvantages and Trade-offs\n\n\n * Limited Parallel Throughput: Cannot match the total compute capacity of many-core systems for embarrassingly parallel workloads\n * Higher Per-Core Cost: Fast cores with advanced microarchitecture features are more expensive to manufacture\n * Poor Scalability for Concurrent Workloads: Request-per-thread server models (like traditional web servers) benefit less when request count exceeds fast core count\n * Lower Total Compute Capacity: Cannot execute as many independent threads simultaneously\n * Underutilization Risk: If workloads can be fully parallelized, fast cores may sit idle while waiting for I/O, wasting resources\n * Memory Bandwidth Limits: Fewer cores mean fewer memory controllers, potentially limiting memory bandwidth for data-parallel workloads\n\n\n\nWhen to Use This Approach\n\n\n * Latency-Sensitive Applications: Real-time systems, trading platforms, gaming servers, interactive applications where P99 latency matters more than throughput\n * Sequential Workloads: Applications with Amdahl\'s Law limits, legacy code that cannot be parallelized, algorithms with strong data dependencies\n * Single-Threaded Applications: Node.js event loops, Python GIL-bound code, JavaScript engines, database query execution (single query optimization)\n * Cache-Sensitive Workloads: Applications where cache locality matters more than parallelism (many scientific computing kernels, graph algorithms)\n * I/O-Bound Systems with Critical Paths: Systems where CPU work per request is minimal but latency is critical (API gateways, load balancers with simple routing logic)\n * Development and Testing: Faster iteration cycles when single-thread performance improves compile times and test execution speed\n\n\n\nWhen Not to Use It\n\n\n * Highly Parallel Workloads: Data processing pipelines, batch jobs, scientific simulations with perfect parallelism (no shared state)\n * Request-Per-Thread Servers: Traditional threaded web servers handling thousands of concurrent connections (more cores allow more simultaneous request processing)\n * Cost-Optimized Deployments: When total compute capacity per dollar is the primary metric and latency requirements are relaxed\n * Embarrassingly Parallel Problems: Image processing, video encoding, Monte Carlo simulations where each unit of work is independent\n * Cloud Environments with Auto-Scaling: When horizontal scaling is cheaper than vertical scaling and workload can be distributed\n * Containers with Thread Pools: Applications using thread pools larger than available fast cores, where additional slow cores provide better resource utilization\n\n\n\nPerformance Impact\n\n\nReal-world observations show:\n\n\nLatency Improvements: P50 latency reductions of 30-50% and P99 latency improvements of 40-60% in latency-sensitive applications. For example, a trading system reduced order processing latency from 85ms to 35ms by switching from 32 slow cores to 8 fast cores.\n\n\nSingle-Thread Throughput: 20-40% improvement in single-threaded benchmarks (SPEC CPU benchmarks show this consistently). JavaScript V8 benchmarks show 25-35% improvements on fast-core architectures.\n\n\nSequential Workload Throughput: Even with fewer total cores, applications with 10-20% sequential code show 15-30% better overall throughput because the critical path completes faster.\n\n\nResource Utilization: Lower CPU utilization (50-70% vs 80-95%) but better response time characteristics, indicating that cores are not the bottleneck but rather single-thread speed.\n\n\nEnergy Efficiency: Better performance per watt for single-threaded workloads, though total system power may be lower with fewer cores.\n\n\n\nCommon Mistakes\n\n\n * Assuming More Cores Always Help: Adding cores to applications with sequential bottlenecks without profiling to identify the actual bottleneck\n * Ignoring Amdahl\'s Law: Failing to calculate theoretical speedup limits based on sequential code percentage\n * Over-Parallelization: Creating excessive threads that contend for fast cores, leading to context switching overhead that negates single-thread advantages\n * Mismatched Architecture Patterns: Using request-per-thread models (many threads) with fast-core architectures instead of event-driven or async models\n * Not Profiling Single-Thread Performance: Optimizing for multi-threaded scenarios without measuring whether single-thread speed is the actual constraint\n * Cache-Unaware Algorithms: Implementing algorithms that ignore cache locality, wasting the cache advantages of fast cores\n * Benchmarking Synthetic Loads: Testing with perfectly parallel synthetic workloads instead of realistic production traffic patterns\n\n\n\nHow to Measure and Validate\n\n\nProfiling Tools:\n\n\n * Use perf (Linux) to measure CPI (Cycles Per Instruction), cache misses, and branch mispredictions\n * Profile with tools like vtune or perf top to identify if single-thread performance or parallelism is the bottleneck\n * Measure IPC metrics: instructions retired per cycle should be higher on fast cores (typically 2-4 IPC vs 1-2 IPC on slow cores)\n\n\nKey Metrics:\n\n\n * Latency Percentiles: Track P50, P95, P99 latency - fast cores should show lower tail latencies\n * Single-Thread Throughput: Benchmark single-threaded execution time for critical paths\n * CPU Utilization: Lower utilization with better performance indicates single-thread speedup\n * Context Switch Rate: Fewer context switches per request with fast cores\n * Cache Hit Rates: Monitor L1/L2/L3 cache hit ratios - fast cores should show better locality\n\n\nBenchmarking Strategy:\n\n\n 1. Run single-threaded benchmarks (SPEC CPU, single-threaded application tests)\n 2. Measure critical path latency under production load\n 3. Compare same workload on many-core vs few-core-fast systems\n 4. Use realistic load patterns, not synthetic parallel workloads\n 5. Measure tail latencies, not just averages\n\n\nProduction Validation:\n\n\n * A/B test with canary deployments comparing core configurations\n * Monitor application-level metrics (request latency, transaction completion time)\n * Track system metrics (CPU utilization, context switches, cache performance)\n * Validate that improvements translate to business metrics (user experience, revenue)\n\n\n\nSummary and Key Takeaways\n\n\nThe core principle: Fewer fast CPU cores outperform many slow cores when single-thread performance matters more than total parallel throughput. This trade-off is fundamental in CPU architecture and should guide hardware selection and system design.\n\n\nThe main trade-off is between latency/sequential performance and total parallel capacity. Fast cores excel at reducing critical path latency and improving single-thread execution, while many-core systems excel at total throughput for parallelizable workloads.\n\n\nDecision Guideline: Choose fast cores when (1) latency requirements are strict (P99 < 100ms), (2) workloads have sequential dependencies (Amdahl\'s Law limits apply), (3) single-thread performance is the bottleneck (profiling confirms), or (4) cache locality matters more than parallelism. Choose many cores when (1) workloads are embarrassingly parallel, (2) total throughput is the primary metric, (3) cost per compute unit is critical, or (4) request-per-thread models handle massive concurrency.\n\n\nAlways profile before deciding: measure IPC, latency percentiles, and identify whether the bottleneck is sequential execution or parallel capacity.\n',NULL,0,'post','published',NULL,'public','all','2025-12-27 00:48:51','2025-12-27 01:04:19','2025-12-27 00:48:52','694f2665c3e44e650f0e5dd8',NULL,NULL,NULL,NULL,NULL,NULL,1);
/*!40000 ALTER TABLE `posts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `posts_authors`
--

DROP TABLE IF EXISTS `posts_authors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `posts_authors` (
  `id` varchar(24) NOT NULL,
  `post_id` varchar(24) NOT NULL,
  `author_id` varchar(24) NOT NULL,
  `sort_order` int unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `posts_authors_post_id_foreign` (`post_id`),
  KEY `posts_authors_author_id_foreign` (`author_id`),
  CONSTRAINT `posts_authors_author_id_foreign` FOREIGN KEY (`author_id`) REFERENCES `users` (`id`),
  CONSTRAINT `posts_authors_post_id_foreign` FOREIGN KEY (`post_id`) REFERENCES `posts` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `posts_authors`
--

LOCK TABLES `posts_authors` WRITE;
/*!40000 ALTER TABLE `posts_authors` DISABLE KEYS */;
INSERT INTO `posts_authors` VALUES ('694f2666c3e44e650f0e5e6b','694f2666c3e44e650f0e5e6a','694f2665c3e44e650f0e5dd8',0),('694f2cf47f4d7d685707e40a','694f2cf37f4d7d685707e403','694f2665c3e44e650f0e5dd8',0);
/*!40000 ALTER TABLE `posts_authors` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `posts_meta`
--

DROP TABLE IF EXISTS `posts_meta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `posts_meta` (
  `id` varchar(24) NOT NULL,
  `post_id` varchar(24) NOT NULL,
  `og_image` varchar(2000) DEFAULT NULL,
  `og_title` varchar(300) DEFAULT NULL,
  `og_description` varchar(500) DEFAULT NULL,
  `twitter_image` varchar(2000) DEFAULT NULL,
  `twitter_title` varchar(300) DEFAULT NULL,
  `twitter_description` varchar(500) DEFAULT NULL,
  `meta_title` varchar(2000) DEFAULT NULL,
  `meta_description` varchar(2000) DEFAULT NULL,
  `email_subject` varchar(300) DEFAULT NULL,
  `frontmatter` text,
  `feature_image_alt` varchar(2000) DEFAULT NULL,
  `feature_image_caption` text,
  `email_only` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `posts_meta_post_id_unique` (`post_id`),
  CONSTRAINT `posts_meta_post_id_foreign` FOREIGN KEY (`post_id`) REFERENCES `posts` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `posts_meta`
--

LOCK TABLES `posts_meta` WRITE;
/*!40000 ALTER TABLE `posts_meta` DISABLE KEYS */;
/*!40000 ALTER TABLE `posts_meta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `posts_products`
--

DROP TABLE IF EXISTS `posts_products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `posts_products` (
  `id` varchar(24) NOT NULL,
  `post_id` varchar(24) NOT NULL,
  `product_id` varchar(24) NOT NULL,
  `sort_order` int unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `posts_products_post_id_foreign` (`post_id`),
  KEY `posts_products_product_id_foreign` (`product_id`),
  CONSTRAINT `posts_products_post_id_foreign` FOREIGN KEY (`post_id`) REFERENCES `posts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `posts_products_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `posts_products`
--

LOCK TABLES `posts_products` WRITE;
/*!40000 ALTER TABLE `posts_products` DISABLE KEYS */;
INSERT INTO `posts_products` VALUES ('694f30937f4d7d685707e41a','694f2cf37f4d7d685707e403','694f2665c3e44e650f0e5de8',0);
/*!40000 ALTER TABLE `posts_products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `posts_tags`
--

DROP TABLE IF EXISTS `posts_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `posts_tags` (
  `id` varchar(24) NOT NULL,
  `post_id` varchar(24) NOT NULL,
  `tag_id` varchar(24) NOT NULL,
  `sort_order` int unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `posts_tags_tag_id_foreign` (`tag_id`),
  KEY `posts_tags_post_id_tag_id_index` (`post_id`,`tag_id`),
  CONSTRAINT `posts_tags_post_id_foreign` FOREIGN KEY (`post_id`) REFERENCES `posts` (`id`),
  CONSTRAINT `posts_tags_tag_id_foreign` FOREIGN KEY (`tag_id`) REFERENCES `tags` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `posts_tags`
--

LOCK TABLES `posts_tags` WRITE;
/*!40000 ALTER TABLE `posts_tags` DISABLE KEYS */;
INSERT INTO `posts_tags` VALUES ('694f2cf47f4d7d685707e404','694f2cf37f4d7d685707e403','694f2cf27f4d7d685707e3f7',0),('694f2cf47f4d7d685707e405','694f2cf37f4d7d685707e403','694f2cf37f4d7d685707e3f9',1),('694f2cf47f4d7d685707e406','694f2cf37f4d7d685707e403','694f2cf37f4d7d685707e3fb',2),('694f2cf47f4d7d685707e407','694f2cf37f4d7d685707e403','694f2cf37f4d7d685707e3fd',3),('694f2cf47f4d7d685707e408','694f2cf37f4d7d685707e403','694f2cf37f4d7d685707e3ff',4),('694f2cf47f4d7d685707e409','694f2cf37f4d7d685707e403','694f2cf37f4d7d685707e401',5);
/*!40000 ALTER TABLE `posts_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `products` (
  `id` varchar(24) NOT NULL,
  `name` varchar(191) NOT NULL,
  `slug` varchar(191) NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `welcome_page_url` varchar(2000) DEFAULT NULL,
  `visibility` varchar(50) NOT NULL DEFAULT 'none',
  `trial_days` int unsigned NOT NULL DEFAULT '0',
  `description` varchar(191) DEFAULT NULL,
  `type` varchar(50) NOT NULL DEFAULT 'paid',
  `currency` varchar(50) DEFAULT NULL,
  `monthly_price` int unsigned DEFAULT NULL,
  `yearly_price` int unsigned DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  `monthly_price_id` varchar(24) DEFAULT NULL,
  `yearly_price_id` varchar(24) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `products_slug_unique` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products`
--

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` VALUES ('694f2665c3e44e650f0e5de7','Free','free',1,NULL,'public',0,NULL,'free',NULL,NULL,NULL,'2025-12-27 00:20:53','2025-12-27 00:20:53',NULL,NULL),('694f2665c3e44e650f0e5de8','Performance Engineering','default-product',1,NULL,'public',0,NULL,'paid','USD',500,5000,'2025-12-27 00:20:53','2025-12-27 00:21:16',NULL,NULL);
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products_benefits`
--

DROP TABLE IF EXISTS `products_benefits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `products_benefits` (
  `id` varchar(24) NOT NULL,
  `product_id` varchar(24) NOT NULL,
  `benefit_id` varchar(24) NOT NULL,
  `sort_order` int unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `products_benefits_product_id_foreign` (`product_id`),
  KEY `products_benefits_benefit_id_foreign` (`benefit_id`),
  CONSTRAINT `products_benefits_benefit_id_foreign` FOREIGN KEY (`benefit_id`) REFERENCES `benefits` (`id`) ON DELETE CASCADE,
  CONSTRAINT `products_benefits_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products_benefits`
--

LOCK TABLES `products_benefits` WRITE;
/*!40000 ALTER TABLE `products_benefits` DISABLE KEYS */;
/*!40000 ALTER TABLE `products_benefits` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recommendation_click_events`
--

DROP TABLE IF EXISTS `recommendation_click_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `recommendation_click_events` (
  `id` varchar(24) NOT NULL,
  `recommendation_id` varchar(24) NOT NULL,
  `member_id` varchar(24) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `recommendation_click_events_recommendation_id_foreign` (`recommendation_id`),
  KEY `recommendation_click_events_member_id_foreign` (`member_id`),
  CONSTRAINT `recommendation_click_events_member_id_foreign` FOREIGN KEY (`member_id`) REFERENCES `members` (`id`) ON DELETE SET NULL,
  CONSTRAINT `recommendation_click_events_recommendation_id_foreign` FOREIGN KEY (`recommendation_id`) REFERENCES `recommendations` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recommendation_click_events`
--

LOCK TABLES `recommendation_click_events` WRITE;
/*!40000 ALTER TABLE `recommendation_click_events` DISABLE KEYS */;
/*!40000 ALTER TABLE `recommendation_click_events` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recommendation_subscribe_events`
--

DROP TABLE IF EXISTS `recommendation_subscribe_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `recommendation_subscribe_events` (
  `id` varchar(24) NOT NULL,
  `recommendation_id` varchar(24) NOT NULL,
  `member_id` varchar(24) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `recommendation_subscribe_events_recommendation_id_foreign` (`recommendation_id`),
  KEY `recommendation_subscribe_events_member_id_foreign` (`member_id`),
  CONSTRAINT `recommendation_subscribe_events_member_id_foreign` FOREIGN KEY (`member_id`) REFERENCES `members` (`id`) ON DELETE SET NULL,
  CONSTRAINT `recommendation_subscribe_events_recommendation_id_foreign` FOREIGN KEY (`recommendation_id`) REFERENCES `recommendations` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recommendation_subscribe_events`
--

LOCK TABLES `recommendation_subscribe_events` WRITE;
/*!40000 ALTER TABLE `recommendation_subscribe_events` DISABLE KEYS */;
/*!40000 ALTER TABLE `recommendation_subscribe_events` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recommendations`
--

DROP TABLE IF EXISTS `recommendations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `recommendations` (
  `id` varchar(24) NOT NULL,
  `url` varchar(2000) NOT NULL,
  `title` varchar(2000) NOT NULL,
  `excerpt` varchar(2000) DEFAULT NULL,
  `featured_image` varchar(2000) DEFAULT NULL,
  `favicon` varchar(2000) DEFAULT NULL,
  `description` varchar(2000) DEFAULT NULL,
  `one_click_subscribe` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recommendations`
--

LOCK TABLES `recommendations` WRITE;
/*!40000 ALTER TABLE `recommendations` DISABLE KEYS */;
/*!40000 ALTER TABLE `recommendations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `redirects`
--

DROP TABLE IF EXISTS `redirects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `redirects` (
  `id` varchar(24) NOT NULL,
  `from` varchar(191) NOT NULL,
  `to` varchar(2000) NOT NULL,
  `post_id` varchar(24) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `redirects_from_index` (`from`),
  KEY `redirects_post_id_foreign` (`post_id`),
  CONSTRAINT `redirects_post_id_foreign` FOREIGN KEY (`post_id`) REFERENCES `posts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `redirects`
--

LOCK TABLES `redirects` WRITE;
/*!40000 ALTER TABLE `redirects` DISABLE KEYS */;
/*!40000 ALTER TABLE `redirects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `roles` (
  `id` varchar(24) NOT NULL,
  `name` varchar(50) NOT NULL,
  `description` varchar(2000) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `roles_name_unique` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES ('694f2665c3e44e650f0e5dd9','Administrator','Administrators','2025-12-27 00:20:53','2025-12-27 00:20:53'),('694f2665c3e44e650f0e5dda','Editor','Editors','2025-12-27 00:20:53','2025-12-27 00:20:53'),('694f2665c3e44e650f0e5ddb','Author','Authors','2025-12-27 00:20:53','2025-12-27 00:20:53'),('694f2665c3e44e650f0e5ddc','Contributor','Contributors','2025-12-27 00:20:53','2025-12-27 00:20:53'),('694f2665c3e44e650f0e5ddd','Owner','Blog Owner','2025-12-27 00:20:53','2025-12-27 00:20:53'),('694f2665c3e44e650f0e5dde','Admin Integration','External Apps','2025-12-27 00:20:53','2025-12-27 00:20:53'),('694f2665c3e44e650f0e5ddf','Ghost Explore Integration','Internal Integration for the Ghost Explore directory','2025-12-27 00:20:53','2025-12-27 00:20:53'),('694f2665c3e44e650f0e5de0','Self-Serve Migration Integration','Internal Integration for the Self-Serve migration tool','2025-12-27 00:20:53','2025-12-27 00:20:53'),('694f2665c3e44e650f0e5de1','DB Backup Integration','Internal DB Backup Client','2025-12-27 00:20:53','2025-12-27 00:20:53'),('694f2665c3e44e650f0e5de2','Scheduler Integration','Internal Scheduler Client','2025-12-27 00:20:53','2025-12-27 00:20:53'),('694f2665c3e44e650f0e5de3','Super Editor','Super Editors','2025-12-27 00:20:53','2025-12-27 00:20:53');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles_users`
--

DROP TABLE IF EXISTS `roles_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `roles_users` (
  `id` varchar(24) NOT NULL,
  `role_id` varchar(24) NOT NULL,
  `user_id` varchar(24) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles_users`
--

LOCK TABLES `roles_users` WRITE;
/*!40000 ALTER TABLE `roles_users` DISABLE KEYS */;
INSERT INTO `roles_users` VALUES ('694f2665c3e44e650f0e5de4','694f2665c3e44e650f0e5ddd','694f2665c3e44e650f0e5dd8');
/*!40000 ALTER TABLE `roles_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions` (
  `id` varchar(24) NOT NULL,
  `session_id` varchar(32) NOT NULL,
  `user_id` varchar(24) NOT NULL,
  `session_data` varchar(2000) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sessions_session_id_unique` (`session_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
INSERT INTO `sessions` VALUES ('694f267dc3e44e650f0e60ad','putoKY_Z--3Hf3czNO8o3JGCCtlTvwp8','694f2665c3e44e650f0e5dd8','{\"cookie\":{\"originalMaxAge\":15552000000,\"expires\":\"2026-06-25T00:21:17.168Z\",\"secure\":false,\"httpOnly\":true,\"path\":\"/ghost\",\"sameSite\":\"lax\"},\"user_id\":\"694f2665c3e44e650f0e5dd8\",\"origin\":\"http://66.179.188.92\",\"user_agent\":\"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36\",\"ip\":\"71.197.40.32\",\"verified\":true}','2025-12-27 00:21:17','2025-12-27 00:21:17'),('694f2c1e7f4d7d685707e3f0','zDWnWIEJdLIqc1Ui6_m3xShJ7uK1shmS','694f2665c3e44e650f0e5dd8','{\"cookie\":{\"originalMaxAge\":15552000000,\"expires\":\"2026-06-25T00:45:45.076Z\",\"secure\":true,\"httpOnly\":true,\"path\":\"/ghost\",\"sameSite\":\"none\"},\"user_id\":\"694f2665c3e44e650f0e5dd8\",\"origin\":\"https://perfstack.dev\",\"user_agent\":\"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36\",\"ip\":\"2601:346:900:235d:e93a:71e3:7e64:1c37\",\"verified\":true}','2025-12-27 00:45:19','2025-12-27 00:45:45');
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `settings`
--

DROP TABLE IF EXISTS `settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `settings` (
  `id` varchar(24) NOT NULL,
  `group` varchar(50) NOT NULL DEFAULT 'core',
  `key` varchar(50) NOT NULL,
  `value` text,
  `type` varchar(50) NOT NULL,
  `flags` varchar(50) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `settings_key_unique` (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `settings`
--

LOCK TABLES `settings` WRITE;
/*!40000 ALTER TABLE `settings` DISABLE KEYS */;
INSERT INTO `settings` VALUES ('694f2666c3e44e650f0e6021','core','last_mentions_report_email_timestamp',NULL,'number',NULL,'2025-12-26 19:20:54','2025-12-26 19:20:54'),('694f2666c3e44e650f0e6022','core','db_hash','f65b9a89-47db-44a6-975a-27ddbd1bc743','string',NULL,'2025-12-26 19:20:54','2025-12-26 19:20:54'),('694f2666c3e44e650f0e6023','core','routes_hash','3d180d52c663d173a6be791ef411ed01','string',NULL,'2025-12-26 19:20:54','2025-12-27 00:20:55'),('694f2666c3e44e650f0e6024','core','next_update_check','1766881264','number',NULL,'2025-12-26 19:20:54','2025-12-27 00:21:03'),('694f2666c3e44e650f0e6025','core','notifications','[{\"dismissible\":true,\"location\":\"bottom\",\"status\":\"alert\",\"id\":\"694f267ec3e44e650f0e60b0\",\"createdAtVersion\":\"6.10.3\",\"type\":\"warn\",\"message\":\"Ghost is currently unable to send email. See https://ghost.org/docs/concepts/config/#mail for instructions.\",\"seen\":false,\"addedAt\":\"2025-12-27T00:21:18.189Z\"}]','array',NULL,'2025-12-26 19:20:54','2025-12-27 00:21:18'),('694f2666c3e44e650f0e6026','core','version_notifications','[]','array',NULL,'2025-12-26 19:20:54','2025-12-26 19:20:54'),('694f2666c3e44e650f0e6027','core','admin_session_secret','00c38d0768005006f6e0558cdf8985dbcb887ec1c1d9a040adfbdb51e2a9e172','string',NULL,'2025-12-26 19:20:54','2025-12-26 19:20:54'),('694f2666c3e44e650f0e6028','core','theme_session_secret','31c19922583bce601bad6b00fc8f5cd38ed16842239add05f536e271e8076f5a','string',NULL,'2025-12-26 19:20:54','2025-12-26 19:20:54'),('694f2666c3e44e650f0e6029','core','ghost_public_key','-----BEGIN RSA PUBLIC KEY-----\nMIGJAoGBAJUy8d4yNoonmeHuGJHcAFIZQ5E7+Pyf5Nxj5qlb3ZztIsKxiFj9kyLI8+vi0Jmh\nc13W499zkKS3MV4dygyKrhEfE6q0OapUNV5ONNTpRxPfDr9Q6MLn84wrC/CxiInGG0+6GV90\nFIdzYYzw3h48DguWCvGsYPZKCHaOTTk4n3E9AgMBAAE=\n-----END RSA PUBLIC KEY-----\n','string',NULL,'2025-12-26 19:20:54','2025-12-26 19:20:54'),('694f2666c3e44e650f0e602a','core','ghost_private_key','-----BEGIN RSA PRIVATE KEY-----\nMIICXAIBAAKBgQCVMvHeMjaKJ5nh7hiR3ABSGUORO/j8n+TcY+apW92c7SLCsYhY/ZMiyPPr\n4tCZoXNd1uPfc5CktzFeHcoMiq4RHxOqtDmqVDVeTjTU6UcT3w6/UOjC5/OMKwvwsYiJxhtP\nuhlfdBSHc2GM8N4ePA4LlgrxrGD2Sgh2jk05OJ9xPQIDAQABAoGAELNrL5wfTsewCgJE7c7a\nmlYJojA8ZsrfK2xjXYHTBMXmpjSJNqzr03D7HOR+xTO1XkO3rkOZZVa8R/S9sTm00jly3P2m\nWJy46XbMW28WwpUIU1uQpsufHaA929HiAijXACrpO53FS1Zt10P8JhJc0S1qHd5PnPpd9AvY\nYuPfSAECQQDm9XiWQNYW93sj0KQLGlvFIVtj2GhXy6OmG+jXg/FbRvSG6VQHDPEY4yQaszZU\nSJN/wJqJxbxGX1VqFb9V017BAkEApWAidzC5VOsJbBKYUfREq9UWvS+J34Nu0rRs6654NpWB\n8CNBD8EyjzdNIoqW/2ZtZpOl2La/8odntYKeB5JtfQJASzNkJzBHRUUhoEDAGSlk9iPtWO5O\n0z9oMp7lyr6YaMsKtZ7lkEIjgqH60ILHztuuwysYZoGu0w8Zhag9G5nuQQJABiEbBenjZJdV\ngRDrXlY8WVYLgrWJWaRobhzL0KxlvjgqWbkkxy207wPwsvAKCqtEMMIWKoMTeCy2lk6iBsvR\njQJBAJ1OlplFIgu8kbb/kxLVIDkjWUBbGnkSN/HqldJoplO6ixXqJeVLZQ9Y6cXjnlUiWI1b\nnx3s5SzffZS7M+8K+wY=\n-----END RSA PRIVATE KEY-----\n','string',NULL,'2025-12-26 19:20:54','2025-12-26 19:20:54'),('694f2666c3e44e650f0e602b','core','members_public_key','-----BEGIN RSA PUBLIC KEY-----\nMIGJAoGBAKb05zWZPPLAbfxWd6RpccCCkfSEjkkMN5MrOFMOihtJOukSRWy0/EiY8DCl5bIZ\nLv3MEigo4k3dXmreUO52B2l21At74MHTCUeZHmUaNozi5yBq1skHjHwmyQ7qqQ5noaWGUeTz\nr1BmUyRUIfN5DdZekgCXmrOD7r/uFS0SjB/JAgMBAAE=\n-----END RSA PUBLIC KEY-----\n','string',NULL,'2025-12-26 19:20:54','2025-12-26 19:20:54'),('694f2666c3e44e650f0e602c','core','members_private_key','-----BEGIN RSA PRIVATE KEY-----\nMIICXQIBAAKBgQCm9Oc1mTzywG38VnekaXHAgpH0hI5JDDeTKzhTDoobSTrpEkVstPxImPAw\npeWyGS79zBIoKOJN3V5q3lDudgdpdtQLe+DB0wlHmR5lGjaM4ucgatbJB4x8JskO6qkOZ6Gl\nhlHk869QZlMkVCHzeQ3WXpIAl5qzg+6/7hUtEowfyQIDAQABAoGBAI8HxkA7zGQnCNKh/ROE\nJiiHc6ToHsFjzwSshS9aiGSB4w8jUQilMHC9XSBAL7zZKFHTj0aKZ/3PBQFG/kycHxIPKezo\nvAggS3jyZEFlkADwXeXEYjtQ8BBPTidwyZsoa+jSF/jpmGH6rm6OYNXyodausq8PMgku3K9/\nCKmqNgLRAkEA2rTJPi0hN+eHs348hcQz8GZ1R3wVcAFF6W7Py/wQ7wRqxAmMAGXjD7RSAVGy\nF8G2gIU+DzZvtLfwkp3x7JY+1QJBAMNtFix/nKDlo5UUNy48gVEFD6PYLwd/wJ4yYN2o7YDT\nZGW6T4XkGb3wh2e7M76iQRrF8gyVc83ydtQ1WIt0XyUCQQDMX4h3G8Eg9rEuoFZ6QgCvM2+A\n34lA40+rdauk2OYSFTSYALvdW1i1wjGnneoonRKoQtrdaGc2n3Sl7ga2qSgJAkBaW6/q9z4W\nbtdJ8MTqzfME4RAwM57bGsiW3LhJBPh7nkJHfvOR9ruoRPR2k+oC9MaheHDIPLoEuV0UFW5R\nXIc5AkAejZTd+whjGu0xEyzQ3w86Yfol6CjSvZRq4sBoODapWCxkNpJ0j9MepuEmwW72Xph+\nufN+kPJ+P6lIVeiMzZRQ\n-----END RSA PRIVATE KEY-----\n','string',NULL,'2025-12-26 19:20:54','2025-12-26 19:20:54'),('694f2666c3e44e650f0e602d','core','members_email_auth_secret','6e2ab2ea64490a4d42cab0d00932e51ec643e17e23b23f2cf0b8dc68ccceb186393022b45d2a464b8b8eaf7686b2949f3a2917baa40a016df7d27f0be2b65a2a','string',NULL,'2025-12-26 19:20:54','2025-12-26 19:20:54'),('694f2666c3e44e650f0e602e','core','members_stripe_webhook_id',NULL,'string',NULL,'2025-12-26 19:20:54','2025-12-26 19:20:54'),('694f2666c3e44e650f0e602f','core','members_stripe_webhook_secret',NULL,'string',NULL,'2025-12-26 19:20:54','2025-12-26 19:20:54'),('694f2666c3e44e650f0e6030','core','members_otc_secret','a73ac404f65ad3b57aace5cd70862c30f25bfe7a3cfc0b2b86071f546f05596577f9056a4c4138c3b0c7ed5e058ca2cd15b22c154dc6975ecf58b566f8874e03','string',NULL,'2025-12-26 19:20:54','2025-12-26 19:20:54'),('694f2666c3e44e650f0e6031','core','site_uuid','9432f6a0-3ed4-411f-a68d-fa288071ec6a','string','PUBLIC,RO','2025-12-26 19:20:54','2025-12-26 19:20:54'),('694f2666c3e44e650f0e6032','site','title','PerfStack – Performance Engineering, Backend & Web Speed','string','PUBLIC','2025-12-26 19:20:54','2025-12-27 01:00:45'),('694f2666c3e44e650f0e6033','site','description','Performance engineering, backend optimization, scalability, caching, and web speed explained clearly for engineers.','string','PUBLIC','2025-12-26 19:20:54','2025-12-27 01:00:45'),('694f2666c3e44e650f0e6034','site','heading_font','','string',NULL,'2025-12-26 19:20:54','2025-12-26 19:20:54'),('694f2666c3e44e650f0e6035','site','body_font','','string',NULL,'2025-12-26 19:20:54','2025-12-26 19:20:54'),('694f2666c3e44e650f0e6036','site','logo','','string',NULL,'2025-12-26 19:20:54','2025-12-26 19:20:54'),('694f2666c3e44e650f0e6037','site','cover_image','https://images.unsplash.com/photo-1766324934839-313529832615?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3wxMTc3M3wwfDF8YWxsfDc1fHx8fHx8fHwxNzY2NzkzODE0fA&ixlib=rb-4.1.0&q=80&w=2000','string',NULL,'2025-12-26 19:20:54','2025-12-27 00:21:47'),('694f2666c3e44e650f0e6038','site','icon','','string',NULL,'2025-12-26 19:20:54','2025-12-26 19:20:54'),('694f2666c3e44e650f0e6039','site','accent_color','#FF1A75','string','PUBLIC','2025-12-26 19:20:54','2025-12-26 19:20:54'),('694f2666c3e44e650f0e603a','site','locale','en','string',NULL,'2025-12-26 19:20:54','2025-12-26 19:20:54'),('694f2666c3e44e650f0e603b','site','timezone','Etc/UTC','string',NULL,'2025-12-26 19:20:54','2025-12-26 19:20:54'),('694f2666c3e44e650f0e603c','site','codeinjection_head','<script async src=\"https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-2111779448500294\"\n     crossorigin=\"anonymous\"></script>','string',NULL,'2025-12-26 19:20:54','2025-12-27 00:52:05'),('694f2666c3e44e650f0e603d','site','codeinjection_foot','','string',NULL,'2025-12-26 19:20:54','2025-12-26 19:20:54'),('694f2666c3e44e650f0e603e','site','facebook','ghost','string',NULL,'2025-12-26 19:20:54','2025-12-26 19:20:54'),('694f2666c3e44e650f0e603f','site','twitter','@ghost','string',NULL,'2025-12-26 19:20:54','2025-12-26 19:20:54'),('694f2666c3e44e650f0e6040','site','navigation','[{\"label\":\"Home\",\"url\":\"/\"},{\"label\":\"About\",\"url\":\"/about/\"}]','array',NULL,'2025-12-26 19:20:54','2025-12-26 19:20:54'),('694f2666c3e44e650f0e6041','site','secondary_navigation','[{\"label\":\"Sign up\",\"url\":\"#/portal/\"}]','array',NULL,'2025-12-26 19:20:54','2025-12-26 19:20:54'),('694f2666c3e44e650f0e6042','site','meta_title',NULL,'string',NULL,'2025-12-26 19:20:54','2025-12-26 19:20:54'),('694f2666c3e44e650f0e6043','site','meta_description',NULL,'string',NULL,'2025-12-26 19:20:54','2025-12-26 19:20:54'),('694f2666c3e44e650f0e6044','site','og_image',NULL,'string',NULL,'2025-12-26 19:20:54','2025-12-26 19:20:54'),('694f2666c3e44e650f0e6045','site','og_title',NULL,'string',NULL,'2025-12-26 19:20:54','2025-12-26 19:20:54'),('694f2666c3e44e650f0e6046','site','og_description',NULL,'string',NULL,'2025-12-26 19:20:54','2025-12-26 19:20:54'),('694f2666c3e44e650f0e6047','site','twitter_image',NULL,'string',NULL,'2025-12-26 19:20:54','2025-12-26 19:20:54'),('694f2666c3e44e650f0e6048','site','twitter_title',NULL,'string',NULL,'2025-12-26 19:20:54','2025-12-26 19:20:54'),('694f2666c3e44e650f0e6049','site','twitter_description',NULL,'string',NULL,'2025-12-26 19:20:54','2025-12-26 19:20:54'),('694f2666c3e44e650f0e604a','theme','active_theme','source','string','RO','2025-12-26 19:20:54','2025-12-26 19:20:54'),('694f2666c3e44e650f0e604b','private','is_private','false','boolean',NULL,'2025-12-26 19:20:54','2025-12-26 19:20:54'),('694f2666c3e44e650f0e604c','private','password','','string',NULL,'2025-12-26 19:20:54','2025-12-26 19:20:54'),('694f2666c3e44e650f0e604d','private','public_hash','f74a92fb9fe69b517b343e10767257','string',NULL,'2025-12-26 19:20:54','2025-12-26 19:20:54'),('694f2666c3e44e650f0e604e','members','default_content_visibility','public','string',NULL,'2025-12-26 19:20:54','2025-12-26 19:20:54'),('694f2666c3e44e650f0e604f','members','default_content_visibility_tiers','[]','array',NULL,'2025-12-26 19:20:54','2025-12-26 19:20:54'),('694f2666c3e44e650f0e6050','members','members_signup_access','all','string',NULL,'2025-12-26 19:20:54','2025-12-26 19:20:54'),('694f2666c3e44e650f0e6051','members','members_support_address','noreply','string','PUBLIC,RO','2025-12-26 19:20:54','2025-12-26 19:20:54'),('694f2666c3e44e650f0e6052','members','stripe_secret_key',NULL,'string',NULL,'2025-12-26 19:20:54','2025-12-26 19:20:54'),('694f2666c3e44e650f0e6053','members','stripe_publishable_key',NULL,'string',NULL,'2025-12-26 19:20:54','2025-12-26 19:20:54'),('694f2666c3e44e650f0e6054','members','stripe_plans','[]','array',NULL,'2025-12-26 19:20:54','2025-12-26 19:20:54'),('694f2666c3e44e650f0e6055','members','stripe_connect_publishable_key',NULL,'string',NULL,'2025-12-26 19:20:54','2025-12-26 19:20:54'),('694f2666c3e44e650f0e6056','members','stripe_connect_secret_key',NULL,'string',NULL,'2025-12-26 19:20:54','2025-12-26 19:20:54'),('694f2666c3e44e650f0e6057','members','stripe_connect_livemode',NULL,'boolean',NULL,'2025-12-26 19:20:54','2025-12-26 19:20:54'),('694f2666c3e44e650f0e6058','members','stripe_connect_display_name',NULL,'string',NULL,'2025-12-26 19:20:54','2025-12-26 19:20:54'),('694f2666c3e44e650f0e6059','members','stripe_connect_account_id',NULL,'string',NULL,'2025-12-26 19:20:54','2025-12-26 19:20:54'),('694f2666c3e44e650f0e605a','members','members_monthly_price_id',NULL,'string',NULL,'2025-12-26 19:20:54','2025-12-26 19:20:54'),('694f2666c3e44e650f0e605b','members','members_yearly_price_id',NULL,'string',NULL,'2025-12-26 19:20:54','2025-12-26 19:20:54'),('694f2666c3e44e650f0e605c','members','members_track_sources','true','boolean',NULL,'2025-12-26 19:20:54','2025-12-26 19:20:54'),('694f2666c3e44e650f0e605d','members','blocked_email_domains','[]','array',NULL,'2025-12-26 19:20:54','2025-12-26 19:20:54'),('694f2666c3e44e650f0e605e','portal','portal_name','true','boolean',NULL,'2025-12-26 19:20:54','2025-12-26 19:20:54'),('694f2666c3e44e650f0e605f','portal','portal_button','false','boolean',NULL,'2025-12-26 19:20:54','2025-12-26 19:20:54'),('694f2666c3e44e650f0e6060','portal','portal_plans','[\"free\"]','array',NULL,'2025-12-26 19:20:54','2025-12-26 19:20:54'),('694f2666c3e44e650f0e6061','portal','portal_default_plan','yearly','string',NULL,'2025-12-26 19:20:54','2025-12-26 19:20:54'),('694f2666c3e44e650f0e6062','portal','portal_products','[]','array',NULL,'2025-12-26 19:20:54','2025-12-26 19:20:54'),('694f2666c3e44e650f0e6063','portal','portal_button_style','icon-and-text','string',NULL,'2025-12-26 19:20:54','2025-12-26 19:20:54'),('694f2666c3e44e650f0e6064','portal','portal_button_icon',NULL,'string',NULL,'2025-12-26 19:20:54','2025-12-26 19:20:54'),('694f2666c3e44e650f0e6065','portal','portal_button_signup_text','Subscribe','string',NULL,'2025-12-26 19:20:54','2025-12-26 19:20:54'),('694f2666c3e44e650f0e6066','portal','portal_signup_terms_html',NULL,'string',NULL,'2025-12-26 19:20:54','2025-12-26 19:20:54'),('694f2666c3e44e650f0e6067','portal','portal_signup_checkbox_required','false','boolean',NULL,'2025-12-26 19:20:54','2025-12-26 19:20:54'),('694f2666c3e44e650f0e6068','email','mailgun_domain',NULL,'string',NULL,'2025-12-26 19:20:54','2025-12-26 19:20:54'),('694f2666c3e44e650f0e6069','email','mailgun_api_key',NULL,'string',NULL,'2025-12-26 19:20:54','2025-12-26 19:20:54'),('694f2666c3e44e650f0e606a','email','mailgun_base_url',NULL,'string',NULL,'2025-12-26 19:20:54','2025-12-26 19:20:54'),('694f2666c3e44e650f0e606b','email','email_track_opens','true','boolean',NULL,'2025-12-26 19:20:54','2025-12-26 19:20:54'),('694f2666c3e44e650f0e606c','email','email_track_clicks','true','boolean',NULL,'2025-12-26 19:20:54','2025-12-26 19:20:54'),('694f2666c3e44e650f0e606d','email','email_verification_required','false','boolean','RO','2025-12-26 19:20:54','2025-12-26 19:20:54'),('694f2666c3e44e650f0e606e','firstpromoter','firstpromoter','false','boolean',NULL,'2025-12-26 19:20:54','2025-12-26 19:20:54'),('694f2666c3e44e650f0e606f','firstpromoter','firstpromoter_id',NULL,'string',NULL,'2025-12-26 19:20:54','2025-12-26 19:20:54'),('694f2666c3e44e650f0e6070','labs','labs','{}','object',NULL,'2025-12-26 19:20:54','2025-12-26 19:20:54'),('694f2666c3e44e650f0e6071','slack','slack_url','','string',NULL,'2025-12-26 19:20:54','2025-12-26 19:20:54'),('694f2666c3e44e650f0e6072','slack','slack_username','Ghost','string',NULL,'2025-12-26 19:20:54','2025-12-26 19:20:54'),('694f2666c3e44e650f0e6073','unsplash','unsplash','true','boolean',NULL,'2025-12-26 19:20:54','2025-12-26 19:20:54'),('694f2666c3e44e650f0e6074','views','shared_views','[]','array',NULL,'2025-12-26 19:20:54','2025-12-26 19:20:54'),('694f2666c3e44e650f0e6075','editor','editor_default_email_recipients','visibility','string',NULL,'2025-12-26 19:20:54','2025-12-26 19:20:54'),('694f2666c3e44e650f0e6076','editor','editor_default_email_recipients_filter','all','string',NULL,'2025-12-26 19:20:54','2025-12-26 19:20:54'),('694f2666c3e44e650f0e6077','announcement','announcement_content',NULL,'string','PUBLIC','2025-12-26 19:20:54','2025-12-26 19:20:54'),('694f2666c3e44e650f0e6078','announcement','announcement_visibility','[]','array',NULL,'2025-12-26 19:20:54','2025-12-26 19:20:54'),('694f2666c3e44e650f0e6079','announcement','announcement_background','dark','string','PUBLIC','2025-12-26 19:20:54','2025-12-26 19:20:54'),('694f2666c3e44e650f0e607a','comments','comments_enabled','off','string',NULL,'2025-12-26 19:20:54','2025-12-26 19:20:54'),('694f2666c3e44e650f0e607b','analytics','outbound_link_tagging','true','boolean',NULL,'2025-12-26 19:20:54','2025-12-26 19:20:54'),('694f2666c3e44e650f0e607c','analytics','web_analytics','true','boolean',NULL,'2025-12-26 19:20:54','2025-12-26 19:20:54'),('694f2666c3e44e650f0e607d','pintura','pintura','true','boolean',NULL,'2025-12-26 19:20:54','2025-12-26 19:20:54'),('694f2666c3e44e650f0e607e','pintura','pintura_js_url',NULL,'string',NULL,'2025-12-26 19:20:54','2025-12-26 19:20:54'),('694f2666c3e44e650f0e607f','pintura','pintura_css_url',NULL,'string',NULL,'2025-12-26 19:20:54','2025-12-26 19:20:54'),('694f2666c3e44e650f0e6080','donations','donations_currency','USD','string',NULL,'2025-12-26 19:20:54','2025-12-26 19:20:54'),('694f2666c3e44e650f0e6081','donations','donations_suggested_amount','500','number',NULL,'2025-12-26 19:20:54','2025-12-26 19:20:54'),('694f2666c3e44e650f0e6082','recommendations','recommendations_enabled','false','boolean',NULL,'2025-12-26 19:20:54','2025-12-26 19:20:54'),('694f2666c3e44e650f0e6083','security','require_email_mfa','0','boolean',NULL,'2025-12-26 19:20:54','2025-12-26 19:20:54'),('694f2666c3e44e650f0e6084','social_web','social_web','true','boolean',NULL,'2025-12-26 19:20:54','2025-12-26 19:20:54'),('694f2666c3e44e650f0e6085','explore','explore_ping','true','boolean',NULL,'2025-12-26 19:20:54','2025-12-26 19:20:54'),('694f2666c3e44e650f0e6086','explore','explore_ping_growth','false','boolean',NULL,'2025-12-26 19:20:54','2025-12-26 19:20:54');
/*!40000 ALTER TABLE `settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `snippets`
--

DROP TABLE IF EXISTS `snippets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `snippets` (
  `id` varchar(24) NOT NULL,
  `name` varchar(191) NOT NULL,
  `mobiledoc` longtext NOT NULL,
  `lexical` longtext,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `snippets_name_unique` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `snippets`
--

LOCK TABLES `snippets` WRITE;
/*!40000 ALTER TABLE `snippets` DISABLE KEYS */;
/*!40000 ALTER TABLE `snippets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stripe_prices`
--

DROP TABLE IF EXISTS `stripe_prices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `stripe_prices` (
  `id` varchar(24) NOT NULL,
  `stripe_price_id` varchar(255) NOT NULL,
  `stripe_product_id` varchar(255) NOT NULL,
  `active` tinyint(1) NOT NULL,
  `nickname` varchar(255) DEFAULT NULL,
  `currency` varchar(191) NOT NULL,
  `amount` int NOT NULL,
  `type` varchar(50) NOT NULL DEFAULT 'recurring',
  `interval` varchar(50) DEFAULT NULL,
  `description` varchar(191) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `stripe_prices_stripe_price_id_unique` (`stripe_price_id`),
  KEY `stripe_prices_stripe_product_id_foreign` (`stripe_product_id`),
  CONSTRAINT `stripe_prices_stripe_product_id_foreign` FOREIGN KEY (`stripe_product_id`) REFERENCES `stripe_products` (`stripe_product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stripe_prices`
--

LOCK TABLES `stripe_prices` WRITE;
/*!40000 ALTER TABLE `stripe_prices` DISABLE KEYS */;
/*!40000 ALTER TABLE `stripe_prices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stripe_products`
--

DROP TABLE IF EXISTS `stripe_products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `stripe_products` (
  `id` varchar(24) NOT NULL,
  `product_id` varchar(24) DEFAULT NULL,
  `stripe_product_id` varchar(255) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `stripe_products_stripe_product_id_unique` (`stripe_product_id`),
  KEY `stripe_products_product_id_foreign` (`product_id`),
  CONSTRAINT `stripe_products_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stripe_products`
--

LOCK TABLES `stripe_products` WRITE;
/*!40000 ALTER TABLE `stripe_products` DISABLE KEYS */;
/*!40000 ALTER TABLE `stripe_products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subscriptions`
--

DROP TABLE IF EXISTS `subscriptions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `subscriptions` (
  `id` varchar(24) NOT NULL,
  `type` varchar(50) NOT NULL,
  `status` varchar(50) NOT NULL,
  `member_id` varchar(24) NOT NULL,
  `tier_id` varchar(24) NOT NULL,
  `cadence` varchar(50) DEFAULT NULL,
  `currency` varchar(50) DEFAULT NULL,
  `amount` int DEFAULT NULL,
  `payment_provider` varchar(50) DEFAULT NULL,
  `payment_subscription_url` varchar(2000) DEFAULT NULL,
  `payment_user_url` varchar(2000) DEFAULT NULL,
  `offer_id` varchar(24) DEFAULT NULL,
  `expires_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `subscriptions_member_id_foreign` (`member_id`),
  KEY `subscriptions_tier_id_foreign` (`tier_id`),
  KEY `subscriptions_offer_id_foreign` (`offer_id`),
  CONSTRAINT `subscriptions_member_id_foreign` FOREIGN KEY (`member_id`) REFERENCES `members` (`id`) ON DELETE CASCADE,
  CONSTRAINT `subscriptions_offer_id_foreign` FOREIGN KEY (`offer_id`) REFERENCES `offers` (`id`),
  CONSTRAINT `subscriptions_tier_id_foreign` FOREIGN KEY (`tier_id`) REFERENCES `products` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subscriptions`
--

LOCK TABLES `subscriptions` WRITE;
/*!40000 ALTER TABLE `subscriptions` DISABLE KEYS */;
/*!40000 ALTER TABLE `subscriptions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `suppressions`
--

DROP TABLE IF EXISTS `suppressions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `suppressions` (
  `id` varchar(24) NOT NULL,
  `email` varchar(191) NOT NULL,
  `email_id` varchar(24) DEFAULT NULL,
  `reason` varchar(50) NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `suppressions_email_unique` (`email`),
  KEY `suppressions_email_id_foreign` (`email_id`),
  CONSTRAINT `suppressions_email_id_foreign` FOREIGN KEY (`email_id`) REFERENCES `emails` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `suppressions`
--

LOCK TABLES `suppressions` WRITE;
/*!40000 ALTER TABLE `suppressions` DISABLE KEYS */;
/*!40000 ALTER TABLE `suppressions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tags`
--

DROP TABLE IF EXISTS `tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tags` (
  `id` varchar(24) NOT NULL,
  `name` varchar(191) NOT NULL,
  `slug` varchar(191) NOT NULL,
  `description` text,
  `feature_image` varchar(2000) DEFAULT NULL,
  `parent_id` varchar(191) DEFAULT NULL,
  `visibility` varchar(50) NOT NULL DEFAULT 'public',
  `og_image` varchar(2000) DEFAULT NULL,
  `og_title` varchar(300) DEFAULT NULL,
  `og_description` varchar(500) DEFAULT NULL,
  `twitter_image` varchar(2000) DEFAULT NULL,
  `twitter_title` varchar(300) DEFAULT NULL,
  `twitter_description` varchar(500) DEFAULT NULL,
  `meta_title` varchar(2000) DEFAULT NULL,
  `meta_description` varchar(2000) DEFAULT NULL,
  `codeinjection_head` text,
  `codeinjection_foot` text,
  `canonical_url` varchar(2000) DEFAULT NULL,
  `accent_color` varchar(50) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `tags_slug_unique` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tags`
--

LOCK TABLES `tags` WRITE;
/*!40000 ALTER TABLE `tags` DISABLE KEYS */;
INSERT INTO `tags` VALUES ('694f2665c3e44e650f0e5dea','News','news',NULL,NULL,NULL,'public',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-12-27 00:20:53','2025-12-27 00:20:53'),('694f2cf27f4d7d685707e3f7','Hardware & Operating System','hardware-operating-system',NULL,NULL,NULL,'public',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-12-27 00:48:50','2025-12-27 00:48:50'),('694f2cf37f4d7d685707e3f9','CPU Optimization','cpu-optimization',NULL,NULL,NULL,'public',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-12-27 00:48:51','2025-12-27 00:48:51'),('694f2cf37f4d7d685707e3fb','Performance','performance',NULL,NULL,NULL,'public',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-12-27 00:48:51','2025-12-27 00:48:51'),('694f2cf37f4d7d685707e3fd','Optimization','optimization',NULL,NULL,NULL,'public',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-12-27 00:48:51','2025-12-27 00:48:51'),('694f2cf37f4d7d685707e3ff','System Design','system-design',NULL,NULL,NULL,'public',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-12-27 00:48:51','2025-12-27 00:48:51'),('694f2cf37f4d7d685707e401','Architecture','architecture',NULL,NULL,NULL,'public',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-12-27 00:48:51','2025-12-27 00:48:51');
/*!40000 ALTER TABLE `tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tokens`
--

DROP TABLE IF EXISTS `tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tokens` (
  `id` varchar(24) NOT NULL,
  `token` varchar(32) NOT NULL,
  `uuid` varchar(36) NOT NULL,
  `data` varchar(2000) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  `first_used_at` datetime DEFAULT NULL,
  `used_count` int unsigned NOT NULL DEFAULT '0',
  `otc_used_count` int unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `tokens_uuid_unique` (`uuid`),
  KEY `tokens_token_index` (`token`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tokens`
--

LOCK TABLES `tokens` WRITE;
/*!40000 ALTER TABLE `tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` varchar(24) NOT NULL,
  `name` varchar(191) NOT NULL,
  `slug` varchar(191) NOT NULL,
  `password` varchar(60) NOT NULL,
  `email` varchar(191) NOT NULL,
  `profile_image` varchar(2000) DEFAULT NULL,
  `cover_image` varchar(2000) DEFAULT NULL,
  `bio` text,
  `website` varchar(2000) DEFAULT NULL,
  `location` text,
  `facebook` varchar(2000) DEFAULT NULL,
  `twitter` varchar(2000) DEFAULT NULL,
  `threads` varchar(191) DEFAULT NULL,
  `bluesky` varchar(191) DEFAULT NULL,
  `mastodon` varchar(191) DEFAULT NULL,
  `tiktok` varchar(191) DEFAULT NULL,
  `youtube` varchar(191) DEFAULT NULL,
  `instagram` varchar(191) DEFAULT NULL,
  `linkedin` varchar(191) DEFAULT NULL,
  `accessibility` text,
  `status` varchar(50) NOT NULL DEFAULT 'active',
  `locale` varchar(6) DEFAULT NULL,
  `visibility` varchar(50) NOT NULL DEFAULT 'public',
  `meta_title` varchar(2000) DEFAULT NULL,
  `meta_description` varchar(2000) DEFAULT NULL,
  `tour` text,
  `last_seen` datetime DEFAULT NULL,
  `comment_notifications` tinyint(1) NOT NULL DEFAULT '1',
  `free_member_signup_notification` tinyint(1) NOT NULL DEFAULT '1',
  `paid_subscription_started_notification` tinyint(1) NOT NULL DEFAULT '1',
  `paid_subscription_canceled_notification` tinyint(1) NOT NULL DEFAULT '0',
  `mention_notifications` tinyint(1) NOT NULL DEFAULT '1',
  `recommendation_notifications` tinyint(1) NOT NULL DEFAULT '1',
  `milestone_notifications` tinyint(1) NOT NULL DEFAULT '1',
  `donation_notifications` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_slug_unique` (`slug`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES ('694f2665c3e44e650f0e5dd8','Manuel A Rodriguez','manuel','$2a$10$DefHeqk9zRpMcLNeh0MwWubOAVgY9cWO7.cKuYtWJukd63x69tVni','rdgztorres19@gmail.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'{\"whatsNew\":{\"lastSeenDate\":\"2025-12-27T00:21:17.383Z\"},\"onboarding\":{\"completedSteps\":[\"customize-design\",\"first-post\",\"build-audience\",\"share-publication\"],\"checklistState\":\"completed\"}}','active',NULL,'public',NULL,NULL,NULL,'2025-12-27 00:45:14',1,1,1,0,1,1,1,1,'2025-12-27 00:20:53','2025-12-27 00:45:14');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `webhooks`
--

DROP TABLE IF EXISTS `webhooks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `webhooks` (
  `id` varchar(24) NOT NULL,
  `event` varchar(50) NOT NULL,
  `target_url` varchar(2000) NOT NULL,
  `name` varchar(191) DEFAULT NULL,
  `secret` varchar(191) DEFAULT NULL,
  `api_version` varchar(50) NOT NULL DEFAULT 'v2',
  `integration_id` varchar(24) NOT NULL,
  `last_triggered_at` datetime DEFAULT NULL,
  `last_triggered_status` varchar(50) DEFAULT NULL,
  `last_triggered_error` varchar(50) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `webhooks_integration_id_foreign` (`integration_id`),
  CONSTRAINT `webhooks_integration_id_foreign` FOREIGN KEY (`integration_id`) REFERENCES `integrations` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `webhooks`
--

LOCK TABLES `webhooks` WRITE;
/*!40000 ALTER TABLE `webhooks` DISABLE KEYS */;
/*!40000 ALTER TABLE `webhooks` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-12-26 20:22:11
